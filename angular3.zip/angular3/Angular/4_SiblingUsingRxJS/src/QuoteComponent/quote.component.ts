import { Component, OnInit, OnDestroy } from '@angular/core';
import { Author } from '../Models/app.author';
import { DataService } from '../Services/data.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'squote',
    templateUrl: 'quote.component.html',
    styleUrls: ['./quote.component.css'.toString()]
})

export class QuoteComponent implements OnInit, OnDestroy {
    selectedAuthor: Author;
    sAuthorSub: Subscription;

    constructor(private dService: DataService) { }

    ngOnInit() {
        this.sAuthorSub = this.dService.sauthorChanged.subscribe(() => { 
            this.selectedAuthor = this.dService.SAuthor;
        });
    }

    ngOnDestroy(): void {
        this.sAuthorSub.unsubscribe();
    }
}