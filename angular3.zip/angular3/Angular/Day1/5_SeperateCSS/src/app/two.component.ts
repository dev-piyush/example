import { Component } from "@angular/core";

@Component({
    selector: 'ctwo',
    template: '<h2>Hello from Component Two!</h2>'
})
export class ComponentTwo { }