import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { ComponentOne } from "./one.component";
import { ComponentTwo } from "./two.component";
import { RootComponent } from "./root.component";

@NgModule({
    imports: [BrowserModule],
    declarations: [RootComponent, ComponentOne, ComponentTwo],
    bootstrap: [RootComponent]
})
export class RootModule { }