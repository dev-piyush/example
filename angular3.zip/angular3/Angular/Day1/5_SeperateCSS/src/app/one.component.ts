import { Component } from "@angular/core";

@Component({
    selector: 'cone',
    template: '<h2>Hello from Component One!</h2>'
})
export class ComponentOne { }