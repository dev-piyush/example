//------------------------------------------------ FormBuilder & Validations

import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
    selector: 'rf',
    templateUrl: 'rf.component.html'
})

export class ReactiveFormsComponent implements OnInit {
    rForm: FormGroup;

    constructor(private fb: FormBuilder) { }

    ngOnInit() {
        this.rForm = this.fb.group({
            firstname: [null, Validators.required],
            lastname: [null, Validators.compose([Validators.required,
                Validators.minLength(2), Validators.maxLength(20)])],
            address: this.fb.group({
                city: [null, Validators.required],
                zip: 0
            })
        })
    }

    logForm(frm: FormGroup) {
        if(frm.valid)
            console.log(frm.value);
        else
            console.error("Invalid Form");
    }
}

// //------------------------------------------------ FormBuilder

// import { Component, OnInit } from '@angular/core';
// import { FormGroup, FormBuilder } from '@angular/forms';

// @Component({
//     selector: 'rf',
//     templateUrl: 'rf.component.html'
// })

// export class ReactiveFormsComponent implements OnInit {
//     rForm: FormGroup;

//     constructor(private fb: FormBuilder) { }

//     ngOnInit() {
//         this.rForm = this.fb.group({
//             firstname: "Manish",
//             lastname: "",
//             address: this.fb.group({
//                 city: "",
//                 zip: 0
//             })
//         })
//     }

//     logForm(frm: FormGroup) {
//         console.log(frm.value);

//     }
// }

//------------------------------------------------ FormGroup and FormControl

// import { Component, OnInit } from '@angular/core';
// import { FormGroup, FormControl } from '@angular/forms';

// @Component({
//     selector: 'rf',
//     templateUrl: 'rf.component.html'
// })

// export class ReactiveFormsComponent implements OnInit {
//     rForm: FormGroup;

//     constructor() { }

//     ngOnInit() {
//         this.rForm = new FormGroup({
//             firstname: new FormControl(),
//             lastname: new FormControl(),
//             address: new FormGroup({
//                 city: new FormControl(),
//                 zip: new FormControl()
//             })
//         })
//     }

//     logForm(frm: FormGroup) {
//         console.log(frm);
//     }
// }