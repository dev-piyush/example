import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

import { RootComponent } from "./root.component";
import { FormsModule } from "@angular/forms";

import { DataListComponent } from "./DataListComponent/dlist.component"
import { CounterComponent } from "./CounterComponent/counter.component";

@NgModule({
    imports: [BrowserModule, FormsModule],
    declarations: [RootComponent, DataListComponent, CounterComponent],
    bootstrap: [RootComponent]
})
export class RootModule { }