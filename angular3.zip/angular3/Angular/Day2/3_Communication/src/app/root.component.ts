import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { CounterComponent } from './CounterComponent/counter.component';

@Component({
    selector: 'root',
    template: ` <div class="container">
        <h2 class="text-danger">{{message}}</h2>
    
        <counter #c1 (onMax)=maxedOut($event)></counter>
        <br>
        <br>
        <button class="btn btn-success btn-block" (click)=c1.reset()>Parent Reset</button>
        <button class="btn btn-success btn-block" (click)=p_reset1(c1)>Parent Reset</button>
        
        <!-- <counter></counter>
        <br>
        <counter [interval]=10></counter> -->
        
        <!--<br>
        <dlist [personList]=plist></dlist>-->
    </div>`
})

export class RootComponent implements OnInit, AfterViewInit {
    @ViewChild(CounterComponent)
    counter: CounterComponent;
    
    message: string;

    plist: Array<string>;

    constructor() {
        this.plist = ["Manish", "Ramkant", "Varun", "Abhijeet", "Subodh"];
    }

    ngAfterViewInit(): void {
        this.counter.interval = 10;
    }

    ngOnInit() { }

    p_reset1(c: CounterComponent) {
        c.reset();
    }

    maxedOut(flag:boolean){
        if(flag)
            this.message = "Maxed Out, click Reset";
        else
            this.message = "";
    }
}