import { Component, OnInit, AfterViewInit } from '@angular/core';

@Component({
    selector: 'root',
    template: ` <div class="container">
        <h2 class="text-danger">Data Binding Demo</h2>
        <assign1></assign1>
        <assign2></assign2>
        <hr/>
        <h2 class="text-info">Two Way Binding</h2>
        <input type="text" bindon-ngModel=message/>
        <input type="text" [(ngModel)]=message [ngModelOptions]="{updateOn:'blur'}"/>
        
        <input type="text" [(ngModel)]=city (change)=update(city)/>
        <input type="text" [(ngModel)]=city (input)=update(city)/>
        <h3>City is: {{city}}</h3>

        <hr/>
        <h2 class="text-info">Event Binding</h2>
        <button class="btn btn-primary" on-click=doChange()>Click</button>
        <button class="btn btn-primary" (click)=doChange()>Click</button>
        <button class="btn btn-danger" id="btnJS">Click JS</button>
        
        <hr/>
        <h2 class="text-info">Property Binding</h2>
        <h3>Message: {{message}}</h3>
        <h3 innerHTML={{message}}>Message: </h3>
        <h3 bind-innerHTML=message>Message: </h3>
        <h3 [innerHTML]=message>Message: </h3>
        <input type="text" [value]=message/>
    </div>`
})

export class RootComponent implements OnInit, AfterViewInit {
    message: string;

    constructor() {
        this.message = "Hello World";
    }

    ngOnInit() { }

    ngAfterViewInit(): void {
        // console.log("ngAfterViewInit - ", document.getElementById("btnJS"));

        // if (document.getElementById("btnJS"))
        //     document.getElementById("btnJS").addEventListener("click", () => {
        //         this.message = "Changed by JS " + new Date().toLocaleTimeString();
        //     });

        var self = this;
        $("#btnJS").click(function(){
            self.message = "Changed by JS " + new Date().toLocaleTimeString();
        });


        // $("#btnJS").click(() => {
        //     this.message = "Changed by JS " + new Date().toLocaleTimeString();
        // });
    }

    doChange() {
        // alert("Clicked.....");
        this.message = "Changed " + new Date().toTimeString();
    }

    update(city:string){
        this.message = "You are from : " + city.toUpperCase();
    }
}