import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

import { RootComponent } from "./root.component";
import { FormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { Assign1Component } from "./assign1.component";
import { Assign2Component } from "./assign2.component";

@NgModule({
    imports: [BrowserModule, FormsModule, CommonModule],
    declarations: [RootComponent, Assign1Component, Assign2Component],
    bootstrap: [RootComponent]
})
export class RootModule { }