import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

import { RootComponent } from "./root.component";
import { FormsModule } from "@angular/forms";
import { ListComponent } from "./ListComponent/list.component";
import { TabRootComponent } from "./TabComponent/tab-root.component";
import { TabComponent } from "./TabComponent/tab.component";
import { TabContentComponent } from "./TabComponent/tab-content.component";

@NgModule({
    imports: [BrowserModule, FormsModule],
    declarations: [RootComponent],
    bootstrap: [RootComponent]
})
export class RootModule { }