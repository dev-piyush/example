import { Component, OnInit, AfterViewInit } from '@angular/core';

@Component({
    selector: 'root',
    template: ` <div class="container">
        <!-- <h3 *ngIf="message; else elseBlock">{{message}}</h3>
        <ng-template #elseBlock>
            <h3>Nothing to Display</h3>
        </ng-template> -->

        <!-- <list></list> -->

         <ul [ngSwitch]="person">
            <li *ngSwitchCase="'Manish'">Hello Manish</li>
            <li *ngSwitchCase="'Abhijeet'">Hello Abhijeet</li>
            <li *ngSwitchCase="'Ramakant'">Hello Ramakant</li>
            <li *ngSwitchCase>Hello World</li>
        </ul> 

        <tab-root></tab-root>
    </div>`
})

export class AppComponent implements OnInit {
    message: string;
    person:string;

    constructor() {
        // this.message = "Hello";
        this.person = "Manish";
    }

    ngOnInit() { }
}