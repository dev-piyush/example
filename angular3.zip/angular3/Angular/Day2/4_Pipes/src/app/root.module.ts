import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

import { RootComponent } from "./root.component";
import { FormsModule } from "@angular/forms";

import { DataListComponent } from "./DataListComponent/dlist.component"
import { CapitalizePipe } from "./Pipes/capitalize.pipe";
import { FilterPipe } from "./Pipes/filter.pipe";

@NgModule({
    imports: [BrowserModule, FormsModule],
    declarations: [RootComponent, DataListComponent, CapitalizePipe, FilterPipe],
    bootstrap: [RootComponent]
})
export class RootModule { }