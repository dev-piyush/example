import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';

@Component({
    selector: 'root',
    template: ` <div class="container">
        <dlist [personList]=plist></dlist>
        
        <h2>{{name | capitalize}}</h2>

        <h2>{{name}}</h2>
        <h2>{{name | uppercase}}</h2>

        <h2>{{today}}</h2>
        <h2>{{today | date}}</h2>
        <h2>{{today | date:'MMM/dd/yyyy'}}</h2>
        <h2>{{today | date:format}}</h2>
        <button (click)=toggleFormat()>Toggle</button>
    </div>`
})

export class RootComponent implements OnInit, AfterViewInit {
    plist: Array<string>;
    name: string = "manish sharma";
    toggle = false;
    today = new Date();

    get format() {
        return this.toggle ? 'shortDate' : 'fullDate';
    }

    toggleFormat() {
        this.toggle = !this.toggle;
    }

    constructor() {
        this.plist = ["Manish", "Ramkant", "Varun", "Abhijeet", "Subodh"];
    }

    ngAfterViewInit(): void {
    }

    ngOnInit() { }
}