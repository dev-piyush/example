import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'root',
    template: ` <div class="container">
        <!-- <mb></mb> -->
        <!-- <tf></tf> -->
        <rf></rf>
    </div>`
})

export class RootComponent implements OnInit {
    constructor() {
    }

    ngOnInit() { }
}