import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

import { RootComponent } from "./root.component";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { ModelBasedComponent } from "./ModelBased/mb.component";
import { TemplatedFormComponent } from "./Templated/tf.component";
import { ReactiveFormsComponent } from "./ReactiveForms/rf.component";

@NgModule({
    imports: [BrowserModule, FormsModule, ReactiveFormsModule],
    declarations: [RootComponent, ModelBasedComponent, TemplatedFormComponent, ReactiveFormsComponent],
    bootstrap: [RootComponent]
})
export class RootModule { }