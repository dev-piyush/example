import { NgModule } from '@angular/core';
import { BrowserModule } from "@angular/platform-browser";
import { FormsModule } from '@angular/forms'
import { RouterModule } from '@angular/router';

import { RootComponent } from "./app.component";
import { AListComponent } from './ListComponent/list.component';

import { routes } from './app.routes';
import { QuoteModule } from './quote.module';

@NgModule({
    imports: [BrowserModule, FormsModule,
        RouterModule.forRoot(routes), QuoteModule],
    declarations: [RootComponent, AListComponent],
    bootstrap: [RootComponent]
})
export class AppModule { }