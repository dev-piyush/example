import { NgModule } from '@angular/core';

import { QuoteComponent } from './QuoteComponent/quote.component';
import { CommonModule } from '@angular/common';

@NgModule({
    imports:[CommonModule],
    declarations: [QuoteComponent],
    exports: [QuoteComponent]
})
export class QuoteModule { }