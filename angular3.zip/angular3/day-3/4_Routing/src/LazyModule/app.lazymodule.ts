import { NgModule } from '@angular/core';

import { LazyComponent } from './app.lazycomponent';
import { routing } from './app.lazyrouting';
import { TestComponent } from './app.testcomponent';

@NgModule({
    imports: [routing],
    declarations: [LazyComponent, TestComponent]
})
export class LazyModule { }
