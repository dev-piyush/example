import { Routes, RouterModule } from "@angular/router";
import { LazyComponent } from "./app.lazycomponent";
import { ModuleWithProviders } from "@angular/core";
import { TestComponent } from "./app.testcomponent";

const routes: Routes = [
    { path: '', component: LazyComponent },
    { path: 'lazy/test', component: TestComponent }
]

export const routing: ModuleWithProviders =
    RouterModule.forChild(routes);