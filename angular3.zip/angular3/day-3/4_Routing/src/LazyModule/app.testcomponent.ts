import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-lazy',
    template: `<h2>Test Component</h2>`
})

export class TestComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}