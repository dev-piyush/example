import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'my-lazy',
    template: `<h2>Lazy Loaded Component</h2>
                <a routerLink="test">Test</a>
                <router-outlet></router-outlet>
    `
})

export class LazyComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}