import { Routes } from "@angular/router";
import { AListComponent } from "./ListComponent/list.component";
import { QuoteComponent } from "./QuoteComponent/quote.component";

export const routes: Routes = [
    { path: 'list', component: AListComponent },
    { path: 'quote', component: QuoteComponent },
    { path: 'quote/:name', component: QuoteComponent },
    { path: 'lazy', loadChildren: './LazyModule/app.lazymodule#LazyModule'}
];