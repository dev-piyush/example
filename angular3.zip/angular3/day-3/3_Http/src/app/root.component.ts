import { Component, OnInit, OnDestroy } from '@angular/core';
import { DataService } from './Services/data.service';
import { Subscription } from 'rxjs';

@Component({
    selector: 'root',
    template: ` <div class="container">
        <ul *ngIf="posts && posts.length">
            <li *ngFor="let post of posts">
                <h3>{{post.id}}</h3>
                <h4>{{post.title}}</h4>
                <p>{{post.body}}</p>
                <hr/>
            <li>
        </ul>
    </div>`,
    providers: [DataService]
})

export class RootComponent implements OnInit, OnDestroy {
    
    posts: Array<any>;
    sub:Subscription;

    constructor(private dService: DataService) {
    }

    ngOnInit() {
        this.sub = this.dService.getPosts().subscribe((data) => {
            this.posts = data;
            console.log(this.posts);
        })
    }

    ngOnDestroy(): void {
        this.sub.unsubscribe();
    }
}