import { Component, OnInit, OnDestroy } from '@angular/core';
import { DataService } from './Services/data.service';

@Component({
    selector: 'root',
    template: ` <div class="container">
        <products></products>
    </div>`,
    providers: [DataService]
})

export class RootComponent implements OnInit {
    constructor() {
    }

    ngOnInit() {
    }
}