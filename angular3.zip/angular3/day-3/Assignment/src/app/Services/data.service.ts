import { Http } from "@angular/http";
import { Injectable } from "@angular/core";
import { Observable } from 'rxjs';
import { Product } from "../Models/product";

@Injectable()
export class DataService {
    private url = "http://localhost:8000/products";

    constructor(private http: Http) { }

    getAllProducts(): Observable<Array<Product>> {
        return this.http.get(this.url).map((res) => {
            return res.json()
        });
    }
}