import { Component, OnInit, OnDestroy } from '@angular/core';
import { DataService } from '../Services/data.service';
import { Subscription } from 'rxjs';
import { Product } from '../Models/product';

@Component({
    selector: 'products',
    templateUrl: 'products.component.html'
})

export class ProductsComponent implements OnInit, OnDestroy {

    products: Array<Product>;
    sub: Subscription;

    constructor(private dService: DataService) {
    }

    ngOnInit() {
        this.sub = this.dService.getAllProducts().subscribe((data) => {
            this.products = data;
        })
    }

    ngOnDestroy(): void {
        this.sub.unsubscribe();
    }
}