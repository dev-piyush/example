from distutils.version import StrictVersion


VERSION = StrictVersion('3.2.1')

