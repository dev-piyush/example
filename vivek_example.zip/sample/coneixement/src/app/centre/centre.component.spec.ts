import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CentreComponent } from './centre.list.component';

describe('CentreComponent', () => {
  let component: CentreComponent;
  let fixture: ComponentFixture<CentreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CentreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CentreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
