import { Component, OnInit } from '@angular/core';
import { Centre } from '../_models/centre';
import { CentreService } from '../_services/index';
import {Observable} from 'rxjs/Observable';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
@Component({
    moduleId: module.id,
    templateUrl: '../_templates/centres/list.component.html',
})
 
export class CentreComponent implements OnInit {
  title="Centres";
  output={};
  public myForm: FormGroup; // our model driven form
  public submitted: boolean; // keep track on whether form is submitted
  public events: any[] = []; // use later to display form changes
  list=new Observable<Centre[]>();
  constructor(private service:CentreService, private _fb: FormBuilder) {
  }   
  initalizeForm(){
  this.myForm = new FormGroup({
        name: new FormControl('', [<any>Validators.required, <any>Validators.minLength(5)]),
        address: new FormGroup({
        	  building: new FormControl('', <any>Validators.required),
            street: new FormControl('', <any>Validators.required),
            city: new FormControl('', <any>Validators.required),
            state: new FormControl('', <any>Validators.required),
            country: new FormControl('', <any>Validators.required),
            region: new FormControl('', <any>Validators.required),
            postcode: new FormControl('', <any>Validators.required)
        })
    });
    this.subcribeToFormChanges()
  }
  subcribeToFormChanges() {
  this.myForm.valueChanges.subscribe(data => {
      console.log('Form changes', data)
      this.output = data
    })
	}


  ngOnInit() {
  this.initalizeForm()
  this.list=this.service.getAll();
  }
  save(model: Centre, isValid: boolean) {
        this.submitted = true; // set form submit to true

        // check if model is valid
        // if valid, call API to save customer
        console.log(model, isValid);
  }

}
