export interface Roles {
  reader: boolean;
  author?: boolean;
  admin?:  boolean;
}
