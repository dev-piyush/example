export class User {
     pk:string;
     username:string;
     email:string;
     first_name:string;
     last_name:string;
     key:string;
}