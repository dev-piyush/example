export class Centre {
 

 	public name: string; // required with minimum 5 chracters
    public address?: {
    	building?: string; // required
        street?: string; // required
        city?: string;
        state?: string;
        region?: string;
        country?: string;
        postcode?: string;
    }	 
   
   }