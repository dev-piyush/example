import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import {Observable} from 'rxjs/Observable';
import {Headers} from '@angular/http';
import {RequestOptions} from '@angular/http';
@Injectable()
export class RestService<T>{	
  constructor(protected http: Http, private actionUrl:string){
  
  }
  createContentTypeHeader(headers: Headers) {
    headers.append('content-Type', 'application/json'); 
  }
  createAuthnticationHeader(headers: Headers,token:string) {
    headers.append('Authorization', 'Token '+token); 
  }
  getAll():Observable<T[]>{
    return this.http.get(this.actionUrl).map(resp=>resp.json() as T[]);
  }
  getOne(id:number):Observable<T>{
    return this.http.get(`${this.actionUrl}${id}`).map(resp=>resp.json() as T);
  }
  get(token:string):Observable<T>{
    console.log("data"+token)
    let headers = new Headers();
    this.createContentTypeHeader(headers);
    if(token){
      this.createAuthnticationHeader(headers,token);
    }
    let options = new RequestOptions({
        method:'GET',
        headers: headers
    });
    return this.http.get(this.actionUrl,options).map(resp=>resp.json() as T);
 
  }
  post(data,token:string):Observable<T>{
    console.log("data"+data)
    let headers = new Headers();
    this.createContentTypeHeader(headers);
    if(token){
      this.createAuthnticationHeader(headers,token);
    }
    return this.http.post(this.actionUrl, data, {
      headers: headers
    }).map(resp=>resp.json() as T);
  }

  
}
