import { Injectable } from '@angular/core';
import { Http } from '@angular/http';
import { RestService } from './rest.service';
import { Centre } from '../_models/centre';

@Injectable()
export class CentreService extends RestService<Centre>{
  url = "http://jsonplaceholder.typicode.com/posts";
  constructor(protected http:Http) {
  	super(http,'http://jsonplaceholder.typicode.com/posts');
  }
}
