import { Injectable } from '@angular/core';
import { Http, Headers, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'
import { User } from '../_models/user'; 
import { RestService } from './rest.service';
import { ConfigurationService } from './configuration.service';
@Injectable()
export class LoginService extends RestService<User> {
    constructor(protected http: Http,
        protected configuration : ConfigurationService) { 
        super(http,configuration.LoginApiUrl);

    } 
    loginFromAPI(username: string, password: string) {
        let user =this.post(JSON.stringify({ username: username, password: password }),undefined)
        return user;   
    }

    loginFrom(username: string, password: string) {
    let url= 'http://localhost:7000/api-token-auth/';
      return this.http.post(url, {username:username,password:password})
    
    }
    
}