import { Injectable } from '@angular/core';

@Injectable()
export class ConfigurationService {
	readonly Server: string;
    readonly ApiRoot: string;
    readonly LoginApiUrl: string;
    readonly ApiUrl: string;
	constructor() {
	this.Server = 'http://localhost:5000/';
    this.ApiRoot = 'api/';
    this.LoginApiUrl = 'http://103.25.130.145/rest-auth/';
    this.LoginApiUrl = 'http://localhost:7000/api-token-auth/';
    this.ApiUrl = this.Server + this.ApiRoot;
 	}	
   
}