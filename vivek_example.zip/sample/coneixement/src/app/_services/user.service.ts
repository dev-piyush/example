import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { RestService } from './rest.service'; 
import { User } from '../_models/index';
import { ConfigurationService } from './configuration.service'; 
@Injectable()
export class UserService extends RestService<User> {
	token:string;
    constructor(protected http: Http,
    	protected configuration : ConfigurationService) { 
         super(http,configuration.LoginApiUrl+'user/');

    } 
    getCurrentUserInfo() {
        let user =this.get(this.token)
        return user;   
    }
    getCurrentUser(){
    	return this.token;
    }
    setUserAuthToken(token:string) {
        this.token=token
        console.log(this.token)
    }
 
}