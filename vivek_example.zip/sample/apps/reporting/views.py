# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from rest_framework.response import Response
from rest_framework import authentication, permissions
from rest_framework.decorators import api_view
from account_master.models import *
from location_master.models import *
from skill_master.models import *
from demand_master.models import *
from framework.utils import *
import time
import sys
from collections import OrderedDict
import json
from django.shortcuts import render_to_response
from django.template import RequestContext

from datetime import date, datetime
@api_view()
def index(request):
    from .urls import urlpatterns
    return render_to_response('reporting/index.html',
                                  {
                                      'urlpatterns': urlpatterns,
                                  },
                                  RequestContext(request)) 
    



@api_view()
def demands(request):
    rows = ResourceRequest.objects.all()
    output = []
    for demand in rows:
            candidatures = demand.candidatures.all()
            if candidatures.count() > 0:
                for candidature in candidatures:
                    resource = candidature.resource
                    row = OrderedDict()
                    print demand.job_code
                    row['RR'] = demand.RR
                    row['job_code'] = demand.job_code
                    row['tech_skills'] = demand.tech_skills
                    row['technology'] = demand.technology.name
                    row['department'] = demand.department.name if demand.department is not None else ""
                    row['sub_department'] = demand.sub_department.name if demand.sub_department is not None else ""
                    row['requestor'] = demand.requestor
                    row['location'] = demand.location.name if demand.location is not None else ""
                    row['request_publish_date'] = demand.request_receive_date
                    row['aging'] = demand.age()
                    row['number_of_profile_send'] = candidatures.count()
                    row['number_of_profile_intervieed'] = candidatures.count()
                    row['candidature_status'] = candidature.actual_selection_status
                    row['selection_status'] = demand.demand_status
                    row['selection_date'] = candidature.selection_date if candidature.selection_date is not None else ""
                    row['emp_id'] = resource.employee_id if resource is not None else ""
                    row['emp_name'] = resource.employee_name if resource is not None else ""
                    row['preposed_date_of_joining'] = candidature.onboarding_date
                    row['dc_status'] = resource.DC_status if resource is not None else ""
                    row['bgv_status'] = resource.BGV_status if resource is not None else ""
                    row['sow_signed'] = demand.get_sow(
                    ).status if demand.get_sow(
                    ) is not None else ""
                    row['onboarded'] = candidature.onbording_status
                    row['date_of_actual_joining'] = candidature.actual_start_date if candidature.actual_start_date is not None else ""
                    row['abort'] = ""
                    row['delayed'] = ""
                    row['Reason_for_Abort_or_Delay'] = candidature.remarks
                    row['Remarksifany'] = candidature.remarks
                    row['role'] = candidature.selection_role
                    row['HSBC_priority'] = ""
                    row['requisition'] = ""
                    row['total'] = ""
                    row['open'] = ""
                    row['closed'] = ""
                    row['on_hold'] = ""
                    row['demand_cancelled'] = ""
                    row['Profiles'] = ""
                    row['Interviewed'] = ""
                    row['ProfilesSentDate'] = ""
                    row['EnhancedStatus'] = ""
                    row['Remarks'] = ""
                    row['Must_start_by_date'] = ""
                    row['RAG'] = ""
                    row['Last_Updated_on'] = ""
                    row['profile_send_aging'] = ""
                    row['Synechron POC'] = demand.SPOC.name
                    output.append(row)
            else:
                print "No Candidature found"
                row = OrderedDict()
                print demand.job_code
                row['RR'] = demand.RR
                row['job_code'] = demand.job_code
                row['tech_skills'] = demand.tech_skills
                row['technology'] = demand.technology.name
                row['department'] = demand.department.name if demand.department is not None else ""
                row['sub_department'] = demand.sub_department.name if demand.sub_department is not None else ""
                row['requestor'] = demand.requestor
                row['location'] = demand.location.name if demand.location is not None else ""
                row['request_publish_date'] = demand.request_receive_date
                row['aging'] = demand.age()
                row['number_of_profile_send'] = 0
                row['number_of_profile_intervieed'] = 0
                row['candidature_status'] =""
                row['selection_status'] = demand.demand_status
                row['selection_date'] = ""
                row['emp_id'] = ""
                row['emp_name'] = ""
                row['preposed_date_of_joining'] = ""
                row['dc_status'] = ""
                row['bgv_status'] = ""
                row['sow_signed'] = demand.get_sow(
                ).status if demand.get_sow(
                ) is not None else ""
                row['onboarded'] = ""
                row['date_of_actual_joining'] = ""
                row['abort'] = ""
                row['delayed'] = ""
                row['Reason_for_Abort_or_Delay'] = ""
                row['Remarksifany'] = ""
                row['role'] = ""
                row['HSBC_priority'] = ""
                row['requisition'] = ""
                row['total'] = ""
                row['open'] = ""
                row['closed'] = ""
                row['on_hold'] = ""
                row['demand_cancelled'] = ""
                row['Profiles'] = ""
                row['Interviewed'] = ""
                row['ProfilesSentDate'] = ""
                row['EnhancedStatus'] = ""
                row['Remarks'] = ""
                row['Must_start_by_date'] = ""
                row['RAG'] = ""
                row['Last_Updated_on'] = ""
                row['profile_send_aging'] = ""
                row['Synechron POC'] = demand.SPOC.name
                output.append(row)

    return Response({"results": output})


@api_view()
def resources(request):
    from resource_master.models import *
    from candidature_master.models import *
    rows = Resource.objects.all().values(
            'synechron_account__name',
            'employee_name',
            'employee_id',
            'email',
            'account_start_data',
            'account_release_date',
            'country__name',
            'city__name')
    for r in rows:
            candidature = None
            r['role'] = r['project_name'] = r[
                'project_start_date'] = r['project_end_date'] = ""
            r['sow'] = r['hsbc_line_manager'] = r[
                'spoc'] = r['hsbc_department'] = ""
            r['hsbc_sub_department'] = r['sow_value'] = ""
            candidatures = Candidature.objects.filter(resource__employee_id=r[
                                                      'employee_id'], selection_status='SELECTED').order_by('-last_moddified_on')
            if candidatures.count() > 0:
                candidature = candidatures[0]
            if candidature is not None:
                r['role'] = candidature.selection_role
                r['project_name'] = candidature.resource_request.project_name
                r['project_start_date'] = candidature.onboarding_date
                r['project_end_date'] = candidature.release_date
                r['selection_role'] = candidature.selection_role
                if  candidature.resource_request.sows.all().count()>0:
                    r['sow'] = candidature.resource_request.sows.all()[
                            0].SOW_ID
                    r['sow_value'] = candidature.resource_request.sows.all()[
                            0].SOW_value

                r['hsbc_line_manager'] = candidature.resource_request.hiring_manager
                r['spoc'] = candidature.resource_request.SPOC.name
                r['hsbc_department'] = candidature.resource_request.department.name

                r['hsbc_sub_department'] = candidature.resource_request.sub_department.name

                


    return Response({"results": rows})


@api_view()
def sows(request):
    from sow_master.models import *
    rows = SOW.objects.all().values('approval_received_from_procurement',
                                        'SOW_ID',
                                        'location__name',
                                        'status',
                                        'line_manager',
                                        'department__name',
                                        'start_date',
                                        'end_date',
                                        'payment_terms',
                                        'SOW_value',
                                        'bill_rate',
                                        'number_of_resources',
                                        'commited_spend_days_2016',
                                        'commited_spend_days_2017',
                                        'commited_spend_days_2018',
                                        )
    for r in rows:
            r['project_name']  = r['spoc'] = r['HSBC_department'] = r[
                'HSBC_sub_department'] = r['sow_status'] = r['actual_onborded'] = ""
            if SOW.objects.filter(SOW_ID=r['SOW_ID'])[0].resource_requests.count() > 0:
                    r['project_name'] = SOW.objects.filter(SOW_ID=r['SOW_ID'])[
                        0].resource_requests.all()[0].project_name
                    r['line_manager'] = SOW.objects.filter(SOW_ID=r['SOW_ID'])[
                        0].resource_requests.all()[0].hiring_manager
                    r['spoc'] = SOW.objects.filter(SOW_ID=r['SOW_ID'])[
                        0].resource_requests.all()[0].SPOC.name
                    r['HSBC_department'] = SOW.objects.filter(SOW_ID=r['SOW_ID'])[
                        0].resource_requests.all()[0].department.name
                    r['HSBC_sub_department'] = SOW.objects.filter(
                        SOW_ID=r['SOW_ID'])[0].resource_requests.all()[0].sub_department.name
                    r['actual_onborded'] = SOW.objects.filter(SOW_ID=r['SOW_ID'])[
                        0].resource_requests.filter(demand_status='Deployed').count()

    return Response({"results": rows})




@api_view()
def onboarding(request):
    from candidature_master.models import *
    rows = Candidature.objects.onboarded().values(
            'resource_request__id',
            'resource__BGV_status',
            'resource__DC_status',
            'resource__BGV_credit_check_status',
            'resource__employee_name',
            'resource__employee_id',
            'resource__primary_skills__name',
            'resource__is_external',
            'selection_status',
            'resource_request__location__name',
            'selection_date',
            'resource_request__department__name',
            'resource_request__sub_department__name',
            'resource_request__RR',
            'resource_request__job_code',
            'resource_request__SPOC__name',
            'resource_request__hiring_manager',
            'selection_role',
            'on_boarding_kit',
            'onboarding_date')
    for r in rows:
            r['approval_received_from_procurement'] = r['SOW_sent_date_to_procurement'] = r['approval_received_from_account_manager'] = r[
                'sow'] = r['sow_start_date'] = r['bill_rate'] = r['sow_end_date'] = r['sow_status'] = r['SOW_sent_date_to_account_manager'] = ''
            if ResourceRequest.objects.get(pk=r['resource_request__id']).sows.all().count() > 0:
                r['sow'] = ResourceRequest.objects.get(
                    pk=r['resource_request__id']).sows.all()[0].SOW_ID

                r['sow_start_date'] = ResourceRequest.objects.get(
                    pk=r['resource_request__id']).sows.all()[0].start_date
                r['bill_rate'] = ResourceRequest.objects.get(
                    pk=r['resource_request__id']).sows.all()[0].bill_rate

                r['sow_end_date'] = ResourceRequest.objects.get(
                    pk=r['resource_request__id']).sows.all()[0].end_date
                r['sow_status'] = ResourceRequest.objects.get(
                    pk=r['resource_request__id']).sows.all()[0].status

                r['SOW_sent_date_to_account_manager'] = ResourceRequest.objects.get(
                    pk=r['resource_request__id']).sows.all()[0].SOW_sent_date_to_account_manager
                r['approval_received_from_account_manager'] = ResourceRequest.objects.get(
                    pk=r['resource_request__id']).sows.all()[0].approval_received_from_account_manager
                r['SOW_sent_date_to_procurement'] = ResourceRequest.objects.get(
                    pk=r['resource_request__id']).sows.all()[0].SOW_sent_date_to_procurement
                r['approval_received_from_procurement'] = ResourceRequest.objects.get(
                    pk=r['resource_request__id']).sows.all()[0].approval_received_from_procurement
    return Response({"results": rows})