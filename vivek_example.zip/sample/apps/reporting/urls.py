from django.conf.urls import url
from .views import *
from . import views
urlpatterns = [
url(r'^$',
        views.index, name='index'),
  url(r'^demands/$',
        views.demands, name='demands'),
  url(r'^sows/$',
        views.sows, name='sows'),
  url(r'^resources/$',
        views.resources, name='resources'),
  url(r'^onboarding/$',
        views.onboarding, name='onboarding'),
]
