
import django_filters
from .models import QuickMessage
from framework.filters import WithinDateFilter


class QuickMessageFilter(django_filters.FilterSet):
    timerange = WithinDateFilter(name='created_on')
    text = django_filters.CharFilter(lookup_expr='icontains')
    sender = django_filters.CharFilter(
        name='created_by__username', lookup_expr='icontains')

    class Meta:
        model = QuickMessage
        exclude = ['timerange', 'opportunity_status']
