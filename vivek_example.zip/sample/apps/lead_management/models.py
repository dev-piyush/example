# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
from framework.models import BaseModel
from framework.enums import STATUS_CHOICES
from account_master.models import Department


class QuickMessage(BaseModel):
    """docstring for Billing"""

    text = models.TextField()
    opportunity_status = models.CharField(
        max_length=100, choices=STATUS_CHOICES, default='Hot')
    received_date = models.DateField(null=True, blank=True)
    received_from = models.CharField(max_length=100, null=True, blank=True)
    department = models.ForeignKey(
        Department, related_name='messages', null=True, blank=True)
    request_title = models.CharField(max_length=100, null=True, blank=True)

    def __str__(self):
        return(self.text)

    class Meta:
        ordering = ['-created_on']
        db_table = 'demand_tracker_quickmessage'
