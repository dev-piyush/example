from django.conf.urls import url
from .views import *
urlpatterns = [

    url(r'^quick_messages/$', QuickMessageList.as_view(), name='quick_message_list'),
    url(r'^quick_messages_create/$', QuickMessageCreate.as_view(),
        name='quick_message_create'),
    url(r'^quick_messages_update/(?P<pk>\d+)/$',
        QuickMessageUpdate.as_view(), name='quick_message_update'),
    url(r'^quick_messages_delete/(?P<pk>\d+)/$',
        QuickMessageDelete.as_view(), name='quick_message_delete')

]
