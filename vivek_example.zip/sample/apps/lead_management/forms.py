from django import forms
from .models import *
from framework.forms import BaseModelForm


class QuickMessageForm(BaseModelForm):
    received_date = forms.DateField(required=False,
                                    widget=forms.TextInput(
                                        attrs={'class': 'datepicker_field'}))

    class Meta:
        model = QuickMessage
        exclude = ['deleted', 'created_on', 'created_by', 'remarks',
                   'last_moddified_on', 'last_moddified_by', 'version']
