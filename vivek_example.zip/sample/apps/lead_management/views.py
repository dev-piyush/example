from framework.views import BaseListView, LoginRequiredView
from .models import QuickMessage
from django.views.generic.edit import CreateView
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from .forms import QuickMessageForm
from django.urls import reverse_lazy
from django.http import HttpResponseRedirect
from .filters import QuickMessageFilter


class QuickMessageList(BaseListView, LoginRequiredView):
    model = QuickMessage
    filter_class = QuickMessageFilter


class QuickMessageCreate(CreateView, LoginRequiredView):
    model = QuickMessage
    form_class = QuickMessageForm
    success_url = reverse_lazy('quick_message_list')

    def post(self, request, **kwargs):
        self.object = None
        form = QuickMessageForm(request.POST)
        if 'advanced' in request.POST:
            self.success_url = reverse_lazy('quick_message_create')
        if form.is_valid():
            self.form_valid(form, request)
        else:
            return super(QuickMessageCreate, self).form_invalid(form)
        return HttpResponseRedirect(self.success_url)

    def form_valid(self, form, request):
        msz = form.save()
        msz.created_by = request.user
        msz.save()


class QuickMessageUpdate(UpdateView, LoginRequiredView):
    model = QuickMessage
    form_class = QuickMessageForm
    template_name_suffix = '_update_form'
    success_url = reverse_lazy('quick_message_list')


class QuickMessageDelete(DeleteView, LoginRequiredView):
    model = QuickMessage
    success_url = reverse_lazy('quick_message_list')
    success_url = reverse_lazy('quick_message_list')
