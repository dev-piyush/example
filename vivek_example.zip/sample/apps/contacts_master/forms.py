
from .models import *
from framework.forms import BaseModelForm


class ContactForm(BaseModelForm):

    class Meta:
        model = Contact
        exclude = ['deleted', 'created_on', 'created_by', 'remarks',
                   'last_moddified_on', 'last_moddified_by', 'version']
