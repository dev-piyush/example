from django.db import models
from .contact_methods import ContactMethods
from framework.querysets import BaseQueryset

class ContactQueryset(BaseQueryset, ContactMethods):
    pass


    
