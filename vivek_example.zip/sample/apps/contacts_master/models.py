from __future__ import unicode_literals

from django.db import models
from .manager import ContactManager

# Create your models here.
from framework.models import BaseModel


class Contact(BaseModel):
    """docstring for Billing"""

    name = models.CharField(
        max_length=100, null=False, blank=False)
    contact_number = models.CharField(
        max_length=100, null=False, blank=False)
    email = models.EmailField(null=False, blank=False)
    company_name = models.CharField(
        max_length=100, null=True, blank=True)
    objects = ContactManager()

    def __str__(self):
        return(self.name)

    class Meta:
        ordering = ['-created_on']
