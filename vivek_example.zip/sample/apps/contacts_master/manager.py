from .querysets import ContactQueryset
from framework.manager import BaseManager
from .contact_methods import ContactMethods


class ContactManager(BaseManager, ContactMethods):
    queryset = ContactQueryset
    

