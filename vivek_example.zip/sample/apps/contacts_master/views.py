from framework.views import BaseListView, LoginRequiredView
from .models import Contact
from django.views.generic.edit import CreateView
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from .forms import ContactForm
from django.urls import reverse_lazy
from django.http import HttpResponseRedirect


class ContactList(BaseListView, LoginRequiredView):
    model = Contact


class ContactCreate(CreateView, LoginRequiredView):
    model = Contact
    form_class = ContactForm
    success_url = reverse_lazy('contacts_list')

    def post(self, request):
        self.object = None

        form = ContactForm(request.POST)
        if form.is_valid():
            self.form_valid(form, request)
            return HttpResponseRedirect(reverse_lazy('contacts_list'))
        else:
            return self.form_invalid(form)

    def form_valid(self, form, request):
        msz = form.save()

        msz.created_by = request.user
        msz.save()


class ContactUpdate(UpdateView, LoginRequiredView):
    model = Contact
    form_class = ContactForm
    template_name_suffix = '_update_form'
    success_url = reverse_lazy('contacts_list')


class ContactDelete(DeleteView, LoginRequiredView):
    model = Contact
    success_url = reverse_lazy('contacts_list')
