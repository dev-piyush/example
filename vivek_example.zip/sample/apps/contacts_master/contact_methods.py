
class ContactMethods(object):
    def all(self):
        return self.filter(deleted=False)

    def getRequestorMail(self, name):
        return self.filter(name=name).latest('created_on').email