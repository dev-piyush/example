from django.conf.urls import url
from .views import *
urlpatterns = [

    url(r'^contacts_master/$', ContactList.as_view(),
        name='contacts_list'),
    url(r'^contacts_create/$', ContactCreate.as_view(),
        name='contacts_create'),
    url(r'^contacts_update/(?P<pk>\d+)/$',
        ContactUpdate.as_view(), name='contacts_update'),
    url(r'^contacts_delete/(?P<pk>\d+)/$',
        ContactDelete.as_view(), name='contacts_delete')

]
