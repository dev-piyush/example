
import django_filters
from .models import Contact


class ResourceFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(lookup_expr='icontains')
    email = django_filters.CharFilter(lookup_expr='icontains')
    contact_number = django_filters.CharFilter(lookup_expr='icontains')

    class Meta:
        model = Contact
        fields = ['name', 'email', 'contact_number']
