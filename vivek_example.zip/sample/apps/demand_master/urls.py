from django.conf.urls import url
from .views import *
urlpatterns = [
    url(r'^tag_demand_to_sow/$',
        tag_demand_to_sow, name='tag_demand_to_sow'),
    url(r'^untag_demand_from_sow/$',
        untag_demand_from_sow, name='untag_demand_from_sow'),    
    url(r'^resource_requests/$', RequisitionList.as_view(),
        name='resource_requests_list'),
    url(r'^resource_requests_create/$', RequisitionCreate.as_view(),
        name='resource_requests_create'),
    url(r'^resource_requests_update/(?P<pk>\d+)/$',
        RequisitionUpdate.as_view(), name='resource_requests_update'),
    url(r'^resource_requests_delete/(?P<pk>\d+)/$',
        RequisitionDelete.as_view(), name='resource_requests_delete'),

]
