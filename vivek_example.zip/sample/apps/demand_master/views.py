from django.http import HttpResponseRedirect
from framework.views import BaseListView, LoginRequiredView
from .models import *
from .forms import *
from django.views.generic.edit import CreateView
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from django.urls import reverse_lazy
from .filters import ResourceRequestFilter
from sow_master.models import SOW
from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from account_master.models import SPOC
from framework.enums import *


class RequisitionList(BaseListView, LoginRequiredView):
    model = ResourceRequest
    filter_class = ResourceRequestFilter

    def get_context_data(self, *args, **kwargs):
            # Call the base implementation first to get a context
        context = super(RequisitionList, self).get_context_data(
            *args, **kwargs)
        # add whatever to your context:
        print reverse_lazy('tag_demand_to_sow')
        context['tag_demand_to_sow'] = reverse_lazy('tag_demand_to_sow')
        context['untag_demand_from_sow'] = reverse_lazy('untag_demand_from_sow')
        print "untag_demand_from_sow" ,reverse_lazy('untag_demand_from_sow')
        context['spocs'] = SPOC.objects.all()
        context['demand_status_options'] = get_keys(DEMAND_STATUS_TYPE_CHOICES)
        return context


class RequisitionCreate(CreateView, LoginRequiredView):
    model = ResourceRequest
    form_class = RequisitionForm
    success_url = reverse_lazy('resource_requests_list')

    def post(self, request):
        self.object = None
        sow_id = request.POST.get("SOW_number", "")
        po_id = request.POST.get("PO_number", "")
        if 'advanced' in request.POST:
            self.success_url = reverse_lazy('resource_requests_create')
        form = RequisitionForm(request.POST)
        if form.is_valid():
            self.form_valid(form, sow_id, po_id)
            return HttpResponseRedirect(self.get_success_url())
        else:
            return self.form_invalid(form)

    def form_invalid(self, form):
        print "form is invalid"
        return self.render_to_response(
            self.get_context_data(form=form,
                                  ))

    def form_valid(self, form, sow_id_input, po_id_input):
        params = self.request.POST
        form.instance.requisition_id = str(params.get("RR", "")) + str(
            params.get("job_code", "")) + str(params.get("requestor", ""))
        self.object = resource_request = form.save()
        index = 1
        for i in range(resource_request.quantity - 1):
            drr = ResourceRequest()
            drr.project_name = resource_request.project_name
            drr.project_id = resource_request.project_id
            drr.RR = None
            drr.technology = resource_request.technology
            drr.tech_skills = resource_request.tech_skills
            drr.requisition_id = resource_request.requisition_id
            drr.requisition_index = index = index + 1
            drr.job_code = None
            drr.department = resource_request.department
            drr.sub_department = resource_request.sub_department
            drr.requestor = resource_request.requestor
            drr.synechron_contact = resource_request.synechron_contact
            drr.hiring_manager = resource_request.hiring_manager
            drr.location = resource_request.location
            drr.request_receive_date = resource_request.request_receive_date
            drr.demand_status = resource_request.demand_status
            drr.SPOC = resource_request.SPOC
            drr.quantity = resource_request.quantity
            drr.job_description = resource_request.job_description
            drr.save()
        return HttpResponseRedirect(self.get_success_url())


class RequisitionUpdate(UpdateView, LoginRequiredView):

    model = ResourceRequest
    form_class = RequisitionUpdateForm
    template_name_suffix = '_update_form'

    def get_success_url(self):
        return reverse_lazy('resource_requests_list')

    def get_initial(self):
        return {'sow_id': self.object.get_sow()}

    def post(self, request, **kwargs):
        self.object = self.get_object()
        form = RequisitionUpdateForm(request.POST, instance=self.object)

        if form.is_valid():

            return self.form_valid(form)

        else:
            return self.form_invalid(form)

    # def form_valid(self, form):
    #     form.save()
    #     # sow_id = self.request.POST.get("sow_id", None)
    #     # # if sow_id is not None and sow_id:
    #     # #     if SOW.objects.filter(SOW_ID=sow_id).exists():
    #     # #         sow = SOW.objects.get(SOW_ID=sow_id)
    #     # #         for s in sow: 
    #     # #             drr.add_demand_to_sow(s)
    #     # #             s.resource_requests.add(self.object)
    #     # #             s.save()
    #     # # else:
    #     # #     if self.object.get_sow() is not None:
    #     # #         sow = self.object.get_sow()
    #     # #         sow.resource_requests.remove(self.object)
    #     # #         sow.save()

    #     return HttpResponseRedirect(form.data['referer'])

    def form_invalid(self, form):
        return self.render_to_response(
            self.get_context_data(form=form,
                                  ))

    # def get_form(self):
    #     """
    #     Returns an instance of the form to be used in this view.
    #     """
    #     form = self.form_class(**self.get_form_kwargs())
    #     if self.object.get_sow() is not None:
    #         form.fields["sow_id"].initial = self.object.get_sow().SOW_ID
    #     return form


class RequisitionDelete(DeleteView, LoginRequiredView):
    model = ResourceRequest
    success_url = reverse_lazy('resource_requests_list')


@csrf_exempt
def tag_demand_to_sow(request):
    sow_id = request.POST.get("SOW_number", None)
    demand_id = request.POST.get("demand_id", None)
    try:
        sow = SOW.objects.filter(SOW_ID=sow_id)
        if sow.count() > 0 :
            rr = ResourceRequest.objects.get(pk=demand_id)
            for s in sow:
                        s.resource_requests.add(rr)
                        s.save()

            
            data = {
                'code':'201',
                'message': 'Demand has been added to SOW : ' + sow_id
            }
        else:
            data = {
                'message': 'No Sow Found with ID : ' + sow_id
            }
        return JsonResponse(data, safe=False)
    except:
        data = {
            'message': 'Could Not  add to SOW : ' + sow_id
        }
    return JsonResponse(data, safe=False)

@csrf_exempt
def untag_demand_from_sow(request):
    sow_id = request.POST.get("SOW_number", None)
    demand_id = request.POST.get("demand_id", None)
    try:
        sow = SOW.objects.filter(SOW_ID=sow_id)
        rr = ResourceRequest.objects.get(pk=demand_id)
        for s in sow:
                    s.resource_requests.remove(rr)
                    s.save()

        
        data = {
            'message': 'Demand has been Removed from SOW : ' + sow_id
        }
        return JsonResponse(data, safe=False)
    except:
        data = {
            'message': 'Could Not  Removed from SOW : ' + sow_id
        }
    return JsonResponse(data, safe=False)
