
import django_filters
from .models import ResourceRequest
from framework.filters import ListFilter


class ResourceRequestFilter(django_filters.FilterSet):
    requestor = django_filters.CharFilter(lookup_expr='icontains')
    RR = django_filters.CharFilter(lookup_expr='icontains')
    job_code = django_filters.CharFilter(lookup_expr='icontains')
    demand_status = ListFilter(name='demand_status')
    department = ListFilter(name='department__name')
    technology = django_filters.CharFilter(
        name='technology__name', lookup_expr='icontains')
    synechron_contact = django_filters.CharFilter(lookup_expr='icontains')
    spoc = django_filters.CharFilter(
        name='SPOC__name')

    class Meta:
        model = ResourceRequest
        fields = ['RR', 'job_code', 'requestor']
