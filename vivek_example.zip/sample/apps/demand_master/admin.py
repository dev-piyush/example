from django.contrib import admin

# Register your models here.
from .models import *
from framework.admin import BaseAdmin


class ResourceRequestAdmin(BaseAdmin):

    list_filter = ('requestor', 'location', 'technology')


admin.site.register(ResourceRequest, ResourceRequestAdmin)
