# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from framework.models import BaseModel
from framework.enums import *
from skill_master.models import Skill
from account_master.models import Department, SubDepartment, SPOC
from location_master.models import Location
from .querysets import ResourceRequestQueryset
from .manager import ResourceRequestManager


class ResourceRequest(BaseModel):
    """docstring for Resource Request"""
    project_name = models.CharField(max_length=100, null=True, blank=True)
    project_id = models.CharField(max_length=100, null=True, blank=True)
    RR = models.CharField(max_length=100, null=True, blank=True)
    requisition_id = models.CharField(max_length=100, null=True, blank=True)
    requisition_index = models.IntegerField(default=1)
    job_code = models.CharField(max_length=100, null=True, blank=True)
    technology = models.ForeignKey(Skill, blank=True)
    tech_skills = models.CharField(max_length=100)
    job_description = models.TextField(null=True, blank=True)
    department = models.ForeignKey(Department, related_name='demands')
    sub_department = models.ForeignKey(SubDepartment, related_name='demands')
    requestor = models.CharField(max_length=100)
    hiring_manager = models.CharField(max_length=100, null=True, blank=True)
    client_group_head = models.CharField(max_length=100, null=True, blank=True)
    synechron_contact = models.CharField(max_length=100, null=True, blank=True)
    SPOC = models.ForeignKey(SPOC, related_name='demands')
    location = models.ForeignKey(Location, related_name='demands')
    request_receive_date = models.DateField()
    demand_status = models.CharField(
        max_length=100, choices=DEMAND_STATUS_TYPE_CHOICES,
        default='Yet to Propose')

    quantity = models.IntegerField(default=1)
    request_closing_date = models.DateField(null=True, blank=True)
    objects = ResourceRequestManager()
    remarks = models.TextField(null=True, blank=True)

    def age(self):
        from datetime import datetime
        now = datetime.now().date()
        if self.request_receive_date is not None:
            days = (now - self.request_receive_date).days
        else:
            days = "NA"
        return days

    def demand_name(self):
        return '%s-%s-%s-%s-%s-%s' % (self.RR,
                                      self.job_code, self.requestor,
                                      self.requisition_index,
                                      self.demand_status, self.tech_skills)

    def __str__(self):
        current_selected_resource = self.current_selected_resource()
        if current_selected_resource is not None:
            employee_name = current_selected_resource.employee_name
            return '%s-%s-%s-%s-%s-%s-%s' % (self.RR,
                                             self.job_code,
                                             self.requestor,
                                             employee_name,
                                             self.requisition_index,
                                             self.demand_status,
                                             self.tech_skills,
                                             )

        return '%s-%s-%s-%s-%s' % (self.RR,
                                   self.job_code,
                                   self.requestor,
                                   self.demand_status,
                                   self.tech_skills)

    def profiles_sent_to_client(self):
        return self.candidatures

    def current_selected_candidature(self):
        if self.candidatures.selected().count() > 0:
            return self.candidatures.selected()[0]
        return None

    def current_selected_resource(self):
        if self.current_selected_candidature() is not None:
            out = self.current_selected_candidature().resource
            return out

    def last_released_candidatures(self):
        if self.candidatures.released().count() > 0:
            out = self.candidatures.released()[0]
            return out

    def mark_on_hold(self):
        self.get_current_selected_resource.update(
            selection_status='On Hold')

    def get_sow(self):
        if(self.sows.count() > 0):
            return self.sows.latest('created_on')
        return None

    class Meta:
        ordering = ['-created_on']
        db_table = 'demand_tracker_resourcerequest'
