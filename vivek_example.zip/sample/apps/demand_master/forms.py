from django import forms
from .models import *
from account_master.models import SPOC
from framework.enums import *
from framework.forms import BaseModelForm


class RequisitionForm(BaseModelForm):
    request_receive_date = forms.DateField(
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    # SOW_number = forms.CharField(required=False, label='SOW Number')
    # PO_number = forms.CharField(required=False, label='PO Number')
    quantity = forms.CharField(
        required=False, label='No of Positions', initial=1)
    project_id = forms.CharField(required=False, label='Project ID')
    requestor = forms.CharField(required=True, label='Client Requestor')
    SPOC = forms.ModelChoiceField(
        SPOC.objects.all(), label='Synechron Group Head')

    class Meta:
        model = ResourceRequest
        exclude = ['created_on', 'request_closing_date',
                   'deleted', 'requisition_id',
                   'requisition_index', 'created_on', 'created_by',
                   'last_moddified_on',
                   'last_moddified_by', 'version']


class RequisitionUpdateForm(BaseModelForm):
    request_receive_date = forms.DateField(
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    # sow_id = forms.CharField(required=False)

    class Meta:
        model = ResourceRequest
        exclude = ['request_closing_date', 'quantity', 'deleted',
                   'requisition_id', 'requisition_index',
                   'created_on', 'created_by', 'last_moddified_on',
                   'last_moddified_by', 'version']
