from django.db import models
from django.db.models import Count
from django.db.models import Q

class DataMethods(object):
    def open(self):
        return self.filter(demand_status__in=['Yet to Propose', 'In Progress',
                                              'Not in Consideration',
                                              'Rejected','Profile Submitted'])


    def selected(self):
        return self.filter(demand_status__in=['Selected'])

    def untagged(self, sow=None):
        if sow is None:
            return self.annotate(num_sows=Count('sows')).filter(num_sows=0)

        return self.annotate(num_sows=Count('sows')).filter(
            Q(sows__in=[sow]) | Q(num_sows=0))

    def in_progress(self):
        return self.filter(demand_status__in=['In Progress'])

    def released(self):
        return self.filter(demand_status__in=['Released'])

    def all(self):
        return self.filter(deleted=False)