from .querysets import ResourceRequestQueryset
from framework.manager import BaseManager
from .data_methods import DataMethods


class ResourceRequestManager(BaseManager, DataMethods):
    queryset = ResourceRequestQueryset

