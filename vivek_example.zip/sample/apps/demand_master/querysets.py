from django.db import models
from django.db.models import Count
from django.db.models import Q
from framework.querysets import BaseQueryset
from .data_methods import DataMethods

class ResourceRequestQueryset(BaseQueryset, DataMethods):
      pass
