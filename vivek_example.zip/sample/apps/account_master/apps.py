from django.apps import AppConfig


class AccountMasterConfig(AppConfig):
    name = 'account_master'
