from django.contrib import admin

# Register your models here.
from .models import *
from framework.admin import BaseAdmin


admin.site.register(Account, BaseAdmin)
admin.site.register(Department, BaseAdmin)
admin.site.register(SubDepartment, BaseAdmin)
admin.site.register(SPOC, BaseAdmin)
admin.site.register(TelephonicBridge, BaseAdmin)
