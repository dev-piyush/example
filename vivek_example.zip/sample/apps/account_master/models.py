from django.db import models
from framework.models import BaseModel


class Account(BaseModel):
    """The summary line for a class docstring should fit on one line.

    If the class has public attributes, they may be documented here
    in an ``Attributes`` section and follow the same formatting as a
    function's ``Args`` section. Alternatively, attributes may be documented
    inline with the attribute's declaration (see __init__ method below).

    Properties created with the ``@property`` decorator should be documented
    in the property's getter method.

    Attributes:
        attr1 (str): Description of `attr1`.
        attr2 (:obj:`int`, optional): Description of `attr2`.

    """

    name = models.CharField(max_length=100)
    enable_for_shift_allowance = models.BooleanField()
    enable_for_sow_master = models.BooleanField()
    enable_for_resource_master = models.BooleanField()
    enable_for_expense_master = models.BooleanField()

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']


class Department(BaseModel):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']


class SubDepartment(BaseModel):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']


class SPOC(BaseModel):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['name']


class TelephonicBridge(BaseModel):
    bridgeName = models.CharField(max_length=20)
    moderator_code = models.CharField(max_length=20)
    passcode = models.CharField(max_length=20)

    def __str__(self):
        return self.bridgeName

    class Meta:
        ordering = ['bridgeName']
