# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from tasks import SendInviteForQuestionnaire
from django.http import HttpResponse
# Create your views here.

def schedule_task(request):
	SendInviteForQuestionnaire.delay(user)
	return HttpResponse("Invite Send!!")