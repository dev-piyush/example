
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from celery.task import Task
from django.core.mail import EmailMultiAlternatives


class SendInviteForQuestionnaire(Task):

    def run(self, user):
        subject, from_email, to = "Welcome", "pug555102@gmail.com", user.from_email

        html_content = render_to_string("send_invite_questionnaire.html", {
                                        'user': user.employee_name})
        text_content = strip_tags(html_content)
        msg = EmailMultiAlternatives(subject, text_content, from_email, to)
        msg.attach_alternatives(html_content, "text/html")
        msg.send()
