from django.conf.urls import url
from office365_calendar import views

urlpatterns = [

    # Redirect to get token ('/tutorial/gettoken/')
    url(r'^gettoken/$', views.gettoken, name='gettoken'),
    url(r'^create_event_with_attachment/(?P<pk>\d+)$',
        views.create_event_with_Attachment,
        name='create_event_with_Attacment'),
]
