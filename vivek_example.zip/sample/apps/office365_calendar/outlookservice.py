import requests
import uuid
import json
import os
outlook_api_endpoint = 'https://outlook.office.com/api/v2.0{0}'


def post_my_events(access_token, mail_sub, mail_body, interview_date, interview_end_time, location):
    post_events_url = outlook_api_endpoint.format('/me/events')

    payload = {
        "Subject": mail_sub,
        "Body": {
            "ContentType": "HTML",
            "Content": mail_body
        },
        "End": {
            "DateTime": interview_end_time,
            "TimeZone": "Asia/Kolkata"
        },
        "Start": {
            "DateTime": interview_date,
            "TimeZone": "Asia/Kolkata"
        },

        "Location": {
            "DisplayName": location,
            "Address": None
        },
    }

    r = make_api_call('POST', post_events_url, access_token, payload)

    if (r.status_code == requests.codes.ok):
        return r.json()
    else:
        return "{0}: {1}".format(r.status_code, json.loads(r._content)['Id'])


def create_my_events(access_token):
    post_events_url = outlook_api_endpoint.format('/me/events')
    r = make_api_call('POST', post_events_url, access_token)
    if (r.status_code == requests.codes.ok):
        return r.json()
    else:
        return "{0}: {1}".format(r.status_code, json.loads(r._content)['Id'])


def create_attchment_to_my_events(access_token, event_id, resume_file):

    post_events_url = outlook_api_endpoint.format(
        '/me/events/'+event_id+'/attachments')

    with open(resume_file, "r") as f:
        content = f.read()
    payload = {
        "@odata.type": "#Microsoft.OutlookServices.FileAttachment",
        "Name": os.path.basename(resume_file),
        "ContentBytes": content.encode('base64')
    }
    response = make_api_call('POST', post_events_url, access_token, payload)
    if (response.status_code == requests.codes.ok):
        return response.json()
    else:
        return "{0}: {1}".format(response.status_code, response.text)


def send_email(access_token, html_content, subject, recipients):
    post_mail_url = outlook_api_endpoint.format('/me/sendmail')
    payload = {
        "Message": {
            "Subject": subject,
            "Body": {
                "ContentType": "HTML",
                "Content": html_content
            },

        },
        "SaveToSentItems": "true"
    }
    recipients_list = []
    for recipient in recipients:
        recipients_list.append({

            "EmailAddress": {
                "Address": recipient
            }
        }
        )
    payload["Message"]["ToRecipients"] = recipients_list
    response = make_api_call('POST', post_mail_url, access_token, payload)
    if (response.status_code == requests.codes.ok):
        return response.json()
    else:
        return "{0}: {1}".format(response.status_code, response.text)


def update_my_events(access_token, eventId, mail_body, to_email_string, cc_email_string):

    patch_events_url = outlook_api_endpoint.format('/me/events/'+eventId)

    Attendees = []
    for email in to_email_string:
        Attendedence = {"Type": "Required",
                        "EmailAddress": {'Name': email.split('@')[0].split('.')[0], "Address": email}}
        json_string = json.dumps(Attendedence)
        Attendees.append(Attendedence)

    for email in cc_email_string:
        Attendedence = {"Type": "Optional",
                        "EmailAddress": {'Name': email.split('@')[0].split('.')[0], "Address": email}}
        Attendees.append(Attendedence)
            
    payload = {
        "Body": {
            "ContentType": "HTML",
            "Content": mail_body
        },
        "Attendees": Attendees
    }

    response = make_api_call('PATCH', patch_events_url, access_token, payload)
    print response.status_code
    if (response.status_code == requests.codes.ok):
        return response.json()
    else:
        return "{0}: {1}".format(response.status_code, response.text)


def get_my_contacts(access_token):
    get_contacts_url = outlook_api_endpoint.format('/Me/Contacts')

    # Use OData query parameters to control the results
    #  - Only first 10 results returned
    #  - Only return the GivenName, Surname, and EmailAddresses fields
    #  - Sort the results by the GivenName field in ascending order
    query_parameters = {'$top': '10',
                        '$select': 'GivenName,Surname,EmailAddresses',
                        '$orderby': 'GivenName ASC'}

    r = make_api_call('GET', get_contacts_url, access_token,
                      parameters=query_parameters)

    if (r.status_code == requests.codes.ok):
        return r.status_code

    else:
        response = "{0}: {1}".format(r.status_code, r.text)
        return response
# Generic API Sending


def make_api_call(method, url, token, payloadData, parameters=None):
    # Send these headers with all API calls
    headers = {'User-Agent': 'django-tutorial/1.0',
               'Authorization': 'Bearer {0}'.format(token),
               'Accept': 'application/json'}

    # Use these headers to instrument calls. Makes it easier
    # to correlate requests and responses in case of problems
    # and is a recommended best practice.
    request_id = str(uuid.uuid4())
    instrumentation = {'client-request-id': request_id,
                       'return-client-request-id': 'true'}

    headers.update(instrumentation)

    response = None

    payload = {
        "Subject": "Discuss the Calendar REST API",
        "Body": {
            "ContentType": "HTML",
            "Content": "I think it will meet our requirements!"
        },
        "Start": {
            "DateTime": "2020-04-14T18:00:00",
            "TimeZone": "Pacific Standard Time"
        },
        "End": {
            "DateTime": "2022-04-04T19:00:00",
            "TimeZone": "Pacific Standard Time"
        },
        "Location": {
            "DisplayName": "PUNE",
            "Address": None
        },
        # "Attendees": [
        #   {
        #     "EmailAddress": {
        #       "Address": "Piyush.raj@synechron.com",
        #      "Name": "Janet Schorr"
        #     },
        #     "Type": "Required"
        #   }
        #  ]
    }

    if (method.upper() == 'GET'):
        response = requests.get(url, headers=headers,
                                params=parameters, verify=False)
    elif (method.upper() == 'DELETE'):
        response = requests.delete(
            url, headers=headers, params=parameters, verify=False)
    elif (method.upper() == 'PATCH'):
        headers.update({'Content-Type': 'application/json'})
        response = requests.patch(url, headers=headers, data=json.dumps(
            payloadData), params=parameters, verify=False)
    elif (method.upper() == 'POST'):
        headers.update({'Content-Type': 'application/json'})
        response = requests.post(url, headers=headers, data=json.dumps(
            payloadData), params=parameters, verify=False)

    return response


def get_my_messages(access_token):
    get_messages_url = outlook_api_endpoint.format('/me/messages')

    # Use OData query parameters to control the results
    #  - Only first 10 results returned
    #  - Only return the ReceivedDateTime, Subject, and From fields
    #  - Sort the results by the ReceivedDateTime field in descending order
    query_parameters = {'$top': '10',
                        '$select': 'ReceivedDateTime,Subject,From',
                        '$orderby': 'ReceivedDateTime DESC'}

    r = make_api_call('GET', get_messages_url, access_token,
                      parameters=query_parameters)

    if (r.status_code == requests.codes.ok):
        return r.json()
    else:
        return "{0}: {1}".format(r.status_code, r.text)


def get_my_events(access_token):
    get_events_url = outlook_api_endpoint.format('/Me/Events')

    # Use OData query parameters to control the results
    #  - Only first 10 results returned
    #  - Only return the Subject, Start, and End fields
    #  - Sort the results by the Start field in ascending order
    query_parameters = {'$top': '10',
                        '$select': 'Subject,Start,End',
                        '$orderby': 'Start/DateTime ASC'}

    r = make_api_call('GET', get_events_url, access_token,
                      parameters=query_parameters)

    if (r.status_code == requests.codes.ok):
        return r.json()
    else:
        return "{0}: {1}".format(r.status_code, r.text)
