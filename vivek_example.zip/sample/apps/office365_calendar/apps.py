# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class Office365CalendarConfig(AppConfig):
    name = 'office365_calendar'
