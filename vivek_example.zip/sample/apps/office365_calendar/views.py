from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from django.core.urlresolvers import reverse
from office365_calendar.authhelper import *
from office365_calendar.outlookservice import *
from contacts_master.models import Contact
from candidature_master.models import Candidature
from account_master.models import TelephonicBridge
from user_management.models import Profile as UserProfile
from django.template import loader
from django.conf import settings
from datetime import timedelta
from datetime import datetime
import pytz
from office365_calendar.utility import isValidEmail
import logging
# Get an instance of a logger
logger = logging.getLogger('info')


def gettoken(request):

    auth_code = request.GET['code']
    redirect_uri = request.build_absolute_uri(reverse('gettoken'))
    token = get_token_from_code(auth_code, redirect_uri)

    userprofile = UserProfile.objects.get(user=request.user)
    userprofile.save_access_token(token)
    return HttpResponseRedirect(reverse("dashboard"))

#create_event_with_attachment()
def create_event_with_Attachment(request, pk):
    userprofile = UserProfile.objects.get(user=request.user)
    access_token = userprofile.get_outlook_access_token()
    mailTpye = request.GET.get('mailType', None)
    passcode = request.GET.get('passcode', None)
    additional_receipts = request.GET.get('additional_receipts', "None")
    additional_receipts = additional_receipts.split(",")
    valid_additional_receipts = []
    for receipt in additional_receipts:
        if isValidEmail(receipt.lstrip().rstrip()):
            valid_additional_receipts.append(receipt.lstrip().rstrip())
    candidature_ID = pk
    candidature = Candidature.objects.get(pk=pk)
    requestors = candidature.resource_request.requestor.split(',')    
    user = request.user
    to_email_string = []
    for req in requestors:
        try:
            to_email_string.append(
                Contact.objects.getRequestorMail(name=req.strip()))
        except:
            break
            return HttpResponse("""Please Check all Requestors mail_id in Contact Book.
                """, status=404)

    if candidature.resource.email is None:
        return HttpResponse("Please Check Resource mail_id .", status=404)

    send_event_with_Attachment(
          user, candidature_ID, mailTpye, access_token,valid_additional_receipts, passcode)
    return HttpResponse("OK", status=200)


def send_event_with_Attachment(user, candidature_id, mail_type,
                               access_token, valid_additional_receipts, passcode=None):

    candidature = Candidature.objects.get(pk=candidature_id)
    requestors = candidature.resource_request.requestor.split(',')
    requestors_names = []
    for requestors_name in requestors:
        requestors_names.append(
            requestors_name.lower().title().lstrip().split(' ')[0])
    to_email_string = []

    if settings.SEND_EMAIL_TO_TEST_USER is False:
        for req in requestors:
            to_email_string.append(
                Contact.objects.getRequestorMail(name=req.strip()))
        resource_mailId = candidature.resource.email
        to_email_string.append(resource_mailId)
    else:
        to_email_string.append(settings.DUMMY_EMAIL_FOR_TESTING)
    
    cc_email_string=[]
    cc_email_string = cc_email_string+settings.COMMON_MAIL_LIST
    
    cc_email_string = cc_email_string+valid_additional_receipts

    mail_signature = UserProfile.objects.get(user=user).email_signature
    utc_interview_date = str(candidature.get_interview_date().strftime('%Y-%m-%d %H:%M'))
    localtimezone=pytz.timezone("Asia/Calcutta")
    interview_date_itc=candidature.get_interview_date().replace(tzinfo=pytz.utc).astimezone(localtimezone)
    interview_date=str(interview_date_itc.strftime('%Y-%m-%d %H:%M'))
    interview_end_time = format(
        interview_date_itc + timedelta(hours=1), '%Y-%m-%d %H:%M')
    resource_contact_no = candidature.resource.contact_number

    resume_file = candidature.resource.resume.url
    #context=candidature.get_mail_context(mail_type)

    if mail_type == "faceToface":
        mail_sub = "F2F Synechron Interview -"+candidature.resource.employee_name
        location = "HSBC Business Bay -P2 ( Interview Room )"
        template = loader.get_template('office365_calender/faceToface.html')
        context = {
            'requestor': ' / '.join(requestors_names),
            'resource': candidature.resource.employee_name,
            'interview_date': interview_date,
            'contact_no': resource_contact_no,
            'mail_signature': mail_signature,
        }
        mail_body = template.render(context)

    elif mail_type == "telephonic":
        mail_sub = "T1 Synechron Interview -"+candidature.resource.employee_name
        location = "Telephonic Interview "
        template = loader.get_template('office365_calender/telephonic.html')
        context = {
            'requestor': ' / '.join(requestors_names),
            'resource': candidature.resource.employee_name,
            'interview_date': interview_date,
            'contact_no': resource_contact_no,
            'mail_signature': mail_signature,
        }
        mail_body = template.render(context)

    elif mail_type == "telOverBridge":
        passcode = passcode
        moderator_code = TelephonicBridge.objects.get(
            passcode=passcode+'#').moderator_code
        mail_sub = "T1 Synechron Interview -"+candidature.resource.employee_name
        location = "Telephonic Interview "
        template = loader.get_template('office365_calender/telOverBridge.html')
        context = {
            'requestor': ' / '.join(requestors_names),
            'resource': candidature.resource.employee_name,
            'interview_date': interview_date,
            'contact_no': resource_contact_no,
            'passcode': passcode+'#',
            'moderator_code': moderator_code,
            'mail_signature': mail_signature,
        }
        mail_body = template.render(context)

    post_event_results = post_my_events(
        access_token, mail_sub, mail_body,
        interview_date, interview_end_time, location)

    status_code = post_event_results.split(':')[0]
    event_id = post_event_results.split(':')[1]

    if status_code == '201':
        create_attch = create_attchment_to_my_events(
            access_token, event_id, resume_file)
        atttchment_status_code = create_attch.split(':')[0]
        if atttchment_status_code == '201':
            update_event_result = update_my_events(
                access_token, event_id, mail_body, to_email_string,cc_email_string)
            return HttpResponse(update_event_result)


def post_events(request):
    access_token = userprofile.get_outlook_access_token()
    if not access_token:
        return HttpResponseRedirect(reverse('tutorial:home'))
    else:
        post_event_results = post_my_events(access_token)

        return HttpResponse('Messages: {0}'.format(post_event_results))
