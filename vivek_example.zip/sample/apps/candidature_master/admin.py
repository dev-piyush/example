from django.contrib import admin
from .models import *
from framework.admin import BaseAdmin


class CandidatureAdmin(BaseAdmin):
    list_display = ('resource', 'resource_request')
    list_filter = ('selection_status', 'resource_request')


admin.site.register(Candidature, CandidatureAdmin)
