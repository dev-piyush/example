from django.http import HttpResponseRedirect
from django.http import HttpResponse
from framework.views import BaseListView
from .models import *
from .forms import *
from django.views.generic.edit import CreateView
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from django.urls import reverse_lazy
from .filters import CandidatureFilter
from framework.views import LoginRequiredView
from contacts_master.models import Contact
from user_management.models import Profile as UserProfile
from account_master.models import TelephonicBridge
import os
import json
from office365_calendar.outlookservice import *
from django.contrib.auth.decorators import login_required
from django.template.loader import get_template
from .tasks import *
import datetime
from django.conf import settings
from framework.enums import *
from account_master.models import SPOC

class CandidatureList(BaseListView, LoginRequiredView):
    model = Candidature
    filter_class = CandidatureFilter

    def get_context_data(self, **kwargs):
        context = super(CandidatureList, self).get_context_data(**kwargs)
        context['spocs'] = SPOC.objects.all()
        context['selection_status_options'] = get_keys(SELECTION_TYPE_CHOICES)
        context['onbording_status_options'] = get_keys(ONBOARDING_STATUS_CHOICES)
        
        return context


class CandidatureCreate(CreateView, LoginRequiredView):
    model = Candidature
    form_class = CandidatureForm
    exclude = ('created_on',)
    success_url = reverse_lazy('candidatures_list')

    def get_initial(self):
        initial = super(CandidatureCreate, self).get_initial()
        initial = initial.copy()
        resource_request_id = self.request.GET.get(
            "resource_request__id", None)
        if resource_request_id is not None:
            initial['resource_request'] = ResourceRequest.objects.filter(
                pk=resource_request_id)[0]
        return initial

    def post(self, request, **kwargs):
        self.object = None
        form = CandidatureForm(request.POST)
        if 'advanced' in request.POST:
            self.success_url = reverse_lazy('candidature_create')
        if form.is_valid():
            self.form_valid(form)
        else:
            return super(CandidatureCreate, self).form_invalid(form)
        return HttpResponseRedirect(self.get_success_url())


class CandidatureUpdate(UpdateView, LoginRequiredView):
    model = Candidature
    form_class = CandidatureUpdateForm
    template_name_suffix = '_update_form'
    success_url = reverse_lazy('candidatures_list')

    def get_context_data(self, **kwargs):
        context = super(CandidatureUpdate, self).get_context_data(**kwargs)
        #context['forcast_formSet'] = forcastformSet(instance=self.get_object()) 
        context['remarks'] = self.get_object().remarks
        interview_level=self.get_object().get_interview_status()
        context['interive_level'] = interview_level
        if interview_level == "L1" :
            context['interive_type'] = self.get_object().L1_type
        if interview_level == "L2" :
            context['interive_type'] = self.get_object().L2_type    
        return context

    def get_initial(self):
        initial = super(CandidatureUpdate, self).get_initial()
        try:
            field1 = self.get_object().resource_request
            field2 = self.get_object().resource
        except:
            pass
        else:
            initial['resource_request'] = field1.pk
            initial['resource'] = field2.pk 
        return initial

    def post(self, request, **kwargs):
        self.object = self.get_object()
        if "submit_and_stay" in request.POST :
            self.success_url = request.path_info
            
        remark=request.POST.get("remarks", "")

        form = CandidatureUpdateForm(request.POST, instance=self.object )
        #forcast_form_set = forcastformSet(request.POST , instance=self.object)
        if(form.is_valid()):
            self.form_valid(form,  remark)
            return HttpResponseRedirect(self.success_url)

            # actual_start_date=form.data['actual_start_date']
            # release_date=form.data['release_date']

            # if actual_start_date  and  release_date and forcast_form_set.is_valid() :
            #     self.form_set_valid(form , forcast_form_set , remark)
            #     return HttpResponseRedirect(self.success_url)
            # else :  
                  
        else:
            return super(CandidatureUpdate, self).form_invalid(form)

    def form_valid(self, form , remark):
        self.object.remarks=remark
        self.object.save()


    def form_set_valid(self , form , formset , remark):
        self.object.remarks=remark
        self.object = form.save()
        pre_record=Forcasting.objects.filter(candidature=self.object)
        for record in pre_record:
            record.delete()
        formset.instance=self.object
        for form in formset:
                form.instance.deleted=False

        formset.save()  


class CandidatureDelete(DeleteView, LoginRequiredView):
    model = Candidature
    success_url = reverse_lazy('candidatures_list')


def candidature_detail(request, pk):
    response_data = {}
    error_messages = []
    mailTpye = request.GET.get('mailType', None)
    candidature = Candidature.objects.get(pk=pk)
    requestors = candidature.resource_request.requestor.split(',')
    requestors_names = []
    for requestors_name in requestors:
        requestors_names.append(
            requestors_name.lower().title().lstrip().split(' ')[0])

    requestors_mail = []
    for req in requestors:
        try:
            requestors_mail.append(
                Contact.objects.getRequestorMail(name=req.strip()))
        except:
            error_messages.append(
                "Please Check all Requestors mail_id in Contact Book.")
            break

    response_data['requestors_mail_id'] = requestors_mail
    resource = candidature.resource.employee_name
    response_data['resource_name'] = resource
    if candidature.resource.email is not None:
        response_data['resource_email'] = candidature.resource.email
    else:
        pass
        error_messages.append("Please Check Resource Mail Id.")

    try:
        resume_file = candidature.resource.resume.url
        if os.path.isfile(resume_file) == False:
            error_messages.append("Please Check  Resource Resume.")
    except:
        error_messages.append("Please Check  Resource Resume.")

    interview_date = candidature.get_interview_date() or "NOT AVAIALABLE"
    if interview_date != "NOT AVAIALABLE":
        response_data['interview_date'] = str(
            interview_date.strftime('%Y-%m-%d %H:%M'))
    else:
        error_messages.append(
            "Please Update Interview Date Before Sending Mail.")
    resource_contact_no = candidature.resource.contact_number
    resource_contact_no = resource_contact_no or "NOT AVAIALABLE"
    if resource_contact_no != "NOT AVAIALABLE":
        response_data['resource_contact_no'] = resource_contact_no
    else:
        error_messages.append("Please Check Resorce Contact No.")

    mail_signature = UserProfile.objects.get(user=request.user).email_signature
    
    if not mail_signature :
       error_messages.append("Please Check your mail signature. ") 
        

    htmly = get_template('templated_email/'+mailTpye+'.email')
    context = {
        'requestor': ' / '.join(requestors_names),
        'resource': candidature.resource.employee_name,
        'interview_date': interview_date,
        'contact_no': resource_contact_no,
        'mail_signature': mail_signature,
    }
    
    passcode = request.GET.get('passcode', None)
    if passcode is not None:
        moderator_code = TelephonicBridge.objects.get(
            passcode=passcode+'#').moderator_code
        context['passcode'] = passcode+'#'
        context['moderator_code'] = moderator_code

    html_content = htmly.render(context)

    response_data['responseTepmlate'] = html_content

    if error_messages:
        response_data['error_messages'] = error_messages

    return HttpResponse(
        json.dumps(response_data),
        content_type="application/json"
    )

@login_required(login_url=reverse_lazy('login'))
def send_questionnaire_invite_mail(request, pk):
    from django.http import JsonResponse
    candidature = Candidature.objects.get(pk=pk)
    htmly = get_template('email.html')
    submittion_url=request.build_absolute_uri(
        candidature.get_questionaire_submittion_url())
    context_data = {
         'employee_name': candidature.resource.employee_name,
         'date_for_invite_end': datetime.datetime.now().date(),
         'mail_signature': request.user.profile.email_signature,
         'interview_date': candidature.get_interview_date(),
         'submittion_url': submittion_url}
    html_content = htmly.render(context_data)
    candiadate_email = candidature.resource.email
    dummy_email = settings.DUMMY_EMAIL_FOR_TESTING
    res = None
    if settings.SEND_EMAIL_TO_TEST_USER:
        receiver_mail_id = dummy_email
    else:
        receiver_mail_id = candiadate_email
    if receiver_mail_id is not None or not receiver_mail_id:
        message = "Invite Could not be send to the resource on his/her mail id"
        res = send_email_for_user(request.user.id, html_content, "Questionnaire Invite", [
            dummy_email])
        if res:
            status = "Success"
        else:
            status = "Error"

    message = """Invite sent sucessfully to the resource on his/her mail id """
    data = {
        "status": status,
        "result": str(res),
        "message": '{} {}'.format(message, receiver_mail_id)
    }

    return JsonResponse(data)