# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.

from framework.models import BaseModel
from demand_master.models import ResourceRequest
from resource_master.models import Resource
from framework.enums import *
from datetime import date
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.urls import reverse
from .manager import CandidatureManager


class Candidature(BaseModel):
    resource_request = models.ForeignKey(
        ResourceRequest, related_name='candidatures')
    resource = models.ForeignKey(Resource, related_name='candidatures')
    profile_submittion_date = models.DateField(
        null=True, blank=True, default=date.today)
    interview_date = models.DateTimeField(null=True, blank=True)
    L1_type = models.CharField(
        max_length=100,
        choices=INTERVIEW_TYPE_CHOICES,
        default='TI')
    selection_date = models.DateField(null=True, blank=True)

    selection_status = models.CharField(
        max_length=100,
        choices=SELECTION_TYPE_CHOICES, default='Profile Submitted')
    L2_interview_date = models.DateTimeField(null=True, blank=True)
    L2_type = models.CharField(
        max_length=100,
        choices=INTERVIEW_TYPE_CHOICES, default='TI')

    selection_status_L2 = models.CharField(
        max_length=100,
        choices=SELECTION_TYPE_CHOICES, default='Not Applicable')
    selection_date_L2 = models.DateField(null=True, blank=True)
    selection_role = models.CharField(
        max_length=100, null=True, blank=True)
    on_boarding_kit = models.CharField(
        max_length=10, choices=ONBORDING_KIT_CHOICES, default='NO')
    interviewer = models.CharField(
        max_length=100, null=True, blank=True)
    other_skills_interviewd_on = models.CharField(
        max_length=100, null=True, blank=True)
    onboarding_date = models.DateField(null=True, blank=True)
    onbording_status = models.CharField(
        max_length=100, choices=ONBOARDING_STATUS_CHOICES, default='NO')
    hourly_bill_rate = models.FloatField(default=0.0)
    must_start_date = models.DateField(null=True, blank=True)
    actual_start_date = models.DateField(null=True, blank=True)
    release_date = models.DateField(null=True, blank=True)
    objects = CandidatureManager()
    remarks = models.TextField(null=True, blank=True)
    actual_selection_status = models.CharField(
        max_length=100,
        choices=SELECTION_TYPE_CHOICES, default='Not Applicable')

    class Meta:
        ordering = ['-created_on']
        db_table = 'demand_tracker_candidature'

    def get_selection_date(self):
        if self.selection_date_L2 is not None:
            return self.selection_date_L2
        if self.selection_date is not None:
            return self.selection_date
        return None

    def get_interview_date(self):
        if self.selection_status_L2 == 'Not Applicable':
            return self.interview_date
        return self.L2_interview_date

    def set_selection_status(self):
        if self.selection_status_L2 == 'Not Applicable':
            self.actual_selection_status = self.selection_status
            return
        self.actual_selection_status = self.selection_status_L2

    def get_interview_status(self):
        if self.selection_status_L2 == 'Not Applicable':
            return "L1"
        return "L2"

    def get_questionaire_submittion_url(self):
        return reverse('questionnaire_create',
                       kwargs={'candidature_id': str(self.id)})

    def save(self, *args, **kwargs):
        super(Candidature, self).save(*args, **kwargs)
        self.set_selection_status()

    def __str__(self):
        return '%s-%s-%s-%s' % (self.resource, self.resource_request,
                                self.selection_status,
                                str(self.selection_date))


@receiver(pre_save, sender=Candidature,
          dispatch_uid="update_actual_selection_status")
def update_actual_selection_status(sender, instance, *args, **kwargs):
    instance.set_selection_status()


@receiver(post_save, sender=Candidature,
          dispatch_uid="update_selection_status")
def update_selection_status(sender, instance, **kwargs):
    candidature = instance
    L1 = candidature.selection_status
    L2 = candidature.selection_status_L2
    if (L1 == 'Selected' and (L2 in['Selected', 'Not Applicable'])):
        rr = candidature.resource_request
        if rr.get_sow() is not None:
            candidature.resource.blocked_from = rr.get_sow().start_date
            candidature.resource.blocked_till = rr.get_sow().end_date
        candidature.resource.is_blocked = True
        candidature.resource.save()
        rr.demand_status = 'Selected'
        rr.save()

    if candidature.actual_selection_status in ['In Progress', 'Rejected',
                                               'Drop Out', 'Not in Consideration']:
        rr = candidature.resource_request
        rr.demand_status = 'In Progress'
        rr.save()

    if candidature.onbording_status in ['Closed', 'Released']:
        rr = candidature.resource_request
        candidature.resource.blocked_from = None
        candidature.resource.blocked_till = None
        candidature.resource.is_blocked = False
        candidature.resource.save()
        rr.demand_status = candidature.onbording_status
        rr.save()
    if candidature.actual_selection_status in ['Profile Submitted']:
        rr = candidature.resource_request
        rr.demand_status = 'Profile Submitted'
        rr.save()

# class Forcasting(BaseModel):
#     candidature=models.ForeignKey(Candidature, related_name='candidature')
#     year = models.CharField(max_length=10)
#     days =  models.IntegerField()
#     forcast_value=models.FloatField()
