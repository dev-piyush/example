from django.db import models
from django.db.models import Q


class CandidatureQueryset(models.QuerySet):

    def onboarded(self):
        return self.filter(onbording_status__in=['Yes',
                                                 'Yes'.upper()])

    def released(self, resource_requests=None):
        if resource_requests is None:
            return self.filter(onbording_status__in=['Released',
                                                     'Released'.upper()])

    def billable(self):
        return self.filter(onbording_status__in=['Released',
                                                 'Released'.upper(),
                                                 'Yes',
                                                 'Yes'.upper()])

    def selected(self):
        return self.filter(actual_selection_status__in=['Selected',
                                                        'Selected'.upper()])

    def selected_yet_to_onboard(self):
        return self.filter(actual_selection_status__in=['Selected',
                                                        'Selected'.upper()],
                           onbording_status__in=['No',
                                                 'No'.upper()])

    def projected(self):
        return self.filter(actual_selection_status__in=['In Progress'])

    def rejected(self):
        return self.filter(actual_selection_status__in=['REJECTED',
                                                        'REJECTED'.lower()])

    def hold(self):
        return self.filter(actual_selection_status__in=['HOLD',
                                                        'HOLD'.lower()])

    def profile_submitted(self):
        return self.filter(actual_selection_status__in=['Profile Submitted'])

    def for_report(self):
        return self.all().filter(Q(onbording_status__in=['Yes', 'Yes'.upper(),
                                                         'Released',
                                                         'Released'.upper()]) |
                                 Q(actual_selection_status__in=[
                                     'Selected',
                                     'Selected'.upper()]))
