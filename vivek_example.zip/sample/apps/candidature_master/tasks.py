# Create your tasks here
from __future__ import absolute_import, unicode_literals
from celery import shared_task
from office365_calendar.outlookservice import *
from user_management.models import Profile as UserProfile
from django.conf import settings

@shared_task
def __send_email_for_user_using_celery(user, email_content, subject, recepients):
    userprofile = UserProfile.objects.get(user=user)
    return send_email(userprofile.get_outlook_access_token(),
                      email_content, subject, recepients)

def send_email_for_user(user, email_content, subject, recepients):
    userprofile = UserProfile.objects.get(user=user)
    outlook_access_token = userprofile.get_outlook_access_token()
    if settings.SEND_EMAIL_USING_CELERY:
        return __send_email_for_user_using_celery.delay(outlook_access_token,
                                                      email_content, subject, recepients)
    else:
        return send_email(outlook_access_token,
                              email_content, subject, recepients)


