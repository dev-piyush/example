from .querysets import CandidatureQueryset
from framework.manager import BaseManager
from .candidature_methods import CandidatureMethods


class CandidatureManager(BaseManager, CandidatureMethods):
    queryset = CandidatureQueryset
