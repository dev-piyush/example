import django_filters
from .models import Candidature


class CandidatureFilter(django_filters.FilterSet):
    actual_selection_status = django_filters.CharFilter(
        lookup_expr='icontains')
    resource__employee_name = django_filters.CharFilter(
        name='resource__employee_name', lookup_expr='icontains')
    resource_request__RR = django_filters.CharFilter(
        name='resource_request__RR', lookup_expr='icontains')
    resource_request__job_code = django_filters.CharFilter(
        name='resource_request__job_code', lookup_expr='icontains')
    resource__employee_id = django_filters.CharFilter(
        name='resource__employee_id', lookup_expr='icontains')
    resource_request__requestor = django_filters.CharFilter(
        name='resource_request__requestor', lookup_expr='icontains')
    resource_request__demand_status = django_filters.CharFilter(
        name='resource_request__demand_status', lookup_expr='icontains')
    resource_request__SPOC = django_filters.CharFilter(
        name='resource_request__SPOC__name', lookup_expr='icontains')
    resource_request__id = django_filters.NumberFilter(
        name='resource_request__id')

    class Meta:
        model = Candidature
        fields = '__all__'
