# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.test import TestCase

# Create your tests here.

from django.test import TestCase,RequestFactory
from django.contrib.auth.models import User
from django.core.urlresolvers import reverse
from candidature_master.models import Candidature
from demand_master.models import ResourceRequest
from resource_master.models import Resource
from account_master.models import Account,Department,SubDepartment,SPOC
from user_management.models import UserRole,Profile
from skill_master.models import Skill
from location_master.models import Location
from datetime import datetime
from .views import send_questionnaire_invite_mail
from django.http import JsonResponse


class send_questionnaire_invite_mail_test(TestCase):
    fixtures = ['users','accounts','location','skills','demands','resource','candidatures']

    def setUp(self):
        self.request_factory = RequestFactory()
        self.user = User.objects.create_user(
        username='abc', email='abc@abc.com', password='my_secret')
        self.user.save()
        
       
    def test_question_create(self):
        
        candidature = Candidature.objects.all()[0].pk
        print candidature

        htmly = get_template('email.html')
        submittion_url=request.build_absolute_uri(
        candidature.get_questionaire_submittion_url())
        context_data = {
         'employee_name': candidature.resource.employee_name,
         'date_for_invite_end': datetime.datetime.now().date(),
         'mail_signature': request.user.profile.email_signature,
         'interview_date': candidature.get_interview_date(),
         'submittion_url': submittion_url}
        html_content = htmly.render(context_data)
        candiadate_email = candidature.resource.email
        dummy_email = settings.DUMMY_EMAIL_FOR_TESTING

        

        request = self.request_factory.post(reverse('send_questionnaire_invite_mail', kwargs={'pk':candidature}), 
            context_data, follow=True)
        request.user = self.user
       
        response = send_questionnaire_invite_mail(request,candidature)    
        self.assertEqual(response.status_code, 200)   



