from django import forms
from .models import *
import datetime
from framework.enums import *
from framework.forms import BaseModelForm


class CandidatureForm(BaseModelForm):
    today = datetime.datetime.now()
    resource_request = forms.ModelChoiceField(
        ResourceRequest.objects.open())
    profile_submittion_date = forms.DateField(initial=today.date,
                                              widget=forms.TextInput(
                                                  attrs={'class':
                                                         'datepicker_field'}),
                                              label='Profile Submission Date')
    resource = forms.ModelChoiceField(
        Resource.objects.available(),
        label='Resource Name')

    class Meta:
        model = Candidature
        exclude = ['deleted', 'created_on', 'created_by',
                   'last_moddified_on', 'last_moddified_by',
                   'version', 'onbording_status',
                   'DC_check_done', 'bgv_status',
                   'credit_check', 'hourly_bill_rate',
                   'preposed_on_boarding_date',
                   'selection_status', 'selection_date',
                   'selection_status_L2',
                   'selection_date_L2',
                   'onboarding_date',
                   'L1_type', 'L2_type', 'interview_date',
                   'L2_interview_date', 'selection_role',
                   'on_boarding_kit', 'must_start_date',
                   'actual_start_date',
                   'release_date', 'actual_selection_status', 'interviewer', 'other_skills_interviewd_on']
ACCEPTABLE_FORMATS = ['%Y-%m-%d %I:%M %p']


class CandidatureUpdateForm(BaseModelForm):
    selection_status = forms.ChoiceField(
        choices=SELECTION_TYPE_CHOICES,
        widget=forms.Select(), label='L1 Selection Status')
    interview_date = forms.DateTimeField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datetimepicker'}),
        label='L1 Interview Date',
        input_formats=ACCEPTABLE_FORMATS)

    selection_date = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}),
        label='L1 Selection Date')
    L2_interview_date = forms.DateTimeField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datetimepicker'}),
        label='L2 Interview Date',
        input_formats=ACCEPTABLE_FORMATS)
    selection_date_L2 = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}),
        label='L2 Selection Date')
    onboarding_date = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    release_date = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    must_start_date = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    actual_start_date = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))

    class Meta:
        model = Candidature
        exclude = ['deleted', 'created_on', 'created_by',
                   'last_moddified_on', 'last_moddified_by', 'version',
                   'actual_selection_status', 'interviewer',
                   'other_skills_interviewd_on', 'remarks']

    def is_onboarding_initiable(self, selection_status, selection_status_L2):
        return (selection_status == 'Selected' and
                (selection_status_L2 == 'Selected' or
                 selection_status_L2 == 'Not Applicable'))

    def clean(self):
        cleaned_data = super(CandidatureUpdateForm, self).clean()
        selection_date = cleaned_data.get("selection_date")
        selection_date_L2 = cleaned_data.get("selection_date_L2")
        selection_status = cleaned_data.get("selection_status")
        selection_status_L2 = cleaned_data.get("selection_status_L2")
        onboarding_date = cleaned_data.get(
            "onboarding_date")
        onbording_status = cleaned_data.get("onbording_status")

        if selection_status == 'Selected' and selection_date is None:
            self.add_error(None, forms.ValidationError(
                'Selection date is mandatory.'))
            return

        if selection_status_L2 == 'Selected' and selection_date_L2 is None:
            self.add_error(None, forms.ValidationError(
                'Selection date For L2 Interview is mandatory.'))
            return

        if self.is_onboarding_initiable(selection_status, selection_status_L2):
            if onboarding_date is None:
                self.add_error(None, forms.ValidationError(
                    'Onboarding Date is mandatory.'))
        else:
            if onbording_status == 'Yes':
                self.add_error(None, forms.ValidationError(
                    '''Onboarding can not be completed unlease
                                selection status is not SELECTED.'''))
        return


# class ForcastForm(BaseModelForm):


#     year=forms.CharField(label='Year',
#         widget=forms.TextInput(attrs={'class': ' form-control','placeholder': 'YYYY'}))
#     days=forms.CharField( label='Days',
#         widget=forms.TextInput(attrs={'class': ' form-control ','placeholder':'Days'} ))
#     forcast_value = forms.CharField( label='Forcast_Value',
#         widget=forms.TextInput(attrs={'class':' form-control ','placeholder':'Value'} ))
#     class Meta:
#         model = Forcasting
#         fields = ['year','days','forcast_value',]


# forcastformSet = inlineformset_factory(Candidature, Forcasting, form = ForcastForm, extra=1,)
