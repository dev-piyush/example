from django.conf.urls import url
from .views import *
from . import views
urlpatterns = [

    url(r'^$', CandidatureList.as_view(),
        name='candidatures_list'),
    url(r'^candidature_create/$', CandidatureCreate.as_view(),
        name='candidature_create'),
    url(r'^candidature_update/(?P<pk>\d+)/$',
        CandidatureUpdate.as_view(), name='candidature_update'),
    url(r'^candidature_delete/(?P<pk>\d+)/$',
        CandidatureDelete.as_view(), name='candidature_delete'),
    url(r'^send_questionnaire_invite_mail/(?P<pk>\d+)/$',
        views.send_questionnaire_invite_mail, name='send_questionnaire_invite_mail'),
    url(r'^candidature_detail/(?P<pk>\d+)/$',
        views.candidature_detail, name='candidature_detail'),


]
