from django import forms
from .models import *
from framework.forms import BaseModelForm
from django.forms import inlineformset_factory
from candidature_master.forms import CandidatureUpdateForm
from django.forms import inlineformset_factory


class QuestionTextForm(BaseModelForm):
    text = forms.CharField(required=True,widget=forms.Textarea,label='Questions')

    class Meta:
        model = QuestionText
        # exclude = ('user',)
        fields = ['text']

    def __init__(self, *args, **kwargs):
        super(QuestionTextForm, self).__init__(
            *args, **kwargs)
        self.fields['text'].widget.attrs[
            'style'] = 'width:810px; height:120px;'

    # def clean(self):
    #     cleaned_data = super(QuestionTextForm, self).clean()
    #     text = cleaned_data.get("text")
      
    #     if text is None:
    #         self.add_error(None, forms.ValidationError(
    #             'Cannot be blank'))
    #         return   


question_form_set = inlineformset_factory(Candidature, QuestionText, form=QuestionTextForm, extra=1)



class EmployeeDetailsForm(forms.Form):
    employee_name = forms.CharField(max_length=200)
    employee_code = forms.CharField(max_length=200)

    class Meta:
        fields = ['name']

