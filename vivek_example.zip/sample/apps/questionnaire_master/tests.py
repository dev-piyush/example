# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.test import TestCase,RequestFactory
from django.contrib.auth.models import User
from django.core.urlresolvers import reverse
from candidature_master.models import Candidature
from demand_master.models import ResourceRequest
from resource_master.models import Resource
from account_master.models import Account,Department,SubDepartment,SPOC
from skill_master.models import Skill
from location_master.models import Location
from datetime import datetime
from .views import QuestionCreate



class QuestionnaireListTest(TestCase):
    

    def setUp(self):
        test_user1 = User.objects.create_user(username='testuser1', password='12345') 
        test_user1.save()

         
    def test_redirect_if_not_logged_in(self):
        resp = self.client.get(reverse('question_list'))
        self.assertRedirects(resp, '/in/login?redirect_to=/in/questionnaire_master/')

    def test_logged_in_uses_correct_template(self):
        login = self.client.login(username='testuser1', password='12345')
        resp = self.client.get(reverse('question_list'))
        
        #Check our user is logged in
        self.assertEqual(str(resp.context['user']), 'testuser1')
        #Check that we got a response "success"
        self.assertEqual(resp.status_code, 200)

        #Check we used correct template
        self.assertTemplateUsed(resp, 'questionnaire_master/questiontext_list.html')   





class QuestionnaireCreateTest(TestCase):
    fixtures = ['users','accounts','locations','skills','demands','resources','candidatures']

    def setUp(self):
        self.request_factory = RequestFactory()
        self.user = User.objects.create_user(
        username='abc', email='abc@abc.com', password='my_secret')
        self.user.save()
        
       
    def test_question_create(self):
        
        candidature = Candidature.objects.all()[0].id
        print candidature

        postData =  {
                'selected_candidature' : 1,
                'interviewer': 'Vivek',
                'other_skills_interviewd_on': 'Java',        
                'questions-TOTAL_FORMS': 1, 
                'questions-INITIAL_FORMS': 0, 
                'questions-MIN_NUM_FORMS': 0, 
                'questions-MAX_NUM_FORMS': 1000, 
                'questions-0-text': 'François',
                'created_by' :  User.objects.get(username = 'abc'),
                'created_on' : datetime.now(tz=None)
                   
            }

        request = self.request_factory.post(reverse('questionnaire_create', kwargs={'candidature_id':candidature}), 
            postData, follow=True)
        request.user = self.user
       
        response = QuestionCreate(request,candidature)    
        self.assertEqual(response.status_code, 200)   

       