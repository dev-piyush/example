# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from framework.views import BaseListView, LoginRequiredView
from django.views import *
from django.forms import inlineformset_factory
from django.urls import reverse_lazy
from .models import QuestionText
from .forms import QuestionTextForm, EmployeeDetailsForm,question_form_set
from candidature_master.models import Candidature
from django.contrib import messages
from django.http import HttpResponseRedirect
from .filters import QuestionTextFilter

# Create your views here.
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.views.decorators.csrf import csrf_exempt
from django import forms
from django.contrib import messages
from datetime import datetime
from django.contrib.auth.models import User
from django.conf import settings


class QuestionList(BaseListView, LoginRequiredView):
    model = QuestionText
    filter_class = QuestionTextFilter

    def get_queryset(self):
        query_set = super(QuestionList, self).get_queryset()
        return query_set.values('candidature__resource__employee_name','candidature_id',
                         'candidature__resource__employee_id',
                         'candidature__resource_request__technology__name','candidature__interviewer','candidature__other_skills_interviewd_on',).distinct().order_by()


@csrf_exempt
def QuestionCreate(request, candidature_id):
    formset = question_form_set(instance=Candidature())
    if request.method == "POST":
        selected_candidature = request.POST.get('selected_candidature', None)
        formset = question_form_set(request.POST)
        if formset.is_valid():
            for form in formset:
                form.instance.candidature = Candidature.objects.get(
                    pk=int(selected_candidature))
                if form.instance.candidature.interviewer is None:
                    form.instance.candidature.interviewer = request.POST.get('interviewer', None)
                    form.instance.candidature.other_skills_interviewd_on = request.POST.get('other_skills_interviewd_on', None)
                    form.instance.candidature.save()
                form.instance.created_by = request.user or User.objects.get(username='root')
                form.instance.created_on = datetime.now(tz=None) 
                form.save()


            return render_to_response('questionnaire_master/thanks.html',
                                  {'formset': formset,
                                   'selected_candidature': selected_candidature},
                                  RequestContext(request))
    else:
        try:
            selected_candidature = Candidature.objects.get(
                id=candidature_id)
        except:
            selected_candidature={}
        mode=request.GET.get('mode', None)
        return render_to_response('questionnaire_master/questiontext_form.html',
                                  {'formset': formset,
                                   'selected_candidature': selected_candidature,
                                   'mode':mode},
                                  RequestContext(request))




