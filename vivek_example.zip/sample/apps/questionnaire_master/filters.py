import django_filters
from .models import QuestionText


class QuestionTextFilter(django_filters.FilterSet):
    technology = django_filters.CharFilter(
        name='candidature__resource_request__technology__name',
        lookup_expr='icontains')

    class Meta:
        model = QuestionText
        fields = '__all__'
