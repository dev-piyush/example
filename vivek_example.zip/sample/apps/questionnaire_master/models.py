# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from candidature_master.models import Candidature
# Create your models here.
from framework.models import BaseModel

class QuestionText(BaseModel):
    candidature = models.ForeignKey(
        Candidature, related_name='questions', null=True, blank=True)
    text =models.CharField(max_length=200 , null=False, blank=False)
    class Meta:
        ordering = ['-created_on']
    