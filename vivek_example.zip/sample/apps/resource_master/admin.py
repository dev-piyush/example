from django.contrib import admin

# Register your models here.
from .models import *
from framework.admin import BaseAdmin


class ResourceAdmin(BaseAdmin):

    pass


admin.site.register(Resource, ResourceAdmin)
