# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.test import TestCase,RequestFactory
from django.contrib.auth.models import User
from django.core.urlresolvers import reverse
from resource_master.models import Resource
from account_master.models import Account,Department,SubDepartment,SPOC
from skill_master.models import Skill
from location_master.models import Location
from datetime import datetime




class ResourceListByUserListViewTest(TestCase):

    def setUp(self):
        #Create users
        test_user1 = User.objects.create_user(username='testuser1', password='12345') 
        test_user1.save()
     
        
    def test_redirect_if_not_logged_in(self):
        resp = self.client.get(reverse('resource_list'))
        self.assertRedirects(resp, '/in/login?redirect_to=/in/resource_master/resources/')

    def test_logged_in_uses_correct_template(self):
        login = self.client.login(username='testuser1', password='12345')
        resp = self.client.get(reverse('resource_list'))
        
        #Check our user is logged in
        self.assertEqual(str(resp.context['user']), 'testuser1')
        #Check that we got a response "success"
        self.assertEqual(resp.status_code, 200)

        #Check we used correct template
        self.assertTemplateUsed(resp, 'resource_master/resource_list.html')

class ResourceCreateByUserCreateViewTest(TestCase):

	def setUp(self):
        #Create users
        test_user1 = User.objects.create_user(username='testuser1', password='12345') 
        test_user1.save()
     
        
    def test_redirect_if_not_logged_in(self):
        resp = self.client.get(reverse('resource_create'))
        self.assertRedirects(resp, '/in/login?redirect_to=/in/resource_master/resource_create/')

    def test_logged_in_uses_correct_template(self):
        login = self.client.login(username='testuser1', password='12345')
        resp = self.client.get(reverse('resource_create'))
        
        #Check our user is logged in
        self.assertEqual(str(resp.context['user']), 'testuser1')
        #Check that we got a response "success"
        self.assertEqual(resp.status_code, 200)

        #Check we used correct template
        self.assertTemplateUsed(resp, 'resource_master/resource_form.html')

