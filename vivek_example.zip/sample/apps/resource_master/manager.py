from .querysets import ResourceQueryset
from framework.manager import BaseManager
from django.db.models import Q
import datetime
from .resource_methods import ResourceMethods

class ResourceManager(BaseManager, ResourceMethods):
    queryset = ResourceQueryset