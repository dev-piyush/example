from django.conf.urls import url
from .views import *
urlpatterns = [

    url(r'^resources/$', ResourceList.as_view(), name='resource_list'),
    url(r'^resource_create/$', ResourceCreate.as_view(), name='resource_create'),
    url(r'^resource_update/(?P<pk>\d+)/$',
        ResourceUpdate.as_view(), name='resource_update'),
    url(r'^resource_delete/(?P<pk>\d+)/$',
        ResourceDelete.as_view(), name='resource_delete'),


]
