class ResourceMethods(object):

    def available(self):
        return self.filter(
            is_blocked=False
        )

    def get_resource(self, employee_id, employee_name):
        q = self.filter(employee_id=employee_id,
                        employee_name=employee_name,
                        deleted=False)
        if q.count() is not 0:
            return q.latest('created_on')
        return None
