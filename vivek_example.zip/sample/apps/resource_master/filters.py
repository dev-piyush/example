import django_filters
from .models import Resource
from distutils.util import strtobool
from framework.enums import BOOLEAN_CHOICES


class ResourceFilter(django_filters.FilterSet):
    is_blocked = django_filters.TypedChoiceFilter(
        choices=BOOLEAN_CHOICES, coerce=strtobool)
    employee_name = django_filters.CharFilter(lookup_expr='icontains')
    employee_id = django_filters.CharFilter(lookup_expr='icontains')
    is_released = django_filters.TypedChoiceFilter(
        choices=BOOLEAN_CHOICES, coerce=strtobool)

    class Meta:
        model = Resource
        fields = ['employee_id', 'employee_name', 'is_blocked', 'is_released']
