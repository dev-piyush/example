from django.db import models
import datetime
from framework.querysets import BaseQueryset
from .resource_methods import ResourceMethods

class ResourceQueryset(BaseQueryset, ResourceMethods):
    pass