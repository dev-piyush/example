from django.http import HttpResponseRedirect
from framework.views import BaseListView
from .models import *
from .forms import *
from django.views.generic.edit import CreateView
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from django.urls import reverse_lazy
from .filters import ResourceFilter
from framework.views import LoginRequiredView
from django.contrib.auth.decorators import login_required


class ResourceList(BaseListView, LoginRequiredView):
    model = Resource
    filter_class = ResourceFilter


class ResourceCreate(CreateView, LoginRequiredView):

    model = Resource
    form_class = ResourceForm
    success_url = reverse_lazy('resource_list')

    def post(self, request, **kwargs):
        self.object = None
        form = ResourceForm(request.POST, request.FILES)
        if 'advanced' in request.POST:
            self.success_url = reverse_lazy('resource_create')
        if form.is_valid():
            self.form_valid(form)
        else:
            return super(ResourceCreate, self).form_invalid(form)
        return HttpResponseRedirect(self.get_success_url())


class ResourceUpdate(UpdateView, LoginRequiredView):
    model = Resource
    form_class = ResourceUpdateForm
    template_name_suffix = '_update_form'
    success_url = reverse_lazy('resource_list')

    def post(self, request, **kwargs):
        self.object = self.get_object()
        form = ResourceUpdateForm(
            request.POST, request.FILES, instance=self.object)
        if(form.is_valid()):
            self.form_valid(form)
            return HttpResponseRedirect(form.data['referer'])
        else:
            return super(ResourceUpdate, self).form_invalid(form)

    def form_valid(self, form):
        resource = form.save()
        if resource.is_released is True:
            resource.is_blocked = False
            resource.save()


class ResourceDelete(DeleteView, LoginRequiredView):
    model = Resource
    success_url = reverse_lazy('resource_list')


@login_required(login_url=reverse_lazy('login'))
def send_resume_upload_invite_mail(request, pk):
    resource = Resource.objects.get(pk=pk)
    htmly = get_template('email.html')
    d = {'username': request.user.username}
    html_content = htmly.render(d)
    x = send_email_for_user.delay(request.user.id, html_content, "test", [
                                  'vivek.srivastava@synechron.com'])

    return HttpResponse(x)
