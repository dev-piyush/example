from framework.forms import BaseModelForm
from .models import *
from django import forms


class ResourceForm(BaseModelForm):
    account_start_data = forms.DateField(
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}),
        required=False)
    account_release_date = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    DC_check_sent_date = forms.DateField(
        required=False,
        label='DC Check Sent Date',
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    DC_check_receive_date = forms.DateField(
        required=False,
        label='DC Check Receive Date',
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    proposed_date_of_joining = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    BGV_sent_date = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}),
        label='BGV Sent Date')
    employee_id = forms.CharField(required=False, label='Employee ID')

    class Meta:
        model = Resource
        exclude = ('deleted', 'blocked_from', 'blocked_till',
                   'is_blocked', 'created_on',
                   'created_by', 'last_moddified_on',
                   'last_moddified_by', 'version', 'release_date')

    def clean(self):
        cleaned_data = super(ResourceForm, self).clean()
        current_emp_id = cleaned_data.get("employee_id")
        date_of_account_tagging = cleaned_data.get("account_start_data")
        BGV_status = cleaned_data.get("BGV_status")
        BGV_sent_date = cleaned_data.get("BGV_sent_date")
        if len(current_emp_id.strip()) > 0:
            previous_record = Resource.objects.filter(
                employee_id=current_emp_id).order_by('-id')
            if previous_record.count() > 0:
                previous_record = previous_record[0]
                if previous_record.is_released is False:
                    self.add_error(None, forms.ValidationError(
                        'Resource Already Exists'))
                    return
                if previous_record.account_start_data is not None:
                    prev_account_tagging = previous_record.account_start_data
                    if prev_account_tagging > date_of_account_tagging:
                        self.add_error(None, forms.ValidationError(
                            '''Resource Account Start date should not be same
                         as prevoius entry for the same resource'''))
        if BGV_status != 'Yet to initiate' and not BGV_sent_date:
            self.add_error(None, forms.ValidationError(
                '''Resource BGV sent date is required.'''))

        else:
            if cleaned_data.get('is_external') is True:
                cleaned_data['employee_id'] = "EXTERNAL"


class ResourceUpdateForm(BaseModelForm):
    account_start_data = forms.DateField(
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}),
        required=False)
    account_release_date = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    DC_check_sent_date = forms.DateField(
        required=False,
        label='DC Check Sent Date',
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    DC_check_receive_date = forms.DateField(
        required=False,
        label='DC Check Receive Date',
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    proposed_date_of_joining = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    BGV_sent_date = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}),
        label='BGV Sent Date')
    employee_id = forms.CharField(required=False, label='Employee ID')
    blocked_from = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    blocked_till = forms.DateField(
        required=False,
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))

    class Meta:
        model = Resource
        exclude = ('deleted',
                   'created_on',
                   'created_by', 'last_moddified_on',
                   'last_moddified_by', 'version')

    def clean(self):
        cleaned_data = super(ResourceUpdateForm, self).clean()
        account_start_data = cleaned_data.get("account_start_data")
        date_of_release_day = cleaned_data.get("release_date")
        if date_of_release_day is not None:
            if date_of_release_day < account_start_data:
                self.add_error(None, forms.ValidationError(
                    '''Resource Account Tagging date can not
                    be greater than release date.'''))
        BGV_status = cleaned_data.get("BGV_status")
        BGV_sent_date = cleaned_data.get("BGV_sent_date")
        if BGV_status != 'Yet to initiate' and not BGV_sent_date:
            self.add_error(None, forms.ValidationError(
                '''Resource BGV sent date is required.'''))
