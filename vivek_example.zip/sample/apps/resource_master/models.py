# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from framework.models import BaseModel
from account_master.models import Account
from skill_master.models import Skill
from location_master.models import Location
from framework.enums import *
from django.db import models
from .manager import ResourceManager


class Resource(BaseModel):
    synechron_account = models.ForeignKey(Account, related_name='resources')
    employee_id = models.CharField(max_length=100, null=True, blank=True)
    employee_name = models.CharField(max_length=100)
    email = models.EmailField(null=True, blank=True)
    contact_number = models.CharField(max_length=100, null=True, blank=True)
    resume = models.FileField(upload_to='resume', null=True, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    PS_ID = models.CharField(max_length=100, null=True, blank=True)
    primary_skills = models.ForeignKey(
        Skill, related_name='primary_resources', null=False, blank=False)
    secondary_skills = models.ForeignKey(
        Skill, related_name='secondary_resources', null=True, blank=True)
    account_start_data = models.DateField(null=True, blank=True)
    is_external = models.BooleanField(default=False)
    is_blocked = models.BooleanField(default=False)
    is_released = models.BooleanField(default=False)
    proposed_date_of_joining = models.DateField(null=True, blank=True)
    account_release_date = models.DateField(null=True, blank=True)
    blocked_from = models.DateField(null=True, blank=True)
    blocked_till = models.DateField(null=True, blank=True)
    city = models.ForeignKey(
        Location, related_name='resource_in_city', default=3)
    country = models.ForeignKey(
        Location, related_name='resource_in_county', default=3)

    BGV_status = models.CharField(
        max_length=100, choices=BGV_STATUS_CHOICES, default='Yet to initiate')
    BGV_sent_date = models.DateField(null=True, blank=True)
    BGV_credit_check_status = models.CharField(
        max_length=100,
        choices=CREDIT_CHECK_STATUS_CHOICES, default='Yet to initiate')

    DC_check_sent_date = models.DateField(null=True, blank=True)

    DC_status = models.CharField(
        max_length=100,
        choices=DC_CHECK_STATUS,
        default='Yet to share details with Client')

    DC_check_receive_date = models.DateField(null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    remarks = models.TextField(null=True, blank=True)
    objects = ResourceManager()

    def check_availability(self):
        return self.is_released and self.is_blocked

    def get_primary_skills(self):
        return self.primary_skills

    def get_secondary_skills(self):
        return self.secondary_skills

    def total_interviews(self):
        return self.candidatures.all().count()

    def total_selected_interviews(self):
        return self.candidatures.filter(actual_selection_status='Selected').count()

    def get_current_billable_sow(self):
        try:
            return self.candidatures.filter(actual_selection_status='Selected',
                                            onbording_status='Yes')[0].resource_request.get_sow()
        except:
            pass

    def total_on_hold_interviews(self):
        return self.candidatures.filter(actual_selection_status='HOLD').count()

    def age(self):
        from datetime import datetime
        now = datetime.now().date()
        if self.account_start_data is not None:
            days = (now - self.account_start_data).days
        else:
            days = "NA"
        return days

    def __str__(self):
        return '%s-%s' % (self.employee_name, self.employee_id)

    class Meta:
        ordering = ['employee_name']
        db_table = 'demand_tracker_resource'
