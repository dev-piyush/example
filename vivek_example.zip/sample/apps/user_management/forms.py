from django import forms
from user_management.models import Profile as UserProfile
from framework.forms import BaseModelForm
from tinymce.widgets import TinyMCE


class UserProfileForm(BaseModelForm):
    email_signature = forms.CharField(
        widget=TinyMCE(attrs={'cols': 80, 'rows': 30}))

    class Meta:
        model = UserProfile
        exclude = ['user', 'role', 'deleted', 'created_on', 'created_by',
                   'last_moddified_on', 'last_moddified_by',
                   'version', 'outlook_auth_token',
                   'outlook_auth_token_created_on',
                   'outlook_refresh_token', 'outlook_auth_token_expreise_on']


