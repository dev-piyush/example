from django.contrib import admin

# Register your models here.
from .models import *
from framework.admin import BaseAdmin



  


admin.site.register(UserRole)
admin.site.register(Profile)