# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from framework.views import BaseListView, LoginRequiredView
from django.views import *
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from django.views.generic.detail import DetailView
from django.urls import reverse_lazy
from user_management.models import Profile as UserProfile
from .forms import UserProfileForm
from django.http import HttpResponseRedirect
from django.contrib import messages
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.forms import PasswordChangeForm
from django.shortcuts import render, redirect

class UserProfileUpdate(UpdateView, LoginRequiredView):
    model = UserProfile
    form_class = UserProfileForm
    template_name_suffix = '_update_form'

    def get_success_url(self, **kwargs):
        from django.contrib import messages
        messages.add_message(self.request, messages.INFO,
         'Profile has been  Updated Succesfully')
        return reverse_lazy('userprofile_update',
     kwargs={'pk': self.request.user.profile.id})




def change_password(request):
    if request.method == 'POST':
        form = PasswordChangeForm(request.user, request.POST)
        if form.is_valid():
            user = form.save()
            update_session_auth_hash(request, user)  # Important!
            messages.success(request, 'Your password was successfully updated!')
            return redirect('change_password')
        else:
            messages.error(request, 'Please correct the error below.')
    else:
        form = PasswordChangeForm(request.user)
    return render(request, 'user_management/change_password.html', {
        'form': form
    })