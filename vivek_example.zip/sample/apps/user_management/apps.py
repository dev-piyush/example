# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class UserRManagementConfig(AppConfig):
    name = 'user_r_management'
