# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from datetime import timedelta
from django.utils import timezone
from tinymce import models as tinymce_models
from django.db import models
from django.contrib.auth.models import User
from office365_calendar.authhelper import *
from location_master.models import Location
from framework.models import BaseModel


class UserRole(BaseModel):
    """docstring for Role"""

    name = models.CharField(max_length=100, null=True, blank=True)

    def __unicode__(self):
        return self.name


class Profile(BaseModel):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    role = models.OneToOneField(UserRole, null=True, blank=True)
    current_location = models.ForeignKey(
        Location, related_name='users', null=True, blank=True)
    contact_no = models.CharField(
        max_length=100, null=True, blank=True, unique=True)
    email_signature = tinymce_models.HTMLField()
    outlook_auth_token = models.CharField(max_length=2500)
    outlook_auth_token_created_on = models.DateTimeField(
        null=True, blank=True)
    outlook_refresh_token = models.CharField(max_length=2500)
    outlook_auth_token_expreise_on = models.DateTimeField(
        null=True, blank=True)

    def get_outlook_access_token(self):

        if self.outlook_auth_token and self._has_token_expired() is False:
            return self.outlook_auth_token
        elif self.outlook_auth_token is not None and self._has_token_expired():
            new_response = get_token_using_refresh(self.outlook_refresh_token)
            self.save_access_token(new_response)
            return self.outlook_auth_token

    def save_access_token(self, token):
        current_time = timezone.localtime(timezone.now())
        self.outlook_auth_token = token['access_token']
        self.outlook_refresh_token = token['refresh_token']
        self.outlook_auth_token_created_on = current_time
        self.outlook_auth_token_expreise_on = current_time + \
            timedelta(minutes=59)
        self.save()

    def _has_token_expired(self):
        if self.outlook_auth_token_expreise_on is None:
            return True
        current_time = timezone.localtime(timezone.now())
        expire_time = timezone.localtime(self.outlook_auth_token_expreise_on)
        if current_time < expire_time:
            return False
        return True

    def __unicode__(self):
        return u'Profile of user: %s' % self.user.username
