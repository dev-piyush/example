from django.conf.urls import url
from .views import *

urlpatterns = [

    url(r'^update/(?P<pk>\w+)/$', UserProfileUpdate.as_view(),
        name='userprofile_update'),
 url(r'^password/$', change_password, name='change_password'),
]
