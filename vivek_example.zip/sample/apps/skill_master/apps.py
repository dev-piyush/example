from django.apps import AppConfig


class SkillMasterConfig(AppConfig):
    name = 'skill_master'
