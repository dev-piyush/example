




from logging import Handler

class DBHandler(Handler,object):
    model_name = None

    def __init__(self, model=""):
        super(DBHandler,self).__init__()
        self.model_name = model

    def emit(self,record):
        # instantiate the model
        try:
            model = self.get_model(self.model_name)
        except:
            from .models import StatusLog as model
          
            import traceback

           
            trace = traceback.format_exc()

            kwargs = {
                'logger_name': record.name,
                'level': record.levelno,
                'msg': record.getMessage(),
                'trace': trace
            }
            log_entry = model(**kwargs)


            log_entry.save()

    def get_model(self, name):
        names = name.split('.')
        mod = __import__('.'.join(names[:-1]), fromlist=names[-1:])
        return getattr(mod, names[-1])