DEMAND_STATUS_TYPE_CHOICES = (('Yet to Propose', 'Yet to Propose'),
                              ('In Progress', 'In Progress'),
                              ('Not in Consideration', 'Not in Consideration'),
                              ('Rejected', 'Rejected'),
                              ('Selected', 'Selected'),
                              ('Demand Cancelled', 'Demand Cancelled'),
                              ('On Hold', 'On Hold'),
                              ('Drop Out', 'Drop Out'),
                              ('Others', 'Others'),
                              ('Profile Submitted', 'Profile Submitted'),
                              ('Duplicate', 'Duplicate'),
                              ('Released', 'Released'),
                              ('Closed', 'Closed'))


ON_BOARDING_STATUS = (
    ('NOT APPLICABLE', 'Not Applicable'),
    ('Onboarded'.upper(), 'Onboarded'),
    ('Projected'.upper(), 'Projected'),
    ('Released', 'Released'),
    ('Closed', 'Closed')
)
DC_CHECK_STATUS = (
    ('Yet to share details with Client',
     'Yet to share details with Client'),
    ('Details shared with Client',
     'Details shared with Client'),
    ('DC Cleared', 'DC Cleared'),
    ('DC Failed', 'DC Failed')
)
BGV_STATUS_CHOICES = (
    ('Yet to initiate', 'Yet to initiate'),
    ('Initiated', 'Initiated'),
    ('Green', 'Green'),
    ('Red', 'Red'),
    ('Amber', 'Amber'),
)
CREDIT_CHECK_STATUS_CHOICES = (
    ('Yet to initiate', 'Yet to initiate'),
    ('Initiated', 'Initiated'),
    ('Green', 'Green'),
    ('Red', 'Red'),
    ('Amber', 'Amber'),
)

SOW_STATUS_TYPE_CHOICES = (
    ('Active', 'Active'),
    ('With Client Manager for approval', 'With Client Manager for approval'),
    ('Closed', 'Closed'),
    ('Lost Opportunity', 'Lost Opportunity'),
    ('With Procurement', 'With Procurement'),
    ('Fully signed off', 'Fully signed off'),
)

ONBOARDING_STATUS_CHOICES = (
    ('No', 'No'),
    ('Yes', 'Yes'),
    ('Released', 'Released'),
    ('Closed', 'Closed')
)

SELECTION_TYPE_CHOICES = (('Not Applicable', 'Not Applicable'), ('Yet to Propose', 'Yet to Propose'),
                          ('In Progress', 'In Progress'),
                          ('Not in Consideration', 'Not in Consideration'),
                          ('Rejected', 'Rejected'),
                          ('Selected', 'Selected'),
                          ('On Hold', 'On Hold'),
                          ('Demand Cancelled', 'Demand Cancelled'),
                          ('Profile Submitted', 'Profile Submitted'),
                          ('Released', 'Released'),
                          ('Drop Out', 'Drop Out')
                          )
INTERVIEW_TYPE_CHOICES = (
    ('TI', 'TI'),
    ('F2F', 'F2F'),
    ('VC', 'VC'),
    ('OV', 'OV'),
    ('Not Applicable', ' Not Applicable'),)
ONBORDING_KIT_CHOICES = (
    ('YES', 'YES'),
    ('NO', 'NO'),
)
PAYMENT_TERMS_CHOICES = (
    ('T&M', 'T&M'),
    ('Fixed', 'Fixed'),
)
STATUS_CHOICES = (
    ('Hot', 'Hot'),
    ('Warm', 'Warm'),
    ('Cold', 'Cold'),
)
BOOLEAN_CHOICES = (('false', 'False'), ('true', 'True'),)


def get_keys(enum):
    keys = []
    for i in enum:
        key_value, key_name = i
        keys.append(key_value)
    return keys


EXPENSE_CHOICES = (('Hotel expenses', 'Hotel expenses'),
                   ('Traveling expenses', 'Traveling expenses'),
                   ('Telephone / Mobile expenses', 'Telephone / Mobile expenses'),
                   ('Other Expenses',  'Other Expenses'),
                   )
