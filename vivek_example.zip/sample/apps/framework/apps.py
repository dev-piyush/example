from django.apps import AppConfig


class FrameworkConfig(AppConfig):
    name = 'framework'
