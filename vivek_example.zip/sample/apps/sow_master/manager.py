from .querysets import SOWQueryset
from framework.manager import BaseManager
from .sow_methods import SowMethods


class SOWManager(BaseManager,SowMethods ):
    queryset = SOWQueryset