from framework.forms import *
from .models import *
from framework.enums import *
from django import forms
from collections import OrderedDict

class SOWForm(BaseModelForm):
    SOW_ID = forms.CharField(required=True, label='SOW Number')
    SOW_sent_date_to_account_manager = get_date_field()
    approval_received_from_account_manager = get_date_field()
    SOW_sent_date_to_procurement = get_date_field()
    approval_received_from_procurement = get_date_field()
    start_date = get_date_field()
    end_date = get_date_field()
    resource_requests = forms.ModelMultipleChoiceField(
        queryset=ResourceRequest.objects.selected().untagged(),
        required=False)


    class Meta:
        model = SOW
        exclude = get_default_excluded_fields()

    def clean(self):
        cleaned_data = super(SOWForm, self).clean()
        start_date = cleaned_data.get("start_date")
        end_date = cleaned_data.get("end_date")
        if end_date < start_date:
            self.add_error(None, forms.ValidationError(
                'Start date can not be greater than End date.'))


class SOWUpdateForm(BaseModelForm):

        
    SOW_ID = forms.CharField(required=True, label='SOW Number')
    SOW_sent_date_to_account_manager = forms.DateField(
        widget=forms.TextInput(attrs={'class': 'datepicker_field'}))
    
    # released_resource_requests = forms.ModelMultipleChoiceField(
    #     queryset=ResourceRequest.objects.all(), required=False)
    resource_requests = forms.ModelMultipleChoiceField(
        queryset=ResourceRequest.objects.all().selected(), required=False)

    approval_received_from_account_manager = get_date_field()
    SOW_sent_date_to_procurement = get_date_field()
    approval_received_from_procurement = get_date_field()
    start_date = get_date_field()
    end_date = get_date_field()
    
    # def __init__(self, *args, **kwargs):
    #     super(SOWUpdateForm, self).__init__(*args, **kwargs)
    #     qs = ResourceRequest.objects.selected().untagged(self.instance)
    #     f = forms.ModelMultipleChoiceField(
    #         queryset=qs,
    #         required=False)
    #     import collections
    #     self.fields=dict(self.fields)
    #     d1=OrderedDict()
    #     self.fields['released_resource_requests']=f
    #     for k,v in self.fields.iteritems():
            
    #         if k is not 'resource_requests':
    #             d1[k]=v
            


        
    #     d2=OrderedDict([("resource_requests",self.fields['resource_requests']),("released_resource_requests",f)])
    #     both=OrderedDict(list(d2.items()) + list(d1.items()))
    #     self.fields=both
    class Meta:
        model = SOW
        exclude = get_default_excluded_fields()

    def clean(self):
        cleaned_data = super(SOWUpdateForm, self).clean()
        start_date = cleaned_data.get("start_date")
        end_date = cleaned_data.get("end_date")
        if end_date < start_date:
            self.add_error(None, forms.ValidationError(
                'Start date can not be greater than End date.'))
