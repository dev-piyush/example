# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
from account_master.models import Account, Department
from demand_master.models import ResourceRequest
from location_master.models import Location
from framework.enums import *
from framework.models import BaseModel
from candidature_master.models import Candidature
from django.db.models import Count
from .manager import SOWManager


class SOW(BaseModel):
    account = models.ForeignKey(
        Account, related_name='sows', null=True, blank=True)
    location = models.ForeignKey(
        Location, related_name='sows', null=True, blank=True)
    department = models.ForeignKey(
        Department, related_name='sows', null=True, blank=True)
    PO_number = models.CharField(max_length=100, null=True, blank=True)
    SOW_ID = models.CharField(max_length=100)
    Previous_SOW_ID = models.CharField(max_length=100, null=True, blank=True)
    SOW_sent_date_to_account_manager = models.DateField(
        null=True, blank=True)
    approval_received_from_account_manager = models.DateField(
        null=True, blank=True)
    SOW_sent_date_to_procurement = models.DateField(null=True, blank=True)
    approval_received_from_procurement = models.DateField(
        null=True, blank=True)
    resource_requests = models.ManyToManyField(
        ResourceRequest, related_name='sows')
    status = models.CharField(
        max_length=100,
        choices=SOW_STATUS_TYPE_CHOICES, default='Yet to draft')
    line_manager = models.CharField(max_length=100, null=True, blank=True)
    payment_terms = models.CharField(
        max_length=100, choices=PAYMENT_TERMS_CHOICES, default='T&M')
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)
    SOW_value = models.FloatField(null=True, blank=True)
    bill_rate = models.FloatField(null=True, blank=True)
    number_of_resources = models.IntegerField(null=True, blank=True)
    commited_spend_days_2016 = models.FloatField(default=0.0)
    commited_spend_days_2017 = models.FloatField(default=0.0)
    commited_spend_days_2018 = models.FloatField(default=0.0)
    soft_copy = models.FileField(upload_to='sows', null=True, blank=True)
    objects = SOWManager()
    remarks = models.TextField(null=True, blank=True)

    def __str__(self):
        return(self.SOW_ID)

    def get_scheduled_interviews(self):
        return SOW.objects.filter(pk=self.id).annotate(
            count=Count('resource_requests__candidatures')).values('count')[0][
            'count']

    def get_active_resources(self):
        l = list(self.resource_requests.all(
        ).values_list('id', flat=True))
        return Candidature.objects.filter(resource_request__in=l,
                                          onbording_status='Yes')

    def get_selected_resources(self):
        l = list(self.resource_requests.all(
        ).values_list('id', flat=True))
        return Candidature.objects.filter(resource_request__in=l,
                                          onbording_status='No',
                                          selection_status='Selected')

    def get_released_resources(self):
        l = list(self.resource_requests.all(
        ).values_list('id', flat=True))
        return Candidature.objects.filter(resource_request__in=l,
                                          onbording_status='Released')

    def get_resource_requests(self):
        return self.resource_requests.all()

    class Meta:
        ordering = ['-created_on']
        db_table = 'demand_tracker_sow'

# class SowForcast(BaseModel):
#     sow = models.ForeignKey( SOW, related_name='sows_forcast')
#     month=models.IntegerField()
#     year=models.IntegerField()
#     value=models.FloatField()
    
#     class Meta:
#         ordering = ['-created_on']
#         db_table = 'demand_tracker_sow_forcast'
