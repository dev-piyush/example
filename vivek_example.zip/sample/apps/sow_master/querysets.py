from django.db import models
from framework.querysets import BaseQueryset
from .sow_methods import SowMethods


class SOWQueryset(BaseQueryset, SowMethods):

    pass
