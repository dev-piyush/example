from django.contrib import admin

# Register your models here.
from .models import *
from framework.admin import BaseAdmin


class SOWAdmin(BaseAdmin):

    pass


admin.site.register(SOW, SOWAdmin)
