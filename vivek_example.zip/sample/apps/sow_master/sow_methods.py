class SowMethods(object):
    def scheduled_interviews(self):
        return self.resource_requests.filter(
            demand_status__in=['SCHEDULED',
                               'SCHEDULED'.lower()
                               ])

    def released(self):
        return self.filter(selection_status__in=['Released',
                                                 'Released'.upper()])

    def selected(self):
        return self.filter(selection_status__in=['Selected',
                                                 'Selected'.upper()])

    def scheduled(self):
        return self.filter(selection_status__in=['SCHEDULED',
                                                 'SCHEDULED'.lower()])

    def rejected(self):
        return self.filter(selection_status__in=['REJECTED',
                                                 'REJECTED'.lower()])

    def hold(self):
        return self.filter(selection_status__in=['HOLD',
                                                 'HOLD'.lower()])
