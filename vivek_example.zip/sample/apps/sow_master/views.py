from django.http import HttpResponseRedirect , HttpResponse
from framework.views import BaseListView, LoginRequiredView
from .models import *
from .forms import *
from django.views.generic.edit import CreateView
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from django.urls import reverse_lazy
from django import forms
from datetime import datetime
from datetime import timedelta
from dateutil.relativedelta import relativedelta
import collections
import json

from .filters import SOWFilter
# import the logging library
import logging
import calendar
import numpy 
# Get an instance of a logger
logger = logging.getLogger('info')


class SOWList(BaseListView, LoginRequiredView):
    model = SOW
    filter_class = SOWFilter


class SOWCreate(CreateView, LoginRequiredView):
    model = SOW
    form_class = SOWForm
    success_url = reverse_lazy('sow_list')

    def get_initial(self):
        initial = super(SOWCreate, self).get_initial()
        initial = initial.copy()
        logger.info('Received request for creating new SOW!')
        previous_sow_id = self.request.GET.get(
            "previous_sow_id", None)
        logger.info("""Received request for creating SOW is based on
                    the previous SOW """ + str(previous_sow_id))
        if previous_sow_id is None:
            resource_request_id = self.request.GET.get(
                "resource_request__id", None)
            if resource_request_id is not None:
                initial['resource_requests'] = ResourceRequest.objects.filter(
                    pk=resource_request_id)[0]
        else:
            initial['resource_requests'] = SOW.objects.filter(
                pk=previous_sow_id)[0].resource_requests.all()
            initial['Previous_SOW_ID'] = SOW.objects.get(
                pk=previous_sow_id).SOW_ID

        return initial

    def get_form(self):
        """
        Returns an instance of the form to be used in this view.
        """
        previous_sow_id = self.request.GET.get(
            "previous_sow_id", None)
        form = self.form_class(**self.get_form_kwargs())
        if previous_sow_id is not None:
            form.fields['resource_requests'] = forms.ModelMultipleChoiceField(
                queryset=SOW.objects.filter(
                    pk=previous_sow_id)[0].resource_requests.all(),
                required=False)
        return form

    def post(self, request, **kwargs):
        self.object = None
        form = SOWForm(request.POST, request.FILES)
        if 'advanced' in request.POST:
            self.success_url = reverse_lazy('sow_create')
        if form.is_valid():
            self.form_valid(form)
        else:
            return super(SOWCreate, self).form_invalid(form)
        return HttpResponseRedirect(self.get_success_url())

    def form_valid(self, form ):
        
        self.object=form.save()
        # start_date=self.object.start_date
        # end_date=self.object.end_date
        # if start_date and end_date :
        #     forcast_values=calculate_commited_days(self.request, start_date=start_date, end_date=end_date, is_ajax=False)
        #     for forcast in forcast_values :

        #         sow_forcast=SowForcast()
        #         sow_forcast.sow=self.object
        #         sow_forcast.month= datetime.strptime(forcast.get("month"), '%B').month
        #         sow_forcast.year=forcast.get("year")

        #         sow_forcast.value=forcast.get("days")
        #         sow_forcast.save()





class SOWUpdate(UpdateView, LoginRequiredView):
    model = SOW
    form_class = SOWUpdateForm
    template_name_suffix = '_update_form'
    success_url = reverse_lazy('sow_list')

        
    def post(self, request, **kwargs):
        self.object = self.get_object()
        form = SOWUpdateForm(request.POST, request.FILES, instance=self.object)
        if(form.is_valid()):
            self.form_valid(form)
            return HttpResponseRedirect(form.data['referer'])
        else:
            return super(SOWUpdate, self).form_invalid(form)

    def get_form(self):
        """
        Returns an instance of the form to be used in this view.
        """
        form = self.form_class(**self.get_form_kwargs())
        form.fields['released_resource_requests'] = forms.ModelMultipleChoiceField(
                queryset=self.object.get_released_resources(),
                required=False)
        return form
class SOWDelete(DeleteView, LoginRequiredView):
    model = SOW
    success_url = reverse_lazy('sow_list')


def get_working_days_in_month(start_date,end_date=None):
    if end_date is None:
        end_date = start_date.replace(day = calendar.monthrange(start_date.year, start_date.month)[1])
    total_working_days= numpy.busday_count(start_date,end_date)
    if end_date.weekday() in range(0, 5) :
            total_working_days += 1
    if total_working_days > 20:
        return {'month':start_date.strftime("%B"),'total_working_days':20}
    return {'month':start_date.strftime("%B"),'total_working_days':total_working_days}


def calculate_commited_days(request, start_date=None, end_date=None, is_ajax=True  ):
    dic = collections.OrderedDict()
    output=[]
    if is_ajax:
        start_date=request.GET.get("start_date")
        end_date=request.GET.get("end_date")
        start_date=datetime.strptime(start_date, '%Y-%m-%d')
        end_date=datetime.strptime(end_date, '%Y-%m-%d') 
    total_working_days=0
    while start_date < end_date:
                if start_date.year==end_date.year and start_date.month==end_date.month :
                    total_working_days=get_working_days_in_month(start_date,end_date)
                else:
                    total_working_days=get_working_days_in_month(start_date)
                output.append({'year':start_date.year,'days':total_working_days['total_working_days'],'month':total_working_days['month']})
                start_date=start_date.replace(day = calendar.monthrange(start_date.year, start_date.month)[1])+ timedelta(days=1)
                
    
    if is_ajax:
        response = json.dumps(output)
        return HttpResponse(response)  
    else:
        return output






