from django.conf.urls import url
from .views import *
urlpatterns = [

    url(r'^sows/$', SOWList.as_view(), name='sow_list'),
    url(r'^sow_create/$', SOWCreate.as_view(), name='sow_create'),
    url(r'^sow_update/(?P<pk>\d+)/$', SOWUpdate.as_view(), name='sow_update'),
    url(r'^sow_delete/(?P<pk>\d+)/$', SOWDelete.as_view(), name='sow_delete'),
    url(r'^calculate_commited_days/$', calculate_commited_days, name='calculate_commited_days'),


]
