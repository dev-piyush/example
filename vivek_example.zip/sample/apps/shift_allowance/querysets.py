from django.db import models
from django.db.models import Count
from django.db.models import Q
from framework.querysets import BaseQueryset
from .allowance_methods import AllowanceDataMethods, PerDayRecordMethods


class PerDayRecordQueryset(BaseQueryset,PerDayRecordMethods):
    pass


    

class AllowanceDataQueryset(BaseQueryset,AllowanceDataMethods):
    pass


   
