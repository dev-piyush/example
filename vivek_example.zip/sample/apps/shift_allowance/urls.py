# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.conf.urls import url

from . import views


urlpatterns = [
    url(r'^Shift_allowance_create$', views.ShiftAllowanceCreate.as_view(), name='shift_allowance_create'),
    url(r'^shift_allowances/$', views.ShiftAllowanceList.as_view(), name='shift_allowances_list'),
    url(r'^(?P<pk>\d+)/update/$', views.update, name='shift_allowance_update'),
    url(r'^(?P<pk>\d+)/updateData/$', views.updateData, name='allowances_update'),
    url(r'^(?P<pk>\d+)/approve/$', views.approve, name='shift_allowance_approve'),
    url(r'^(?P<pk>\d+)/reject/$', views.reject, name='shift_allowance_reject'),
    url(r'^(?P<pk>\d+)/detail/$', views.shift_allowance_detail, name='shift_allowance_detail'),
    url(r'^export/$', views.export_data, name='shift_allowance_export'),
    url(r'^thanks/$', views.thanks, name='thanks'),
    url(r'get_previous_allowances/$', views.get_previous_allowances, name='get_previous_allowances'),
]
