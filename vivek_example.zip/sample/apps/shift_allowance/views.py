# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from django.db.models import CharField, Case, When, Value as V
from django.http import HttpResponse , HttpResponseRedirect
from .forms import AllowanceForm, perDayformSet, perDayUpdateformSet
from django.forms import inlineformset_factory
from .models import AllowanceData, PerDayRecord
from user_management.models import Profile as UserProfile
from resource_master.models import Resource
from account_master.models import  SPOC
from django.shortcuts import redirect, render
from django import forms
from django.views.generic.edit import DeleteView
from django.core.urlresolvers import reverse_lazy
from django.contrib.auth.decorators import login_required
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from framework.views import BaseListView
from framework.views import LoginRequiredView
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from django.contrib import messages
import xlwt
from .filters import AllowanceFilter
from constants import *
import json
import collections
import logging
from django.db.models.functions import Extract , Concat
from django.db.models import Count
# Get an instance of a logger
logger = logging.getLogger('info')


class ShiftAllowanceList(BaseListView, LoginRequiredView):
    logger.info('Getting all shift allowance list!')
    filter_class=AllowanceFilter
    model = AllowanceData
    context_object_name = 'allowance_list' 
    template_name = 'shift_allowance/shift_allowance_list.html'
    def get_context_data(self, *args, **kwargs):
            # Call the base implementation first to get a context
        context = super(ShiftAllowanceList, self).get_context_data(
            *args, **kwargs)
        
        context['spocs'] = SPOC.objects.all()
        return context



class ShiftAllowanceCreate(CreateView):
    model = AllowanceData
    fields = ['resource_email','account', 'reporting_manager', 'group_head']
    template_name = 'shift_allowance/shift_allowance_create.html'

    def get_context_data(self, **kwargs):
        context = super(ShiftAllowanceCreate, self).get_context_data(**kwargs)
        if self.request.POST:
            context['employee_id'] =self.request.POST.get("employee_ID", None)
            context['employee_name'] =self.request.POST.get("employee_name", None)
            context['allowance_form'] = AllowanceForm(self.request.POST)
            context['perDay_formSet'] = perDayformSet(self.request.POST, self.request.FILES)
        else:
            context['allowance_form'] = AllowanceForm()
            context['perDay_formSet'] = perDayformSet(instance=AllowanceData())
        return context
    
    def form_valid(self, form):
        context = self.get_context_data()
        employee_id=context['employee_id']
        employee_name = context['employee_name']
        resource =None
        resource=Resource.objects.get_resource(employee_id=employee_id,employee_name=employee_name)
        if resource is None:
            try:
                raise ResourceNotFoundError("Error")
            except:
                logger.info("No Resource Found during shift allowance create")

            messages.error(self.request,'NO Resource Found !! ')
            return self.render_to_response(self.get_context_data(form=form)) 
            
        allowance_form = context['allowance_form']
        perDay_formSet = context['perDay_formSet']
        
        if allowance_form.is_valid() and perDay_formSet.is_valid():
            self.object = allowance_form.save(commit=False)
            self.object.resource=resource
            self.object.save()
            perDay_formSet.instance = self.object
            perDay_formSet.save()
            logger.info('New allowance Report Is Created!')
            return self.get_success_url()
        else:
            return self.render_to_response(self.get_context_data(allowance_form=allowance_form ,perDay_formSet=perDay_formSet))
    
    def get_success_url(self):
        if self.request.user.is_anonymous()  : 
           return HttpResponseRedirect(reverse_lazy('thanks'))
        return HttpResponseRedirect(reverse_lazy('shift_allowances_list'))

def thanks(request):
    return render(request,'shift_allowance/thanks.html')


@login_required(login_url=reverse_lazy('login'))
def update(request, pk):
    allowance = AllowanceData.objects.get(pk=pk)
    allowance_form = AllowanceForm(instance=allowance, 
            initial={'employee_ID': allowance.resource.employee_id,
                     'employee_name': allowance.resource.employee_name})
    
    perDay_formSet = perDayUpdateformSet(instance=allowance)
    return render(request, 'shift_allowance/shift_alloance_update.html', {'allowance_form': allowance_form, 'id': allowance.pk, 'perDay_formSet': perDay_formSet})


@login_required(login_url=reverse_lazy('login'))
def updateData(request, pk):

    allowance_object = AllowanceData.objects.get(pk=pk)
    new_form = AllowanceForm(request.POST, instance=allowance_object)
    if new_form.is_valid():
        saved_data = new_form.save()
        formSet = perDayUpdateformSet(
            request.POST, request.FILES, instance=saved_data)
        pre_records=PerDayRecord.objects.filter(allowanceId=allowance_object)
        for form in formSet :
            if form.has_changed():
                form.instance.pmo_approval=None
                form.instance.group_head_approval=None
                form.instance.actual_approval=None
                form.save()
            if form.instance not in pre_records:
                form.instance.deleted=True
                form.save()
        logger.info(' Allowance Reocrd Is Updated!')
    return redirect(reverse_lazy('shift_allowances_list'))


@login_required(login_url=reverse_lazy('login'))
def approve(request, pk):
    allowance_record = PerDayRecord.objects.get(pk=pk)
    
    userRole= UserProfile.objects.get(user=request.user).role
    if userRole is not None and userRole.name=="Group Head" :
        allowance_record.group_head_approval=True
        allowance_record.actual_approval=True
    else :
        allowance_record.pmo_approval=True
        if allowance_record.actual_approval is False :
            allowance_record.group_head_approval=None
            allowance_record.actual_approval=None

    allowance_record.save()
    logger.info(' Allowance Reocrd Is approved!')
    return redirect(reverse_lazy('shift_allowances_list'))


@login_required(login_url=reverse_lazy('login'))
def reject(request, pk):
    allowance_record = PerDayRecord.objects.get(pk=pk)

    allowance_record.pmo_approval=False
    allowance_record.group_head_approval=False
    allowance_record.actual_approval=False
      
    allowance_record.save()
    logger.info(' Allowance Reocrd Is approved!')
    return redirect(reverse_lazy('shift_allowances_list'))


@login_required(login_url=reverse_lazy('login'))
def shift_allowance_detail(request, pk):
    allowance=AllowanceData.objects.get(pk=pk)
    pmo_login=True
    
    userRole= UserProfile.objects.get(user=request.user).role

    if userRole is not None and userRole.name=="Group Head" :
        allowance_object=PerDayRecord.objects.all().filter(allowanceId=allowance)
        pmo_login=False
    else :
        allowance_object=PerDayRecord.objects.all().filter(allowanceId=allowance)
    
         
    return render(request, 'shift_allowance/per_day_record.html', {'allowance_object': allowance_object,'pmo_login':pmo_login})



def get_previous_allowances(request):
    output=[]
    try:
        resource=Resource.objects.get(employee_id=request.GET.get("empid"))
        allowances=AllowanceData.objects.filter(resource=resource)
        dic = collections.OrderedDict()
        
        for allowance in allowances :
            print allowance
            allowances_records=allowance.shift_records.all()
            for recods in allowances_records :
                record ={
                         'start_date':str(recods.start_date),
                         'start_time':str(recods.start_time),
                         'end_date':str(recods.end_date),
                         'end_time':str(recods.end_time)
                         }
                output.append(record)
    except:
          pass              
    response=json.dumps(output)              
    return HttpResponse(response)


def export_data(request):
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="Allowance.xls"'

    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Allowance_data')

    # Sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold = True

    columns = ['emp_code', 'name', 'account', 'reporting_manager',
               'group_head', 'date','approval' ,'allowance']

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)

    font_style = xlwt.XFStyle()
    

    rows = AllowanceFilter(request.GET, queryset=AllowanceData.objects.all()).qs
    rows_id=rows.values_list('id')
    queryset_rows = PerDayRecord.objects.filter(allowanceId__in=rows_id).annotate(
                actual_year=Extract('start_date', 'year'),
                actual_month=Extract('start_date', 'month'), 
                actual_day=Extract('start_date', 'day'),
                ).annotate(
                actual_date=Concat(
                'actual_day', V('-'), 'actual_month', V('-'), 'actual_year',
                output_field=CharField()
                )).annotate(
                aprroval_status=Case(
                    When(actual_approval=True,
                        then=V('APPROVED')),
                    When(actual_approval=False,
                        then=V('REJECTED')),
                    When(actual_approval=None,
                        then=V('Wating fir approval')),
                   output_field=CharField()
                )).values_list(
                           'allowanceId__resource__employee_id', 
                           'allowanceId__resource__employee_name',
                           'allowanceId__account__name',
                           'allowanceId__reporting_manager',
                           'allowanceId__group_head__name',                           
                           'actual_date',
                           'aprroval_status',     
                        )

    approval=request.GET.get('approval')
    if approval is not None and  approval != '':
       filteredQueryset=queryset_rows.filter(actual_approval=approval) 
    else:
        filteredQueryset=queryset_rows

    for row in filteredQueryset:
        print row
        row_num += 1
        for col_num in range(len(row)):
            ws.write(row_num, col_num, row[col_num], font_style)

        if row[6] == "APPROVED" :
            ws.write(row_num, len(row), ALLOWANE_PER_DAY, font_style)
    wb.save(response)
    logger.info(' Allowance Reocrd is Exportrd As xls !')
    return response
