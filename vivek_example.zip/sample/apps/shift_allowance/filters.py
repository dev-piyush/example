import django_filters
from .models import *
from django import forms
from constants import *
from account_master.models import  SPOC
from datetime import datetime
from pytz import timezone



class AllowanceFilter(django_filters.FilterSet):

    
    created_on_after = django_filters.CharFilter(method='filter_created_on_after')
    created_on_before = django_filters.CharFilter(method='filter_created_on_before')
    approval=django_filters.BooleanFilter(method='filter_approval')


    spoc = django_filters.CharFilter(
        name='group_head__name')

    class Meta:
        model = AllowanceData
        fields = ['reporting_manager', ]

    def filter_created_on_after(self, queryset, name, value):
        date = datetime.strptime(value, '%Y-%m-%d')
        datetime_obj_utc=date.replace(tzinfo=timezone('UTC')) 
        return queryset.filter(created_on__gte=datetime_obj_utc)   

    def filter_created_on_before(self, queryset, name, value):
        date = datetime.strptime(value, '%Y-%m-%d')
        datetime_obj_utc=date.replace(tzinfo=timezone('UTC'))
        return queryset.filter(created_on__lte=datetime_obj_utc) 

    def filter_approval(self, queryset, name, value):
        removable_obj=[]
        for obj in queryset :    
            if  obj.shift_records.filter(actual_approval=value).count() < 1:
                removable_obj.append(obj.id)
            
        new_queryset=queryset.exclude(id__in=removable_obj)     
            
        return new_queryset
        
