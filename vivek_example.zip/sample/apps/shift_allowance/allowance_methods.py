class AllowanceDataMethods(object):
    def all(self):
        return self.filter(deleted=False)

        
class PerDayRecordMethods(object):
    def all(self):
        return self.filter(deleted=False)   