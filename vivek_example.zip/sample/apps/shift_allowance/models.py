# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.db import models
from framework.models import BaseModel
import calendar
from datetime import datetime
from django.db.models.signals import post_save, pre_save
from django.utils import timezone
from account_master.models import Account, Department, SPOC
from resource_master.models import Resource
from .manager import AllowanceDataManager,PerDayRecordManager

class AllowanceData(BaseModel):

    
    resource= models.ForeignKey(Resource)
    resource_email = models.EmailField(null=True, blank=True)
    account = models.ForeignKey(Account)
    department = models.ForeignKey(Department , null=True)
    reporting_manager = models.CharField(max_length=30)
    group_head = models.ForeignKey(SPOC)
    objects = AllowanceDataManager()
    
    def claimed_allowance(self):
        return self.shift_records.filter(deleted=False).count() * 400

    def approved_allowance(self):
        return self.shift_records.filter(deleted=False, actual_approval=True).count() * 400    

    def __str__(self):
        return self.reporting_manager
        
    class Meta:
        ordering = ['-created_on']

class PerDayRecord(BaseModel):

    allowanceId = models.ForeignKey(
        AllowanceData, related_name='shift_records')
    start_date = models.DateField(blank=False)
    end_date = models.DateField(blank=False)
    start_time = models.TimeField(blank=True, null=True)
    end_time = models.TimeField(blank=True, null=True)
    objects = PerDayRecordManager()
    pmo_approval=models.NullBooleanField()
    group_head_approval=models.NullBooleanField()
    actual_approval=models.NullBooleanField()


    def  getMonth(self):
        return self.date.getMonth
        
    def getYear(self) :
        return self.date.year    

    def getApprovelStatus(self):
        if self.pmo_approval is None:
           return "Yet To Review By PMO"
        if self.pmo_approval is True and self.group_head_approval is None:
           return "Yet To Review By Group Head"  
        if self.pmo_approval is False:  
            return "Rejected <i class='fa fa-ban' aria-hidden='true'></i>"
        if self.actual_approval is True:  
            return "Approved <i class='fa fa-check-circle' aria-hidden='true'></i>"

