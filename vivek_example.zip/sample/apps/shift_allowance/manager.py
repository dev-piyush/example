from .querysets import AllowanceDataQueryset,PerDayRecordQueryset
from framework.manager import BaseManager
from .allowance_methods import AllowanceDataMethods, PerDayRecordMethods


class PerDayRecordManager(BaseManager,PerDayRecordMethods):
    queryset = PerDayRecordQueryset

   

class AllowanceDataManager(BaseManager,AllowanceDataMethods):
    queryset = AllowanceDataQueryset
