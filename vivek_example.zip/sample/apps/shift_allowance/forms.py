from django.db import models
from django.forms import ModelForm
from .models import AllowanceData, PerDayRecord
import calendar
import datetime
from django import forms
from django.forms import inlineformset_factory
from framework.forms import BaseModelForm
from account_master.models import Account , Department , SPOC

class AllowanceForm(BaseModelForm):

    employee_ID =forms.CharField( required=True, widget=forms.TextInput(attrs={'class': 'required ',
                            'placeholder': 'Employee ID'}))
    employee_name =forms.CharField(required=True, widget=forms.TextInput(attrs={'class': 'required ',
                            'placeholder': 'Employee Name'}))
    resource_email =forms.CharField(label='Employee Mail_ID',required=True, widget=forms.TextInput(attrs={'class': 'required ',
                            'placeholder': 'Employee Mail'}))

    account = forms.ModelChoiceField(required=True, queryset=Account.objects.all().filter(enable_for_shift_allowance=True), empty_label="Select Account..", 
                        widget=forms.Select(attrs={'class': 'required '}))

    # department = forms.ModelChoiceField(required=True, queryset=Department.objects.all(), 
    #       empty_label="Select Department..", 
    #         widget=forms.Select(attrs={'class': 'required '}))

    group_head = forms.ModelChoiceField(required=True, queryset=SPOC.objects.all(), 
          empty_label="Select Group Head..", 
            widget=forms.Select(attrs={'class': 'required '}))
    
    reporting_manager=forms.CharField(required=True, widget=forms.TextInput(attrs={'class': 'required ',
                                 'placeholder': 'Reporting Manager'}))
    class Meta:

        model = AllowanceData
        fields = [ 'employee_ID' ,'employee_name', 'resource_email', 'account', 
                  'reporting_manager', 'group_head']
                  

perDayformSet = inlineformset_factory(AllowanceData, PerDayRecord, fields=('start_date', 'end_date',
                      'start_time' ,'end_time'), extra=1,
                       widgets={
          'start_date': forms.TextInput(attrs={'class': 'required form-control datepicker_field', 'placeholder': 'YYYY-MM-DD'}),
          'start_time': forms.TextInput(attrs={'class': 'required form-control houronly', 'placeholder': 'HH:MM'}),
          'end_date': forms.TextInput(attrs={'class': 'required form-control datepicker_field', 'placeholder': 'YYYY-MM-DD'}),
          'end_time': forms.TextInput(attrs={'class': 'required form-control houronly', 'placeholder': 'HH:MM'}),
                            }

         )

perDayUpdateformSet = inlineformset_factory(AllowanceData, PerDayRecord, fields=('start_date', 'end_date',
                      'start_time' ,'end_time'), extra=0,
                       widgets={
          'start_date': forms.TextInput(attrs={'class': 'required form-control datepicker_field', 'placeholder': 'YYYY-MM-DD'}),
          'start_time': forms.TextInput(attrs={'class': 'required form-control houronly', 'placeholder': 'HH:MM'}),
          'end_date': forms.TextInput(attrs={'class': 'required form-control datepicker_field', 'placeholder': 'YYYY-MM-DD'}),
          'end_time': forms.TextInput(attrs={'class': 'required form-control houronly', 'placeholder': 'HH:MM'}),
                            }

         )
