from django.http import HttpResponseRedirect
from framework.views import BaseListView, LoginRequiredView
from .models import *
from .forms import *
from django.views.generic.list import ListView
from django.views.generic.edit import CreateView 
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from django.urls import reverse_lazy
from .filters import BillingFilter,MONTH_CHOICES
from django.shortcuts import render ,redirect
from candidature_master.models import Candidature
from sow_master.models import SOW
import xlrd
import os
from django.conf import settings
import datetime
from django.db.models import Sum
from django.contrib.auth.decorators import login_required
from .exceptions import *
import logging
# Get an instance of a logger
logger = logging.getLogger('info')




# class BillingList(BaseListView, LoginRequiredView):
#     model = Billing_Record
#     filter_class = BillingFilter

class BillingList(BaseListView, LoginRequiredView):
    model = Billing_Record
    filter_class = BillingFilter
    template_name = 'invoice_master/uploaded_billing_list.html'
    
    def get_context_data(self, *args, **kwargs):
        # Call the base implementation first to get a context
        context = super(BillingList, self).get_context_data(*args, **kwargs)
        # add whatever to your context:
        context['month_choices'] = MONTH_CHOICES
        return context
    

class AdjustedHours(ListView, LoginRequiredView):
    
    template_name = 'invoice_master/adjusted_hour_list.html'    
    
    def get_queryset(self):
        queryset = Billing_Record.objects.get(pk=self.kwargs.get('pk'))
        return queryset 


class BillingCreate(CreateView, LoginRequiredView):
    model = Billing
    form_class = BillingForm

    def get_success_url(self):
        return reverse_lazy('billing_list')

    def form_valid(self, form):
        form.save()
        return HttpResponseRedirect(self.get_success_url())


class BillingUpdate(UpdateView, LoginRequiredView):
    model = Billing
    form_class = BillingForm
    template_name_suffix = '_update_form'
    success_url = reverse_lazy('billing_list')


class BillingDelete(DeleteView, LoginRequiredView):
    model = Billing
    success_url = reverse_lazy('billing_list')


@login_required(login_url=reverse_lazy('login'))
def billing_upload_home(request):
    form = FileForm()
    return render(request, 'invoice_master/upload_file.html', {'form': form})

def billing_upload(request):
    if request.method == 'POST':
        form = FileForm(request.POST, request.FILES)
        if form.is_valid():
            file_object=form.save(commit=False)
            file_object.save()
            file_id=file_object.id
            save_file_todataBase(file_id)
            object_list=Billing_Record.objects.filter(billing_file=file_object)
            logger.info('New Invoice file is uploaded!')

            return render(request,'invoice_master/uploaded_billing_list.html' ,
                    {'object_list': object_list ,  'search_option':False})    

def save_file_todataBase(file_id):
    
    file=Billing_Files.objects.get(pk=file_id)
    file_url=file.file.url
    print file_url
    workbook = xlrd.open_workbook(file_url)
    sh = workbook.sheet_by_index(0)
    for rownum in range(1, sh.nrows):       
            row_values = sh.row_values(rownum)
            emp_id=str(int(row_values[3]))            
            sow=SOW.objects.filter(SOW_ID=row_values[2])
            if sow.count() < 1 :
                try :
                    raise SOWNotFoundError("sow error")
                except :
                    logger.info('No SOW found with sow No : '+  row_values[2] +'!') 
            
            elif sow.count() > 1:
                try :
                    raise MultipleSOWFondError("multple sow error")
                except:
                    logger.info('Multiple SOW found !') 
            else :
                candidature=Candidature.objects.all().filter(
                    resource__employee_id=str(int(row_values[3]))).filter(
                    resource_request__in=sow[0].resource_requests.all())
                
                if candidature.count() < 1 :
                    try :
                        raise ResourceNotFoundError("resorce error")
                    except:
                        logger.info("no resorce found !")
                else :
                    billing=Billing_Record()
                    billing.candidature=candidature[0]
                    billing.billing_file=file
                    date = datetime.datetime(*xlrd.xldate_as_tuple(row_values[0], workbook.datemode))
                    billing.billing_month=date.month
                    billing.billing_year=date.year
                    billing.ps_id=str(int(row_values[1]))
                    billing.sow = row_values[2]
                    billing.employee_id =str(int(row_values[3]))   
                    billing.resource_name = row_values[4]
                    billing.actual_hour= float(row_values[5])
                    billing.billable_hour=float(row_values[6])
                    billing.invoiced_hour=float(row_values[7])
                    billing.pending_hour=float(billing.billable_hour-billing.invoiced_hour)
                    hour_to_adjust= float(row_values[8] or 0)
                    if hour_to_adjust > 0:
                        billing.save()
                        billing_record_prevoius=Billing_Record.objects.filter(candidature=candidature 
                            , pending_hour__gt = 0).order_by('created_on')
                        
                        
                        for record in billing_record_prevoius:
                            if hour_to_adjust> 0:
                                hours_found=0
                                if record.pending_hour >= hour_to_adjust :  
                                      hours_found=hour_to_adjust
                                else:
                                      hours_found=record.pending_hour
        
                                adjusted_hours= Adjusted_hours()                            
                                adjusted_hours.billing_record=billing
                                adjusted_hours.previous_billing_record=record
                                adjusted_hours.adjusted_hour=hours_found
                                adjusted_hours.save()
                                record.pending_hour=record.pending_hour-hours_found
                                record.save()
                                hour_to_adjust=hour_to_adjust-hours_found
                            else:
                                break;
                                
                                                            
                    else :           
                        billing.save()

       
                
                

    
                         
            
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 
                 