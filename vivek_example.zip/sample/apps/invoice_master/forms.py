from django import forms
from .models import *
import calendar
import datetime
from framework.enums import *
from framework.forms import BaseModelForm

from django.contrib.admin.widgets import AdminFileWidget


class BillingForm(BaseModelForm):
    candidature = forms.ModelChoiceField(
        Candidature.objects.billable())
    attached_file = forms.FileField(widget=AdminFileWidget)

    class Meta:
        model = Billing
        exclude = ['created_on', 'created_by', 'deleted',
                   'last_moddified_on', 'last_moddified_by', 'version']


class BulkBillingForm(forms.Form):
    SOW = forms.CharField(max_length=100)
    MONTH_CHOICES = list((m, m) for m in calendar.month_name[1:])
    YEAR_CHOICES = (
        ('2016', '2016'),
        ('2017', '2017'),
        ('2018', '2018'),
        ('2019', '2019'),
    )
    month = forms.ChoiceField(choices=MONTH_CHOICES,
                              initial=datetime.datetime.now().strftime('%B'))
    year = forms.ChoiceField(choices=YEAR_CHOICES, initial='2017')
    actual_hours = forms.FloatField(initial=0)
    pending_billing = forms.FloatField(initial=0)
    leaves = forms.FloatField(initial=0)
    actual_billing = forms.FloatField(initial=0)
    pending_revenue = forms.FloatField(initial=0)
    leaves_revenue = forms.FloatField(initial=0)
    leaves = forms.FloatField(initial=0)
    actual_billing = forms.FloatField(initial=0)
    pending_revenue = forms.FloatField(initial=0)
    leaves_revenue = forms.FloatField(initial=0)
    pending_revenue = forms.FloatField(initial=0)
    leaves_revenue = forms.FloatField(initial=0)


class FileForm(forms.ModelForm):
    
    class Meta:

        model = Billing_Files
        fields = ['file'] 