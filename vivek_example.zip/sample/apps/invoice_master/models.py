# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from framework.models import BaseModel
from candidature_master.models import Candidature
# Create your models here.
import calendar
import datetime


class Billing(BaseModel):
    """docstring for Billing"""
    candidature = models.ForeignKey(Candidature, related_name='billing_info')
    MONTH_CHOICES = list((m, m) for m in calendar.month_name[1:])
    YEAR_CHOICES = (
        ('2016', '2016'),
        ('2017', '2017'),
        ('2018', '2018'),
        ('2019', '2019'),
    )
    month = models.CharField(max_length=100, choices=MONTH_CHOICES,
                             default=datetime.datetime.now().strftime('%B'))
    year = models.CharField(
        max_length=100, choices=YEAR_CHOICES, default='10017')
    actual_hours = models.FloatField(default=0)
    pending_billing = models.FloatField(default=0)
    leaves = models.FloatField(default=0)
    actual_billing = models.FloatField(default=0)
    pending_revenue = models.FloatField(default=0)
    leaves_revenue = models.FloatField(default=0)
    #attached_file = models.FileField(upload_to='attachments')
    remarks = models.TextField(null=True, blank=True)

    class Meta:
        ordering = ['-created_on']
        db_table = 'demand_tracker_billing'


class Billing_Files(BaseModel):
    file = models.FileField(upload_to='files/%Y/%m/%d')


class Billing_Record(BaseModel):
    billing_file=models.ForeignKey(Billing_Files, null=True,related_name='billing_file')
    candidature= models.ForeignKey(Candidature, related_name='candidature_billing')
    billing_month=models.IntegerField(null=True, blank=True)
    billing_year=models.IntegerField(null=True, blank=True)
    ps_id = models.CharField(max_length=30) 
    sow = models.CharField(max_length=30)  
    employee_id = models.CharField(max_length=30)   
    resource_name = models.CharField(max_length=50)
    actual_hour= models.FloatField()
    billable_hour= models.FloatField()
    invoiced_hour= models.FloatField()
    pending_hour= models.FloatField()
    
    def getMonth(self):
        return calendar.month_name[self.billing_month]
    
    def get_total_adjusted_hours(self):
        hours=0
        if self.adjustment_done.count() > 0:
            for record in self.adjustment_done.all():
                hours+= record.adjusted_hour
        return hours
        
        

class Adjusted_hours(BaseModel):
    billing_record=models.ForeignKey(Billing_Record, related_name='adjustment_done')
    previous_billing_record=models.ForeignKey(Billing_Record, null=True, related_name='adjustment_logs')
    adjusted_hour=models.FloatField()
        
    

