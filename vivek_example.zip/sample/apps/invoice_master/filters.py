
import django_filters
from .models import Billing_Record

MONTH_CHOICES = (
    ('1', 'January'),
    ('2', 'February'),
    ('3', 'March'),
    ('4', 'April'),
    ('5', 'May'),
    ('6', 'June'),
    ('7', 'July'),
    ('8', 'August'),
    ('9', 'September'),
    ('10', 'October'),
    ('11', 'November'),
    ('12', 'December'),
      )

class BillingFilter(django_filters.FilterSet):
    
    month=django_filters.ChoiceFilter( name='billing_month', lookup_expr='icontains',
                                       choices=MONTH_CHOICES)
    
    class Meta:
        model = Billing_Record
        fields = ['employee_id','billing_year',]
