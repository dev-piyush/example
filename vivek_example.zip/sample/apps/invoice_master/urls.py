from django.conf.urls import url
from .views import *
urlpatterns = [

    url(r'^billing/$', BillingList.as_view(), name='billing_list'),
    url(r'^billing_create/$', BillingCreate.as_view(), name='billing_create'),
    url(r'^billing_update/(?P<pk>\d+)/$',
        BillingUpdate.as_view(), name='billing_update'),
    url(r'^billing_delete/(?P<pk>\d+)/$',
        BillingDelete.as_view(), name='billing_delete'),

    url(r'^adjusted_hours/(?P<pk>\d+)/$',
        AdjustedHours.as_view(), name='adjusted_hours'),

    url(r'^billing_upload_home/$',billing_upload_home, name='billing_upload_home'),
    url(r'^billing_upload/$',billing_upload, name='billing_upload'),


]