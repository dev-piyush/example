from django.db import models
from django.forms import ModelForm
from .models import Expense , Particular
import calendar
import datetime
from django import forms
from django.forms import inlineformset_factory
from framework.forms import BaseModelForm
from resource_master.models  import Resource 
from account_master.models import Account
from framework.enums import *


class ExpenseForm(BaseModelForm):
    employee_ID =forms.CharField( required=True, widget=forms.TextInput(attrs={'class': 'required ',
                            'placeholder': 'Employee ID'}))
    employee_name =forms.CharField(required=True, widget=forms.TextInput(attrs={'class': 'required ',
                            'placeholder': 'Employee Name'}))
    account_name = forms.ModelChoiceField(required=True, queryset=Account.objects.all().filter(enable_for_expense_master=True), empty_label="Select Account..", 
                        widget=forms.Select(attrs={'class': 'required '}))
    date=forms.CharField(required=True, widget=forms.TextInput(attrs={'class': 'required datepicker_field',
                                 'placeholder': 'YYYY-MM-DD'}))
    class Meta:
        model = Expense
        fields = ['employee_ID' ,'employee_name','date','account_name']
        
class ParticularForm(BaseModelForm):
    
    type= forms.ChoiceField( label='Expense Type', choices=EXPENSE_CHOICES,
        widget=forms.Select(attrs={'class': 'required form-control'}))
    expenses_date=forms.CharField(label='Expense Date',
        widget=forms.TextInput(attrs={'class': 'required form-control datepicker_field','placeholder': 'YYYY-MM-DD'}))
    amount=forms.CharField( label='Amount',
        widget=forms.TextInput(attrs={'class': 'required form-control ', 'placeholder': 'Amount'} ))
    description = forms.CharField( label='Description', 
        widget=forms.Textarea(attrs={'class': 'required form-control',
            'placeholder': 'Please write some description', 'rows':2, 'cols':35}))
    class Meta:
        model = Particular
        fields = ['type','expenses_date','amount','description']      
        


ParticularformSet = inlineformset_factory(Expense, Particular, form = ParticularForm, extra=1,)
