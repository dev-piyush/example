# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
from django.http import HttpResponseRedirect
from django.http import HttpResponse ,  JsonResponse
from framework.views import BaseListView
from .models import *
from .forms import *
from django.views.generic.list import ListView
from django.views.generic.detail import DetailView
from django.views.generic.edit import CreateView
from django.views.generic.edit import UpdateView
from django.views.generic.edit import DeleteView
from framework.views import LoginRequiredView
from django.urls import reverse_lazy
from django.shortcuts import redirect
from django.contrib import messages
from .forms import ExpenseForm , ParticularformSet
from .exceptions import ResourceNotFoundError
from .filters import ExpenseFilter
from resource_master.models import Resource
from django.contrib import messages
import logging
# Get an instance of a logger
logger = logging.getLogger('info')






class ExpensesList(BaseListView, LoginRequiredView):
    logger.info('Getting all expense list!')
    filter_class=ExpenseFilter
    model = Expense
    template_name = 'expense_master/expense_list.html'
    
class AllExpenses(ListView, LoginRequiredView):
    model = Expense
    template_name = 'expense_master/all_expense_list.html'    
    
    def get_queryset(self):
        queryset = Expense.objects.get(pk=self.kwargs.get('pk'))
        return queryset 


class ExpenseCreate(CreateView, LoginRequiredView):
    model = Expense
    fields = ['date','account_name',]
    template_name = 'expense_master/expense_create.html'
    success_url = reverse_lazy('expenses_list')

    def get_context_data(self, **kwargs):
        context = super(ExpenseCreate, self).get_context_data(**kwargs)
        if self.request.POST:
            context['employee_id'] =self.request.POST.get("employee_ID", None)
            context['employee_name'] =self.request.POST.get("employee_name", None)
            context['expense_form'] = ExpenseForm(self.request.POST)
            context['particular_formSet'] = ParticularformSet(self.request.POST, self.request.FILES)
        else:
            context['expense_form'] = ExpenseForm()
            context['particular_formSet'] = ParticularformSet(instance=Expense())
        return context
    
    def form_valid(self, form):
        context = self.get_context_data()
        employee_id=context['employee_id']
        employee_name = context['employee_name']
        resource =None
        resource=Resource.objects.get_resource(employee_id=employee_id,employee_name=employee_name)
        if resource is None:
            try:
                raise ResourceNotFoundError("Error")
            except:
                logger.info("No Resource Found")

            messages.error(self.request,'NO Resource Found !! ')
            return self.render_to_response(self.get_context_data(form=form)) 
            
        expense_form = context['expense_form']
        particular_formSet = context['particular_formSet']
        
        if expense_form.is_valid() and particular_formSet.is_valid():
            self.object = expense_form.save(commit=False)
            self.object.resource=resource
            self.object.save()
            particular_formSet.instance = self.object
            particular_formSet.save()
            logger.info('New Expense Report Is Created!')
            return HttpResponseRedirect(self.success_url)
        else:
            return self.render_to_response(self.get_context_data(expense_form=expense_form ,particular_formSet=particular_formSet))
     
class CreateExpenseInvoice(DetailView , LoginRequiredView):     
    model = Expense
    template_name='expense_master/expense_invoice.html'
    
        

