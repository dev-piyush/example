class ResourceNotFoundError(Exception):    
    pass
