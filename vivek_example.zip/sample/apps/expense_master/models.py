# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models
from framework.models import BaseModel
from framework.enums import *
from resource_master.models import Resource 
from account_master.models import Account


class Expense(BaseModel):
    """docstring for  expense"""
    
    resource = models.ForeignKey(Resource, related_name='resource')
    date = models.DateTimeField(null=True, blank=True)
    account_name=  models.ForeignKey(Account,  null=True , related_name='account')

    class Meta:
        ordering = ['-created_on']
        
    def get_total_expense(self):
        expense=0
        if self.expenses.count() > 0:
            for record in self.expenses.all():
                expense+= record.amount
        return expense  
      
    def getTpyeCount(self):
        type_count= dict((key,[]) for key , vlaue  in EXPENSE_CHOICES)
    
        for particular in self.expenses.all():
            type_list=type_count[particular.type]
            type_list.append(particular)          
        return type_count        
            
          
      

class Particular(BaseModel):
    expense=models.ForeignKey(Expense, related_name='expenses')   
    type= models.CharField(max_length=50 , choices=EXPENSE_CHOICES) 
    expenses_date=  models.DateTimeField(null=True, blank=True) 
    description =  models.CharField(max_length=200 )
    amount= models.FloatField()
    
    
        
        
