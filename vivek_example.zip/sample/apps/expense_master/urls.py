from django.conf.urls import url
from .views import *
from . import views
urlpatterns = [

    url(r'^expenses/$', ExpensesList.as_view(),
        name='expenses_list'),
    url(r'^expense_create/$', ExpenseCreate.as_view(),
        name='expense_create'),
    url(r'^all_expenses/(?P<pk>\d+)/$',
        AllExpenses.as_view(), name='all_expenses'), 
    url(r'^create_expense_invoice/(?P<pk>\d+)/$',
        CreateExpenseInvoice.as_view(), name='create_expense_invoice'),             
]
