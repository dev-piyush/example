from django.contrib.auth.models import User
import django_filters
from .models import Billing, SOW, Resource, ResourceRequest, Candidature, SELECTION_TYPE_CHOICES
from distutils.util import strtobool
BOOLEAN_CHOICES = (('false', 'False'), ('true', 'True'),)


class ResourceFilter(django_filters.FilterSet):
    is_blocked = django_filters.TypedChoiceFilter(
        choices=BOOLEAN_CHOICES, coerce=strtobool)
    employee_name = django_filters.CharFilter(lookup_expr='icontains')

    class Meta:
        model = Resource
        fields = ['employee_id', 'employee_name', 'is_blocked']


class ResourceRequestFilter(django_filters.FilterSet):
    requestor = django_filters.CharFilter(lookup_expr='icontains')
    RR = django_filters.CharFilter(lookup_expr='icontains')
    job_code = django_filters.CharFilter(lookup_expr='icontains')
    demand_status = django_filters.CharFilter()
    technology = django_filters.CharFilter(
        name='technology__name', lookup_expr='icontains')
    spoc = django_filters.CharFilter(
        name='SPOC__name')

    class Meta:
        model = ResourceRequest
        fields = ['RR', 'job_code', 'requestor']


class CandidatureFilter(django_filters.FilterSet):
    actual_selection_status = django_filters.TypedChoiceFilter(
        choices=SELECTION_TYPE_CHOICES)
    resource__employee_name = django_filters.CharFilter(
        name='resource__employee_name', lookup_expr='icontains')
    resource_request__RR = django_filters.CharFilter(
        name='resource_request__RR', lookup_expr='icontains')
    resource_request__job_code = django_filters.CharFilter(
        name='resource_request__job_code', lookup_expr='icontains')
    resource__employee_id = django_filters.CharFilter(
        name='resource__employee_id', lookup_expr='icontains')
    resource_request__requestor = django_filters.CharFilter(
        name='resource_request__requestor', lookup_expr='icontains')
    resource_request__demand_status = django_filters.CharFilter(
        name='resource_request__demand_status', lookup_expr='icontains')
    resource_request__SPOC = django_filters.CharFilter(
        name='resource_request__SPOC__name', lookup_expr='icontains')
    resource_request__id = django_filters.NumberFilter(
        name='resource_request__id', lookup_expr='icontains')

    class Meta:
        model = Candidature
        fields = ['resource_request__RR', 'resource_request__job_code',
                  'resource__employee_id',
                  'resource__employee_name', 'actual_selection_status']


class SOWFilter(django_filters.FilterSet):
    sow_id = django_filters.CharFilter(name='sow_id', lookup_expr='icontains')
    status = django_filters.CharFilter(name='status', lookup_expr='icontains')
    location = django_filters.CharFilter(
        name='location__name', lookup_expr='icontains')

    class Meta:
        model = SOW
        fields = ['sow_id', 'status', 'location']


class BillingFilter(django_filters.FilterSet):

    class Meta:
        model = Billing
        exclude = ['attached_file']
