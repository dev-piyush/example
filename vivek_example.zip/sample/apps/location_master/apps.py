from django.apps import AppConfig


class LocationMasterConfig(AppConfig):
    name = 'location_master'
