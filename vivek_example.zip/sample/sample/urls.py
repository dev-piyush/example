from django.conf.urls import url, include
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static
from .views import (index, login_user, dashboard,
                    logout_view, export_excel, send_notifications_by_email)


urlpatterns = [
    url(r'^in/$', index, name='home'),
    url(r'^in/login', login_user, name='login'),
    url(r'^in/logout/', logout_view, name='logout'),
    url(r'^in/dashboard/', dashboard, name='dashboard'),
    url(r'^in/export_excel/', export_excel, name='export_excel'),
    url(r'^in/sendNotification/',
        send_notifications_by_email, name='send_notifications_by_email'),
    url(r'^in/candidature_master/', include('candidature_master.urls')),
    url(r'^in/lead_management/', include('lead_management.urls')),
    url(r'^in/resource_master/', include('resource_master.urls')),
    url(r'^in/demand_master/', include('demand_master.urls')),
    url(r'^in/sow_master/', include('sow_master.urls')),
    url(r'^in/invoice_master/', include('invoice_master.urls')),
    url(r'^in/contacts_master/', include('contacts_master.urls')),
    url(r'^in/shift_allowance/', include('shift_allowance.urls')),
    url(r'^in/admin/', admin.site.urls),
    url(r'^in/office365_calendar/', include('office365_calendar.urls')),
    url(r'^in/user_management/', include('user_management.urls')),
    url(r'^in/tinymce/', include('tinymce.urls')),
    url(r'^in/questionnaire_master/', include('questionnaire_master.urls')),
    url(r'^in/expense_master/', include('expense_master.urls')),
]

if settings.DEBUG is True:
    urlpatterns = urlpatterns + \
        static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
if settings.DEBUG is True:
    urlpatterns = urlpatterns + \
        static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
