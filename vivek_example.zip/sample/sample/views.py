from django.shortcuts import render
from django.http import *
from django.shortcuts import redirect
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate, login, logout
from django.conf import settings
from django.urls import reverse, reverse_lazy
from resource_master.models import Resource
from candidature_master.models import Candidature
from demand_master.models import ResourceRequest
from django.db.models import Count
from django.contrib.auth.signals import user_logged_in
from django.contrib.auth.models import User
from user_management.models import Profile as UserProfile
import os
from django.http import HttpResponse
from office365_calendar.views import *
from office365_calendar.authhelper import get_signin_url
import logging
logger = logging.getLogger('info')


def index(request):
    logger.info('Request received For Home Page!')
    if request.user.is_authenticated():
        logger.info('User already Logged in redirecting to Dashboard!')
        return redirect(reverse('dashboard'))
    logger.info('Request Prcessing For Home Page!')
    return render(request, 'index.html', {'msz': "message"})


def user_logged_in_handler(sender, request, user, **kwargs):

    if UserProfile.objects.filter(user=user).count() == 0:
        logger.info(
            'User Profile Does Not Exist Creating a new one for user.')
        user_profile = UserProfile(user=user)
        user_profile.save()
        logger.info('User Profile Already exists.')


user_logged_in.connect(user_logged_in_handler, sender=User)


def login_user(request):
    logger.info('Request received For Login Page!')
    if request.user.is_authenticated():
        logger.info('User already Logged in redirecting to Dashboard!')
        return redirect(reverse('dashboard'))

    logout(request)
    username = password = ''
    if request.POST:
        username = request.POST['username']
        password = request.POST['password']
        try:
            if 'remember' in request.POST and request.POST['remember']:
                remember = request.POST['remember']
            else:
                remember = False
        except KeyError:
            remember = False
        logger.info('authenticating the user!')
        user = authenticate(username=username, password=password)
        if user is not None:
            logger.info('authenticated the user and Found one!')
            logger.info('Checking if user is active!')
            if user.is_active:
                logger.info('user found active!')
                logger.info('Login to Application Now!')
                login(request, user)
                outlook_auth_token = UserProfile.objects.get(
                    user=user).outlook_auth_token
                if user.is_staff and not outlook_auth_token:
                    logger.info(
                        """authenticated the user and being
                         a staff memeber and unavailability of
                         outlook_auth_token
                         redirecting user to logging with Outlook
                         """)
                    redirect_uri = request.build_absolute_uri(
                        reverse('gettoken'))
                    sign_in_url = get_signin_url(redirect_uri)
                    return HttpResponseRedirect(sign_in_url)

                if remember:
                    request.session.set_expiry(0)

                return HttpResponseRedirect(reverse('dashboard'))
            else:
                logger.info(
                    'Checking if user is active \
                    failed found user is inactive!')
        else:
            messages = []
            messages.append(
                {'tags': 'danger',
                 'text': 'Invalid username or password.Please try again.'
                 }
            )
            return render(request, 'login.html', {'messages': messages})
    return render(request, 'login.html', {})


@login_required(login_url=reverse_lazy('login'))
def dashboard(request):
    logger.info('Request received For Dashboard!')
    total_resource_count = Resource.objects.all()
    candidatures = Candidature.objects.all()
    onboarded_candidatures = candidatures.onboarded()
    released_candidatures = candidatures.released()
    projected_candidatures = candidatures.selected_yet_to_onboard()
    in_progress_candidature = candidatures.projected()
    total_profile_submitted = candidatures.profile_submitted()
    open_postions_as_per_department = ResourceRequest.objects.all().open(
    ).values('department__name').annotate(
        count=Count('id')).order_by('-count')
    open_postions_as_per_spoc = ResourceRequest.objects.all().open().values(
        'SPOC__name').annotate(
        count=Count('id')).order_by('-count')
    open_position_as_per_technology = ResourceRequest.objects.all().open(
    ).values('technology__name').annotate(
        count=Count('id')).order_by('-count')
    logger.info('Request Processed For dashboard!')
    return render(request, 'dashboard.html',
                  {'total_resource_count': total_resource_count,
                   'onboarded_candidatures': onboarded_candidatures,
                   'released_candidatures': released_candidatures,
                   'projected_candidatures': projected_candidatures,
                   'in_progress_candidature': in_progress_candidature,
                   'total_profile_submitted': total_profile_submitted,
                   'open_postions_as_per_department':
                   open_postions_as_per_department,
                   'open_postions_as_per_spoc':
                   open_postions_as_per_spoc,
                   'open_position_as_per_technology':
                   open_position_as_per_technology
                   })


@login_required(login_url=reverse_lazy('login'))
def logout_view(request):
    logger.info('Request received For logout!')
    logout(request)
    logger.info('Request Processed For logout!')
    logger.info('Redirecting user to Home page!')
    return HttpResponseRedirect(reverse('home'))


def export_excel(request):
    path = request.POST.get('path')
    username = request.POST.get('username')
    password = request.POST.get('password')
    if username and password:
        user = authenticate(username=username, password=password)
        if user is not None:
            file_path = os.path.join(settings.MEDIA_ROOT, path)
            if os.path.exists(file_path):
                file_extension = os.path.splitext(file_path)
                if file_extension in['xls', 'xlsx']:
                    with open(file_path, 'rb') as fh:
                        response = HttpResponse(
                            fh.read(), content_type="application/vnd.ms-excel")
                        response[
                            'Content-Disposition'] = 'attachment\
                            filename =' + os.path.basename(file_path)
                        return response
        return HttpResponse("Invalid username or password.")
    else:
        return HttpResponse("Please Provide username and password.")


def send_notifications_by_email(request):
    if request.POST:
        to = request.POST.get('to', '')
        subject = request.POST.get('subject', '')
        content = request.POST.get('content', '')
        userprofile = UserProfile.objects.get(user=request.user)
        access_token = userprofile.get_outlook_access_token()
        send_email(access_token, content, subject, to)
    return HttpResponse('Email Sent..')
