$(document).ready(function() {

  
$('.questionaire_formset_row').formset({
        
        deleteText: 'remove',
        prefix:'questions',
        deleteCssClass:'pull-right btn delete-link',
        addCssClass:'pull-right btn add-link',
        addText:'more',
        deleteCallback:function(){
   
   
        }
});



 $("#submitQuestionform").click(function(e) {

        //prevent Default functionality
        e.preventDefault();
        var totalform=$('#id_questions-TOTAL_FORMS').val();
        var errHtml='<div class="alert alert-danger"><h6 >Error : </h6></div>';
          function validateQuestionFormSet(){

              for(i=0;i<=totalform;i++)
                    {
         question=$('#id_questions-'+i+'-text').val();
         
              if(question===""){
              errHtml +='<p>Please Make Sure All Questions Box Are Entered .</p>';
              return false;
                }
              
                }
             return true;
           }
        
     if(validateQuestionFormSet())
        {
          $("#question_form").submit();       
        }
        else{
           bootbox.alert({
        message: errHtml,
        callback: function () {
            console.log('This was logged in the callback!');
          }
         }) 
        return false;
         }

  });


});