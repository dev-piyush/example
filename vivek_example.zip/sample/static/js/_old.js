$("#send_questionnaire_invite").click(function(){
	send_questionnaire_invite_url=('#send_questionnaire_invite_url').val()
    $.get(send_questionnaire_invite_url function(data, status){
        alert("Done");
    });
});