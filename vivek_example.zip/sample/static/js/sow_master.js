$(document).ready(function() {

  var ShowSowLink="<a href='#sow_commited_days' id='sow_commited_days' class='btn btn-link'>Show Sow Forcast Values</a>"
$("input[id=id_soft_copy]").parent().removeClass('col-sm-10').removeClass('col-lg-10')
                 .addClass('col-lg-6').addClass('col-sm-6').after(ShowSowLink);


$("#sow_commited_days").on("click", function (e) {
    
        start_date=$('#id_start_date').val();
        end_date=$("#id_end_date").val();
        if (start_date=='' || end_date=='')
        {   
                 bootbox.alert({
                  message: "Select Both Start Date And End Date !",
                  size: 'small'
                 });
            return false;
        }
        if ( start_date > end_date )
        {   
            bootbox.alert({
                  message: "Start Date Should Be Greater !!",
                  size: 'small'
                 });      
            return false;
        }
        url="/in/sow_master/calculate_commited_days?start_date="+start_date+"&end_date="+end_date;
        $.ajax({
        url :url,
        success : function(data) {
        $("[name^='commited_spend_days']").val(0)

        sow_commited_days=JSON.parse(data)
        var comited_days_grop_by_year=_.groupBy(sow_commited_days, function(d){return d.year});
        $.each(comited_days_grop_by_year, function(key, value) {
               var total_days=0;
               $.each(value, function(key, value) {
               total_days+=value["days"]
               }) 
        $("#id_commited_spend_days_"+key+"").val(total_days)
        })

        ShowForcastValues(sow_commited_days)
        },
        error : function(xhr,errmsg,err) {
         alert("some error occured");
        }  
       }); 
       
 });

function ShowForcastValues(sow_commited_days){
       var bill_rate=$('#id_bill_rate').val();
  var sow_detail_html = '<div class="col-sm-12 ">';
      sow_detail_html += '<table class="table table-hover table-striped" >';
      sow_detail_html += '<tr><th> Month </th>';
      sow_detail_html += '<th> Year  </th>';
      sow_detail_html += '<th> Value </th></tr>';

      for(i=0 ; i< sow_commited_days.length; i ++){
      sow_detail_html += '<tr>  <td>' + sow_commited_days[i].month+'</td>';
      sow_detail_html += '<td>' + sow_commited_days[i].year+'</td>';
      sow_detail_html += '<td>' + sow_commited_days[i].days* bill_rate+'</td>';
      }
      sow_detail_html += '</table>'; 
        sow_detail_html += '</div>';
      
       bootbox.alert({
        title: '<strong>Sow Forcast Values</strong>',
        message: sow_detail_html,
        callback: function () {
            console.log('This was logged in the callback!');
          }
         }) 
       
     $('.modal-body').css("height","200px").css("overflow-y","scroll");

}


/*$("#id_end_date").on("dp.hide", function (e) {
     
        start_date=$('#id_start_date').data('date');
        end_date=$("#id_end_date").data('date');
        if(start_date==undefined){
          start_date=$('#id_start_date').val()
          if(start_date=="" || start_date==undefined){
             alert("select start date")
            return false
          }
        }
        if(end_date==""){
            return false
          }
        if (start_date > end_date )
        {
            alert("End Date Should Be Greater !!!")
            return false
        }
        calculate_commited_days(start_date, end_date)       
 });
$("#id_start_date").on("dp.hide", function (e) {
     
        start_date=$('#id_start_date').data('date');
        end_date=$("#id_end_date").data('date');
        if(end_date==undefined){
         end_date=$('#id_end_date').val()
          if(end_date=="" || end_date==undefined){
          return false
          }
        }
        if (start_date > end_date )
        {
            alert("End Date Should Be Greater !!!")
            return false
        }
        calculate_commited_days(start_date, end_date)     
 });
*/
 function calculate_commited_days( start_date, end_date){

       url="/in/sow_master/calculate_commited_days?start_date="+start_date+"&end_date="+end_date;  
       $.ajax({
        url :url,
        success : function(data) {
        $("[name^='commited_spend_days']").val(0)
        sow_commited_days=JSON.parse(data)

        var comited_days_grop_by_year=_.groupBy(sow_commited_days, function(d){return d.year});
        $.each(comited_days_grop_by_year, function(key, value) {
               var total_days=0;
               $.each(value, function(key, value) {
               total_days+=value["days"]
               }) 
        $("#id_commited_spend_days_"+key+"").val(total_days)
        })
 
        },

        error : function(xhr,errmsg,err) {
         
         alert("some error occured");
        }
        
       });

 }

});