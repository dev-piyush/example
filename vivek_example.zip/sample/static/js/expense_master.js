$(document).ready(function() {



$('.expense_formset_row').formset({
        deleteText: 'Remove',
        prefix:'expenses',
        deleteCssClass:' btn btn-link expenxe_delete-row ',
        addCssClass:' btn btn-link add-row',
        addText:'Add More',
        formCssClass:'formset_row',
        deleteCallback:function(){
      

          var noOfForm=$('#id_expenses-TOTAL_FORMS').val();
         if(noOfForm==1){
          alert("Need  atlest one");
          $( "a.add-row" ).trigger( "click" );
           }
        
        }
});

$("#btnPrint").click(function () {
var contents = $("#expense_invoice").html();
var frame1 = $('<iframe />');
frame1[0].name = "frame1";
frame1.css({ "position": "absolute", "top": "-1000000px" });
$("body").append(frame1);
var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
frameDoc.document.open();
//Create a new HTML document.

frameDoc.document.write('<html><head><title>Expense Invoice</title>');
frameDoc.document.write('</head><body>');
//Append the external CSS file.
frameDoc.document.write('<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet" media="all" type="text/css" />');
 
var source = 'bootstrap.min.js';
var script = document.createElement('script');
script.setAttribute('type', 'text/javascript');
script.setAttribute('src', source);

frameDoc.document.write(contents);
frameDoc.document.write('</body></html>');
frameDoc.document.close();
setTimeout(function () {
window.frames["frame1"].focus();
window.frames["frame1"].print();
frame1.remove();
}, 500);
 
 
});
 






 $("#expense_submit").click(function(e) {

        //prevent Default functionality
        e.preventDefault();
        $('.parsley-error').removeClass('parsley-error')

        
  var empcode= $('#id_employee_ID');
  var name = $('#id_employee_name');
  var date = $('#id_date');
  var account = $('#id_account_name option:selected');
  var totalform=$('#id_expenses-TOTAL_FORMS').val();
  

   function validateFormSet(){
     if(!totalform)
      return false;
     for(i=0;i< totalform;i++)
       {
         expense_type = $('#id_expenses-'+i+'-type');
         expense_date=$('#id_expenses-'+i+'-expenses_date');
         amount = $('#id_expenses-'+i+'-amount');
         description =  $('#id_expenses-'+i+'-description');
              if(expense_type.val()===""){
               errHtml +='<p>Please Enter '+(i+1)+ ' expense type.</p>';
               expense_type.addClass('parsley-error')
               return false;} 
            
              if(expense_date.val()===""){
              errHtml +='<p>Please Enter '+(i+1)+ ' days Date.</p>';
              expense_date.addClass('parsley-error')
              return false;
              }

              if(amount.val()===""){
               errHtml +='<p>Please Enter '+(i+1)+ ' amount.</p>';
               amount.addClass('parsley-error')
               return false;}

              if(description.val()===""){
               errHtml +='<p>Please Enter '+(i+1)+ ' description.</p>';
               description.addClass('parsley-error')
               return false;}
             
      }
    return true;
   }
  

      
  

    var errHtml='<div class="alert alert-danger"><h6 >Error : </h6></div>';
    function validateForm() {
            if(empcode.val()===""){
               errHtml +='<p>Please Enter Employee code which should be numeric only .</p>';
               empcode.addClass('parsley-error')
               return false;}
            else if(name.val()===""){
               errHtml +='<p> Please Enter Employee Name.</p>';
               name.addClass('parsley-error')
               return false;}
            else if(date.val()===""){
              errHtml +='<p>Please Enter Date .</p>';
              date.addClass('parsley-error')
              return false;
              }  
            else if(account.val()===""){
               errHtml +='<p> Please Select Account Name.</p>';
               name.addClass('parsley-error')
               return false;}
            
                           
            else   
            return true  ;    
     }

     

      var expense_html='<div class="form-group col-sm-12 ">';
      expense_html += '<table class="table table-hover table-striped" >';
      expense_html += '<tr>  <td> Employee Id </td>  <td>' + empcode.val()+'</td></tr>';
      expense_html += '<tr>  <td> Employee Name </td>  <td>' + name.val()+'</td></tr>';
      expense_html += '<tr>  <td> Date </td>  <td>' + date.val()+'</td></tr>';
      expense_html += '<tr>  <td> Account </td>  <td>' +account.text()+'</td></tr>';
      expense_html += '</table>';
      expense_html += '</div>';  


      var exp_detail_html = '<div class="col-sm-12 ">';
      exp_detail_html += '<table class="table table-hover table-striped" >';
      exp_detail_html += '<caption><strong>Expenses Detail</strong></caption>';
      exp_detail_html += '<tr><th> Expense Type </th>';
      exp_detail_html += '<th> Expense Date  </th>';
      exp_detail_html += '<th> Amount </th>';
      exp_detail_html += '<th> Description </th></tr>';

      for(i=0;i< totalform;i++){
      exp_detail_html += '<tr>  <td>' + $('#id_expenses-'+i+'-type').val()+'</td>';
      exp_detail_html += '<td>' + $('#id_expenses-'+i+'-expenses_date').val()+'</td>';
      exp_detail_html += '<td>' + $('#id_expenses-'+i+'-amount').val()+'</td>';
      exp_detail_html += '<td>' + $('#id_expenses-'+i+'-description').val()+'</td></tr>';
      }
      exp_detail_html += '</table>'; 
        exp_detail_html += '</div>'; 
        expense_html +=   exp_detail_html  
       
  
      if(validateForm() && validateFormSet())
        {
        bootbox.confirm({
        title: "Submit ??",
        message: expense_html,
        buttons: {
            cancel: {
                label: '<i class="fa fa-times"></i> Cancel'
            },
            confirm: {
                label: '<i class="fa fa-check"></i> Confirm'
            }
        },
        callback: function (result) {
            if (result) {
                    $("#expense_form").submit();       
                } 
        }
        });
        }
        else{
           bootbox.alert({
        message: errHtml,
         })

       };

 });

});