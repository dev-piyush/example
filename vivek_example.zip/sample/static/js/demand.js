$(".tag_demand_to_sow").blur(function(){
    var text=$(this)
    var url=$('#tag_demand_to_sow').val()
   if( $(this).val().length > 0 ) {
     
    $.ajax({
    type: 'POST',
    url: url,
    data: {
        'SOW_number':$.trim($(this).val()),
        'demand_id':$.trim($(this).attr('rr_id'))
     },
    success: function(data) {
        if (data.code=='201')
            text.prop('disabled',true);
        bootbox.alert({
        message: data.message,
        size: 'small'
    });
     },
    });
}
});

$(".untag_demand_from_sow").click(function(){

    var url=$('#untag_demand_from_sow').val()
   
     
    $.ajax({
    type: 'POST',
    url: url,
    data: {
        'SOW_number':$.trim($(this).attr('SOW_number')),
        'demand_id':$.trim($(this).attr('rr_id'))
     },
    success: function(data) {
          
           bootbox.alert({
        message: data.message,
        size: 'small'
    });
     },
    });

});

jQuery(document).ready(function() {
 jQuery(".req-control-label").after("<span class='required'>*</span>");
});