jQuery(document).ready(function() {
 jQuery(".req-control-label").after("<span class='required'>*</span>");

 $("label[for$='-clear_id']").hide()
 $("[id$='-clear_id']").hide()

 filelink=$('input[type="file"]').parent().find("a");
  downloadablelink='/'+$(filelink).attr('href')
  $(filelink).attr('href', downloadablelink)

});

 $(document).ready(function() {
    console.log($('input[type=file]').val())
   $('input[type=file]').each(function() {

    if($(this).val()){
        $(this).prop('required',true);
    }
})



          $('.dropdown-toggle').on("click", function() {
  var dropdownList = $('.dropdown-menu'),
  dropdownOffset = $(this).offset(),
  offsetLeft = dropdownOffset.left,
  dropdownWidth = dropdownList.width(),
  docWidth = $(window).width(),

  subDropdown = dropdownList.eq(1),
  subDropdownWidth = subDropdown.width(),

  isDropdownVisible = (offsetLeft + dropdownWidth <= docWidth),
  isSubDropdownVisible = (offsetLeft + dropdownWidth + subDropdownWidth <= docWidth);

  if (!isDropdownVisible || !isSubDropdownVisible) {
        dropdownList.addClass('pull-right');
  } else {
        dropdownList.removeClass('pull-right');
  }
});

          
    $('form:first *:input[type!=hidden]:first').focus();
});

       
            $(function () {
                $('.datetimepicker').datetimepicker({
                  format:"YYYY-M-D h:mm a",
                icons: {
                    time: "fa fa-clock-o",
                    date: "fa fa-calendar",
                    up: "fa fa-arrow-up",
                    down: "fa fa-arrow-down",
                     previous: 'fa fa-arrow-left',
                   next: 'fa fa-arrow-right'
                }
            });

         
            });
    

   



    window.onload = maxWindow;

    function maxWindow() {
     var el = document.body;

  // Supports most browsers and their versions.
  var requestMethod = el.requestFullScreen || el.webkitRequestFullScreen 
  || el.mozRequestFullScreen || el.msRequestFullScreen;

  if (requestMethod) {

    // Native full screen.
    requestMethod.call(el);

  } else if (typeof window.ActiveXObject !== "undefined") {

    // Older IE.
    var wscript = new ActiveXObject("WScript.Shell");

    if (wscript !== null) {
      wscript.SendKeys("{F11}");
    }
  }
    }