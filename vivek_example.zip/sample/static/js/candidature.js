$(document).ready(function() {

   $(".send_questionnaire_invite").click(function(){

  send_questionnaire_invite_url=$(this).attr('mail_url')
    $.get(send_questionnaire_invite_url,function(data, status){
        bootbox.alert({
        message: data.message,
        size: 'small'
          });
       });
   });

/* $('.forcast_formSet_row').formset({
        deleteText: '',
        prefix:'candidature',
        deleteCssClass:' btn btn-link delete_row ',
        addCssClass:' btn btn-link add-row',
        addText:'',
        formCssClass:'formset_row',
        deleteCallback:function(){
        
        }
   });*/


  var candidatureforcast_viewlink="<div  class=' col-sm-12 col-lg-12 text-right'>";
  candidatureforcast_viewlink+="<a href='#candidature_comitted_days' id='candidature_comitted_days' class='btn btn-link'>Show  Forcast Values</a>"
  candidatureforcast_viewlink+="</div>";

  $("input[id=id_release_date]").parent().after(candidatureforcast_viewlink);
 
 $("#candidature_comitted_days").on("click", function (e) {
        start_date=$('#id_actual_start_date').val();
        end_date=$("#id_release_date").val();
        if (start_date=='' || end_date=='')
        {   
                 bootbox.alert({
                  message: "Select Both Start Date And End Date !",
                  size: 'small'
                 });
            return false;
        }
        if ( start_date > end_date )
        {   
            bootbox.alert({
                  message: "Start Date Should Be Greater !!",
                  size: 'small'
                 });      
            return false;
        }
        url="/in/sow_master/calculate_commited_days?start_date="+start_date+"&end_date="+end_date;
        $.ajax({
        url :url,
        success : function(data) {
        candidature_commited_days=JSON.parse(data)
        ShowCandidatureForcastValues(candidature_commited_days)
        },
        error : function(xhr,errmsg,err) {
         alert("some error occured");
        }  
       }); 
       
 });

function ShowCandidatureForcastValues(candidature_commited_days){
       var bill_rate=$('#id_hourly_bill_rate').val();
  var sow_detail_html = '<div class="col-sm-12 ">';
      sow_detail_html += '<table class="table table-hover table-striped" >';
      sow_detail_html += '<tr><th> Month </th>';
      sow_detail_html += '<th> Year  </th>';
      sow_detail_html += '<th> Value </th></tr>';

      for(i=0 ; i< candidature_commited_days.length; i ++){
      sow_detail_html += '<tr>  <td>' + candidature_commited_days[i].month+'</td>';
      sow_detail_html += '<td>' + candidature_commited_days[i].year+'</td>';
      sow_detail_html += '<td>' + candidature_commited_days[i].days* bill_rate+'</td>';
      }
      sow_detail_html += '</table>'; 
        sow_detail_html += '</div>';
      
       bootbox.alert({
        title: '<strong>Sow Forcast Values</strong>',
        message: sow_detail_html,
        callback: function () {
            console.log('This was logged in the callback!');
          }
         }) 
       
     $('.modal-body').css("height","200px").css("overflow-y","scroll");

}
/*$("#id_release_date").on("dp.hide", function (e) {
     
    start_date=$('#id_actual_start_date').data('date');
         if (start_date == undefined ){
            start_date=$('#id_actual_start_date').val();
          if(start_date=="" || start_date==undefined){
             alert("select start date")
            return false
           }}

        end_date=$("#id_release_date").data('date');
        if (start_date > end_date )
           {
            alert("End Date Should Be Greater !!!")
            return
            }
        calculate_candidature_commited_days(start_date, end_date)
  });
$("#id_actual_start_date").on("dp.hide", function (e) {
      start_date=$('#id_actual_start_date').data('date');
        end_date=$("#id_release_date").data('date');
        if(end_date==undefined){
         end_date=$('#id_release_date').val()
          if(end_date=="" || end_date==undefined){
          return false
          }
        }
        if (start_date > end_date )
        {
            alert("End Date Should Be Greater !!!")
            return false
        }
        calculate_candidature_commited_days(start_date, end_date)
  });*/

function calculate_candidature_commited_days( start_date, end_date){

       url="/in/sow_master/calculate_commited_days?start_date="+start_date+"&end_date="+end_date;
      bill_rate=$("#id_hourly_bill_rate").val()
       $.ajax({
        url :url,

        success : function(data) {
    
       $('.forcast_formSet_row').remove()
        candidature_commited_days=JSON.parse(data)
        /*for(i=0 ; i< commited_days.length; i ++){
            var id='id_candidature-'+i
            var name='candidature-'+i
          str=`<div style="margin-top:12px" class="forcast_formSet_row form-group col-md-12  formset_row">
        <div style="margin-left: 200px;" class="form-group col-sm-12 col-md-3"><input type="text" name="${name}-year" placeholder="YYYY" class="required form-control datepicker_field" id="${id}-year"> </div> 
        <div style="margin-left: 10px; " class="form-group col-sm-12 col-md-3"><input type="text" name="${name}-days" placeholder="Days" class="required form-control " id="${id}-days"> </div> 
        <div style="margin-left: 10px;" class="form-group col-sm-12 col-md-3"><input type="text" name="${name}-forcast_value" placeholder="Value" class="required form-control " id="${id}-forcast_value"> 
        </div> 
           <a class=" btn btn-link delete_row " href="javascript:void(0)"></a></div>`

           $('#formset_container').append($(str))

        }
        $('#id_candidature-TOTAL_FORMS').val(commited_days.length)   
        
        for(i=0 ; i< commited_days.length; i ++){
          year=commited_days[i].year
          day=commited_days[i].days
          forcast=commited_days[i].days * bill_rate

         $("#id_candidature-"+i+"-year").val(commited_days[i].year)
         $("#id_candidature-"+i+"-days").val(day)
         $("#id_candidature-"+i+"-forcast_value").val(forcast)

        }*/

 
        },

        error : function(xhr,errmsg,err) {
         
         alert("some error occured");
        }
        
       });

 }

$(document).on('click',".mailSendLink", function(e){
        e.preventDefault();
        
        mail_send_url=$(this).attr("href");
        candidature_id=mail_send_url.split('?')[0].split('/')[4];
        mailType=$(this).attr("id");
        passcode=mail_send_url.split('?')[1].split('&')[1];

        condidatureUrl ="/in/candidature_master/candidature_detail/"+candidature_id+"?mailType="+mailType;
        if (passcode!==undefined){
           passcodeValue=passcode.split('=')[1];     
           condidatureUrl=condidatureUrl+"&passcode="+passcodeValue;     
        }
            
        $.ajax({

        url :condidatureUrl,
        success : function(data) {
         send_mail(data, mail_send_url);
        },
        error : function(xhr,errmsg,err) { 
         alert("some error occured");
        }
        
       });
        
});

   send_mail=function (data, mail_send_url){

      var confirmButton=true;
      if (data.hasOwnProperty('error_messages')) { 
          confirmButton=false;
         var errListHtml='<div class="alert alert-danger alert-dismissable" id=" style="width:100%;">'; 
          errListHtml+='<h5><i class="fa fa-exclamation-triangle" aria-hidden="true"></i> Errors :</h5>';
          errListHtml+='<ol>';
         for ( var i in data.error_messages) {
            errListHtml+='<li><strong>'+data.error_messages[i]+'</strong></li>';
             }
         errListHtml+='</ol>';
         errListHtml+='</div>';
         
        }
                 
         var html = '<div>';
         if (undefined !== errListHtml)
         {
         html+=errListHtml;
         }

         html+=data.responseTepmlate;
         html += '</div>';
              
      bootbox.confirm({
        title: 'Mail Send Confirmation !!',
        message: html,
        buttons: {
            cancel: {
                label: '<i class="fa fa-times"></i> Cancel'
            },
            confirm: {
                label: '<i class="fa fa-envelope"></i> Send Mail',
                className:'confirmButton btn btn-success'
            }
        },
        callback: function (result) {
            if (result)
                   {
                    additional_receipts= $('#email_ids').val()
                    if(additional_receipts!="")
                    {
                      mail_send_url+="&additional_receipts="+additional_receipts
                    }
                   bootbox.alert({
                                 message: "<i class='fa fa-circle-o-notch fa-spin'></i> sending",
                                size: 'small'
                                    });
                     $.ajax({
                         url :mail_send_url,
                
                         success : function(data) {
                                bootbox.hideAll(); 
                                 bootbox.alert({
                                 message: "mail send :"+ data,
                                size: 'small'
                                    });
                                
                             },

                         error : function(xhr,errmsg,err) {
                                bootbox.hideAll(); 
                         alert("some error occured");
                             }
                        });
                   } 
        }
      });
      if(!confirmButton){
      $(".confirmButton").hide();
      $("label[for='email_ids']").hide();
      $('#email_ids').hide()
     }
   };





});

