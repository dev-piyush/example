$(document).ready(function() {


$('a.shift_record_approve').click(function(e) {
  e.preventDefault();
   var href = $(this).attr("href");
     bootbox.confirm("Are you sure to Approve?", function(result) {    
                if (result) {
                    document.location.href = href;        
                }   
            });
});
$('a.shift_record_reject').click(function(e) {
  e.preventDefault();
   var href = $(this).attr("href");
     bootbox.confirm("Are you sure to Reject?", function(result) {    
                if (result) {
                    document.location.href = href;        
                }   
            });
});

$('body').on('focus',".date_picker", function(){

    $(this).datepicker({
    format: 'yyyy-mm-dd'
    });
});


  var empcode= $('#id_employee_ID');
  var name = $('#id_employee_name');
  var account = $('#id_account option:selected');
  var department = $('#id_department option:selected');
  var reporting_manager = $('#id_reporting_manager');
  var group_head = $('#id_group_head option:selected');
  var totalform=$('#id_shift_records-TOTAL_FORMS')


function onSuccess(){
          $('.parsley-error').removeClass('parsley-error')
        var html = '<table class="table table-hover table-striped" >';
        html += '<tr>  <td> Employee ID </td>  <td>' + empcode.val()+'</td></tr>';
        html += '<tr>  <td> Name </td>  <td>' + name.val()+'</td></tr>';
        html += '<tr>  <td> Account </td>  <td>' + $('#id_account option:selected').text()+'</td></tr>';
        html += '<tr>  <td> Reporting Manager </td>  <td>' + reporting_manager.val()+'</td></tr>';
        html += '<tr>  <td> Group Head </td>  <td>' +  $('#id_group_head option:selected').text()+'</td></tr>';
        html += '</table>';

  bootbox.confirm({
        title: "Summary",
        message: html,
        buttons: {
            cancel: {
                label: '<i class="fa fa-times"></i> Cancel'
                    },
            confirm: {
                label: '<i class="fa fa-check"></i> Confirm'
                    }
                },
        callback: function (result) {
            if (result) {
                    $("#allowance_form").submit();       
                } 
        }
        });
}

function onError(err){
  var errHtml='<div class="alert alert-danger"><h6 >Error : </h6></div>';
    bootbox.alert({
        message: errHtml+err,
        callback: function () {
            console.log('This was logged in the callback!');
          }
         }) 
}

function all_validations(){ 

    if (validateForm() && validateFormSet()){
                  $.ajax({
                  url :"/in/shift_allowance/get_previous_allowances?empid="+empcode.val(),
    
                  success : function(data) {
                       var errHtml=''
                       previous_record=JSON.parse(data)
                       console.log(previous_record)
                       if(previous_record.length > 0){
                        for(i=0;i< totalform.val();i++)
                           { 
                        for ( k=0 ; k<previous_record.length; k++){
                         start_date=$('#id_shift_records-'+i+'-start_date');
                         end_date=$('#id_shift_records-'+i+'-end_date');
                         start_time=$('#id_shift_records-'+i+'-start_time');
                         end_time=$('#id_shift_records-'+i+'-end_time');
                         var a = moment(start_date.val(), 'YYYY-M-D');
                         var b = moment(end_date.val(), 'YYYY-M-D');
                         var start_timestamp= moment(a).add(start_time.val().split(":")[0], 'hours').add(start_time.val().split(":")[1], 'minutes').valueOf();
                         var end_timestamp= moment(b).add(end_time.val().split(":")[0], 'hours').add(end_time.val().split(":")[1], 'minutes').valueOf();

                         var start_date_pre = moment(previous_record[k].start_date, 'YYYY-M-D');
                         var end_date_pre = moment(previous_record[k].end_date, 'YYYY-M-D');
                         var start_timestamp_pre= moment(start_date_pre).add(previous_record[k].start_time.split(":")[0], 'hours')
                                        .add(previous_record[k].start_time.split(":")[1], 'minutes').valueOf();
                         var end_timestamp_pre= moment(end_date_pre).add(previous_record[k].end_time.split(":")[0], 'hours')
                                        .add(previous_record[k].end_time.split(":")[1], 'minutes').valueOf();
                         
                         
                         is_start_timestamp_conflict=moment(start_timestamp).isBetween(start_timestamp_pre, end_timestamp_pre, null, '[]');
                         is_end_timestamp_conflict=moment(end_timestamp).isBetween(start_timestamp_pre, end_timestamp_pre , null, '[]');
                          if (is_start_timestamp_conflict || is_end_timestamp_conflict)
                          {
                             var table = '<tr><td> ' + previous_record[k].start_date+'  </td>  <td>' + previous_record[k].start_time+'</td>';
                             table += '  <td>' + previous_record[k].end_date+' </td>  <td>' + previous_record[k].end_time+'</td></tr>';
                             errHtml +=table;
                       
                          }
                          else if (moment(start_timestamp_pre).isBetween(start_timestamp, end_timestamp))
                          {
                             var table = '<tr><td> ' + previous_record[k].start_date+'  </td>  <td>' +previous_record[k].start_time+'</td>';
                             table += '  <td>' +previous_record[k].end_date+' </td>  <td>' +previous_record[k].end_time+'</td></tr>';
                             errHtml +=table;
                         
                          }

                        }
                        
                        }
                        if (errHtml!=''){
                          var err="<p>Dplicate Record Found In Database.</p>"
                              err += '<table class="table table-hover table-striped" >';
                              err += '<tr>  <th>Start Date</th><th>Start time</th><th>End Date</th>  <th>End time</th></tr>';
                              err += errHtml;
                              err += '</table>';
                            onError(err)
                          }
                  
                        }
                        
                        if (errHtml==''){
                        onSuccess()
                        }
                         
                        },
                       error : function(xhr,errmsg,err) {
         
                         alert("some error occured");
                         }
        
                });
    }

     return false;

  }  

   function validateFormSet(){
    if(!totalform.val())
      return false;
     for(i=0;i< totalform.val();i++)
       { 

         start_date=$('#id_shift_records-'+i+'-start_date');
         end_date=$('#id_shift_records-'+i+'-end_date');
         start_time=$('#id_shift_records-'+i+'-start_time');
         end_time=$('#id_shift_records-'+i+'-end_time');
         var errHtml=''

          if(start_date.val()===""){
          errHtml +='<p>Please Enter '+(i+1)+ ' days Date .</p>';
          start_date.addClass('parsley-error')
          onError(errHtml)
          return false;
          }

          if(start_time.val()===""){
          errHtml +='<p>Please Enter '+(i+1)+ ' days Start time .</p>';
          start_time.addClass('parsley-error')
          onError(errHtml)
          return false;
          }
          if(end_time.val()===""){
          errHtml +='<p>Please Enter '+(i+1)+ ' days End time .</p>';
          end_time.addClass('parsley-error')
          onError(errHtml)
          return false;
          }

          var a = moment(start_date.val(), 'YYYY-M-D');
          var b = moment(end_date.val(), 'YYYY-M-D');
          var start_timestamp= moment(a).add(start_time.val().split(":")[0], 'hours').add(start_time.val().split(":")[1], 'minutes').valueOf();
          var end_timestamp= moment(b).add(end_time.val().split(":")[0], 'hours').add(end_time.val().split(":")[1], 'minutes').valueOf();
          var diffDays =b.diff(a, 'days') ;

          if(diffDays != 0 && diffDays != 1 ){
          errHtml +='<p>Please Correct  record  '+(i+1)+ ' end date  should be same day or next day .</p>';
          end_date.addClass('parsley-error')
          onError(errHtml)
          return false;
          }
          if(diffDays == 0 && end_time.val() < start_time.val() ){
          errHtml +='<p>Please Correct  record  '+(i+1)+ ' end time  should be greater than start time .</p>';
          end_time.addClass('parsley-error')
          onError(errHtml)
          return false;
          }  


          for (j=0;j<totalform.val();j++){
            if (j!=i){
               start_date_object=$('#id_shift_records-'+j+'-start_date');
               end_date_object=$('#id_shift_records-'+j+'-end_date');
               start_time_object=$('#id_shift_records-'+j+'-start_time');
               end_time_object=$('#id_shift_records-'+j+'-end_time');
               var start_date_other = moment(start_date_object.val(), 'YYYY-M-D');
               var end_date_other = moment(end_date_object.val(), 'YYYY-M-D');
               var start_timestamp_other= moment(start_date_other).add(start_time_object.val().split(":")[0], 'hours').add(start_time_object.val().split(":")[1], 'minutes').valueOf();
               var end_timestamp_other= moment(end_date_other).add(end_time_object.val().split(":")[0], 'hours').add(end_time_object.val().split(":")[1], 'minutes').valueOf();
               
               is_start_timestamp_conflict=moment(start_timestamp).isBetween(start_timestamp_other, end_timestamp_other, null, '[]');
               is_end_timestamp_conflict=moment(end_timestamp).isBetween(start_timestamp_other, end_timestamp_other , null, '[]');

              if (is_start_timestamp_conflict || is_end_timestamp_conflict)
                          {
                          errHtml +='<p>Duplicate Record</p>';
                          start_date_object.addClass('parsley-error')
                          end_date_object.addClass('parsley-error')
                          start_time_object.addClass('parsley-error')
                          end_time_object.addClass('parsley-error')
                          onError(errHtml)
                          return false;
                       
                          }
              else if (moment(start_timestamp_other).isBetween(start_timestamp, end_timestamp))
                          {
                          errHtml +='<p>Duplicate Record</p>';
                          start_date_object.addClass('parsley-error')
                          end_date_object.addClass('parsley-error')
                          start_time_object.addClass('parsley-error')
                          end_time_object.addClass('parsley-error')
                          onError(errHtml)
                          return false;
                         
                          }

             }
            }      

         }
       return true;
     }

    function validateForm() {
            var errHtml=''
             var empcode= $('#id_employee_ID');
             var name = $('#id_employee_name');
             var account = $('#id_account option:selected');
             var reporting_manager = $('#id_reporting_manager');
            var group_head = $('#id_group_head option:selected');
  
            if(empcode.val()===""){
               errHtml +='<p>Please Enter Employee code which should be numeric only .</p>';
               empcode.addClass('parsley-error')
               onError(errHtml)
               return false;}
            else if(name.val()===""){
               errHtml +='<p> Please Enter Employee Name.</p>';
               name.addClass('parsley-error')
               onError(errHtml)
               return false;
             }

            else if(account.val()===""){
               errHtml +='<p> Please Select Account Name.</p>';
               name.addClass('parsley-error')
               onError(errHtml)
               return false;
              }

               
            else if(!isNaN( parseInt(name.val()))){
               errHtml +='<p> Please Enter Name as String  !</p>';
               name.addClass('parsley-error')
               onError(errHtml)
               return false;
               }
        
            else if(reporting_manager.val()===""){
               errHtml +='<p> Please Enter Reporting Manager Name !</p>';
               reporting_manager.addClass('parsley-error')
               onError(errHtml)
               return false;
             
           } 
            else if(!isNaN( parseInt(reporting_manager.val()))){

              reporting_manager.addClass('parsley-error')
               errHtml +='<p> Please Enter Reporting_manager in String  !</p>';
               onError(errHtml)
               return false;
               
             }
            else if(group_head.val()===""){
               errHtml +='<p> Please Select Group Head.</p>';
               group_head.addClass('parsley-error')
               onError(errHtml)
               return false;
               
             }

                           
            else   
             return true  ;    
     }
 $("#submitform").click(function(e) {

        //prevent Default functionality
        e.preventDefault();
    
        return all_validations();     

  });




$('.shift_allowance_formset_row').formset({
        deleteText: 'remove',
        prefix:'shift_records',
        deleteCssClass:' btn btn-link ',
        addCssClass:' btn btn-link add-row',
        addText:'more',
        formCssClass:'formset_row',
        deleteCallback:function(){
      

          var noOfForm=$('#id_shift_records-TOTAL_FORMS').val();
         if(noOfForm==1){
         swal(  
                 '',
                 'Need Atleast One Allwance Form!',
                 'error',
               
            )
          $( "a.add-row" ).trigger( "click" );
           }
        
        }
});


function replaceBadInputs(val) {
  // Replace impossible inputs as the appear
  val = val.replace(/[^\dh:]/, "");
  val = val.replace(/^[^0-2]/, "");
  val = val.replace(/^([2-9])[4-9]/, "$1");
  val = val.replace(/^\d[:h]/, "");
  val = val.replace(/^([01][0-9])[^:h]/, "$1");
  val = val.replace(/^(2[0-3])[^:h]/, "$1");      
  val = val.replace(/^(\d{2}[:h])[^0-5]/, "$1");
  val = val.replace(/^(\d{2}h)./, "$1");      
  val = val.replace(/^(\d{2}:[0-5])[^0-9]/, "$1");
  val = val.replace(/^(\d{2}:\d[0-9])./, "$1");
  return val;
}

$(document).on('keyup', '.houronly', function() {
    var val = this.value;
  var lastLength;
  do {
    // Loop over the input to apply rules repeately to pasted inputs
    lastLength = val.length;
    val = replaceBadInputs(val);
  } 
  while(val.length > 0 && lastLength !== val.length);
  this.value = val;
 });


$(document).on('blur', '.houronly', function() {
var val = this.value;
  val = (/^(([01][0-9]|2[0-3])h)|(([01][0-9]|2[0-3]):[0-5][0-9])$/.test(val) ? val : "");
  this.value = val;
 });




 });
