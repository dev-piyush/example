import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import KanbanBoardContainer from './KanbanBoardContainer';
import cardsList from './data'
import registerServiceWorker from './registerServiceWorker';


ReactDOM.render(<KanbanBoardContainer cards={cardsList} />, document.getElementById('root'));
registerServiceWorker();
