
import React, { Component } from 'react';
import 'whatwg-fetch';
import KanbanBoard from './KanbanBoard';
import update from 'react-addons-update';
const API_URL = 'http://kanbanapi.pro-react.com';
const API_HEADERS = {
 'Content-Type': 'application/json',
 Authorization: 'any-string-you-like'// The Authorization is not needed for local server
};


class KanbanBoardContainer extends Component {
 constructor(){
 super(...arguments);
 this.state = {
 cards:[],
 };
 }
 componentDidMount(){
 this.setState({cards: [
 {
 id: 1,
 title: "Read the Book",
 description: "I should read the whole book",
 color: '#BD8D31',
 status: "in-progress",
 tasks: []
 },
  {
 id: 1,
 title: "Read the Book",
 description: "I should read the whole book",
 color: '#FC1131',
 status: "done",
 tasks: []
 },
 {
 id: 2,
 title: "Write some code",
 color: '#1D3331',
 description: "Code along with the samples in the book",
 status: "todo",
 tasks: [
 {
 id: 1,
 name: "ContactList Example",
 done: true
 },
 {
 id: 2,
 name: "Kanban Example",
 done: false
 },
 {
 id: 3,
 name: "My own experiments",
 done: false
 }
 ]
 },
]
 })}

	addTask(cardId, taskName){

		 let cardIndex = this.state.cards.findIndex((card)=>card.id == cardId);

 // Create a new task with the given name and a temporary ID
 let newTask = {id:Date.now(), name:taskName, done:false};

let nextState = update(this.state.cards, {
 [cardIndex]: {
 tasks: {$push: [newTask] }
 }
 });
 // set the component state to the mutated obj


 }
 deleteTask(cardId, taskId, taskIndex){
 	 // Find the index of the card
 let cardIndex = this.state.cards.findIndex((card)=>card.id == cardId);

 // Create a new object without the task
 let nextState = update(this.state.cards, {
 [cardIndex]: {
 tasks: {$splice: [[taskIndex,1]] }
 }
 });
 // set the component state to the mutated object
 this.setState({cards:nextState});


 }
 toggleTask(cardId, taskId, taskIndex){
 	// Find the index of the card
 let cardIndex = this.state.cards.findIndex((card)=>card.id == cardId);
 // Save a reference to the task's 'done' value
 let newDoneValue;
 // Using the $apply command, you will change the done value to its opposite
 let nextState = update(this.state.cards, {
 [cardIndex]: {
 tasks: {
 [taskIndex]: {
 done: { $apply: (done) => {
 newDoneValue = !done
 return newDoneValue;
 }
 }
 }
 }
 }
 });
 // set the component state to the mutated object
 this.setState({cards:nextState});



 }
 render() {
 return <KanbanBoard cards={this.state.cards} taskCallbacks={{
 toggle: this.toggleTask.bind(this),
delete: this.deleteTask.bind(this),
 add: this.addTask.bind(this) }}/>
 }
}
export default KanbanBoardContainer;