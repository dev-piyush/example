## Scotch React Router
A demo that backs a Scotch article on routing in React.
