import React, { Component } from 'react';
import './App.css';
import axios from 'axios';
/*
Screen:LoginScreen
Loginscreen is the main screen which the user is shown on first visit to page and after
hitting logout
*/
import LoginScreen from './Loginscreen';
/*
Module:Material-UI
Material-UI is used for designing ui of the app
*/
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import AppBar from 'material-ui/AppBar';
import RaisedButton from 'material-ui/RaisedButton';
import Drawer from 'material-ui/Drawer';
import MenuItem from 'material-ui/MenuItem';
import FontIcon from 'material-ui/FontIcon';
import {blue500, red500, greenA200} from 'material-ui/styles/colors';

var apiBaseUrl = "http://127.0.0.1:5000/";
/*
Module:Dropzone
Dropzone is used for local file selection
*/
import Dropzone from 'react-dropzone';
/*
Module:superagent
superagent is used to handle post/get requests to server
*/
var request = require('superagent');

class BooksPage extends Component {
  constructor(props){
    super(props);
    this.state={
      
      books:[],
      
    }
  
    }

    render() {
    return (
    	<h1>piyush Raj</h1>
      
    );
  }

  

  componentWillMount(){
   
   var payload={
   	'access_token':this.props.appContext.access_token
     }
   
    axios.get(apiBaseUrl+'mybooks',{ headers: {"Authorization" : `Bearer ${this.props.appContext.state.access_token}`} })
   .then(function (response) {
 
	if(response.status == 200){
		       
		       self.state.books=response.data
		       console.log(self.state.books)
		     }
     else if(response.data.code == 204){
       console.log("Username password do not match");
       alert(response.data.success)
     }
     else{
       console.log("Username does not exists");
       alert("Username does not exist");
     }
   })
   .catch(function (error) {
     console.log(error);
   });

  }

    
  

  }


  
 export default BooksPage;