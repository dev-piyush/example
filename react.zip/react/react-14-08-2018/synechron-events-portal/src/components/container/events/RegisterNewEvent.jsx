import React, { Component } from 'react';

class RegisterNewEvent extends Component {
    constructor(props) {
        super(props);
        this.state = {
            eventId: '',
            eventCode: '',
            eventName: '',
            description: '',
            startDate: new Date(),
            endDate: new Date(),
            fees: 0,
            attendance: 0,
            logo: 'images/noimage.png'
        }
        this.inputChange = (e) => {
            this.setState({
                [e.target.name]: e.target.value
            });
        }
    }

    showDetails(e) {
        e.preventDefault();
        this.state.eventId = Number.parseInt(this.state.eventId);
        fetch("http://localhost:9090/api/events", {
            method: "POST",
            headers: new Headers({
                "content-type": "application/json"
            }),
            body: JSON.stringify(this.state)
        })
            .then(response => response.json())
            .then(data => console.log(data));
    }

    render() {
        return (
            <form className="form-horizontal">
                <fieldset>
                    <legend>New Event Registration</legend>
                    <div className="form-group">
                        <label htmlFor="inputEventId" className="col-lg-2 control-label">Event ID</label>
                        <div className="col-lg-10">
                            <input type="number" className="form-control"
                                id="inputEventId" placeholder="Event ID"
                                value={this.state.eventId}
                                onChange={this.inputChange}
                                name="eventId"
                            />
                        </div>
                    </div>
                    <div className="form-group">
                        <label htmlFor="inputEventCode" className="col-lg-2 control-label">Event Code</label>
                        <div className="col-lg-10">
                            <input type="text"
                                onChange={this.inputChange}
                                value={this.state.eventCode} className="form-control" id="inputEventCode" placeholder="Event Code" name="eventCode" />
                        </div>
                    </div>
                    <div className="form-group">
                        <label htmlFor="inputEventName" className="col-lg-2 control-label">Event Name</label>
                        <div className="col-lg-10">
                            <input type="text"
                                onChange={this.inputChange}
                                value={this.state.eventName}
                                className="form-control" id="inputEventName" placeholder="Event Name" name="eventName" />
                        </div>
                    </div>
                    <div className="form-group">
                        <label htmlFor="inputEventDescription" className="col-lg-2 control-label">Event Description</label>
                        <div className="col-lg-10">
                            <input type="text"
                                onChange={this.inputChange}
                                value={this.state.description}
                                className="form-control" id="inputEventDescription" placeholder="Event Description" name="description" />
                        </div>
                    </div>
                    <div className="form-group">
                        <label htmlFor="inputEventStartDate" className="col-lg-2 control-label">Start Date</label>
                        <div className="col-lg-10">
                            <input type="date"
                                onChange={this.inputChange}
                                value={this.state.startDate}
                                className="form-control" id="inputEventStartDate" placeholder="StartDate" name="startDate" />
                        </div>
                    </div>
                    <div className="form-group">
                        <label htmlFor="inputEventLastDate" className="col-lg-2 control-label">Last Date</label>
                        <div className="col-lg-10">
                            <input type="date"
                                onChange={this.inputChange}
                                value={this.state.endDate}
                                className="form-control" id="inputEventLastDate" placeholder="Last Date" name="endDate" />
                        </div>
                    </div>
                    <div className="form-group">
                        <label htmlFor="inputEventFees" className="col-lg-2 control-label">Event Fees</label>
                        <div className="col-lg-10">
                            <input type="number"
                                onChange={this.inputChange}
                                value={this.state.fees}
                                className="form-control" id="inputEventFees" placeholder="Event Fees" name="fees" />
                        </div>
                    </div>
                    <div className="form-group">
                        <label htmlFor="inputEventAttendance" className="col-lg-2 control-label">Attendance</label>
                        <div className="col-lg-10">
                            <input type="number"
                                value={this.state.attendance}
                                onChange={this.inputChange}
                                className="form-control" id="inputEventAttendance" placeholder="Attendance" name="attendance" />
                        </div>
                    </div>
                    <div className="form-group">
                        <div className="col-lg-10 col-lg-offset-2">
                            <button type="reset" className="btn btn-default">Cancel</button>
                            <button type="submit" className="btn btn-primary" onClick={(e) => this.showDetails(e)}>Submit</button>
                        </div>
                    </div>
                </fieldset>
            </form>

        );
    }
}

export default RegisterNewEvent;