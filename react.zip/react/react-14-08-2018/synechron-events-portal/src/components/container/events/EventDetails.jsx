import React from "react";


export default class EventDetails extends React.Component {
    constructor(props) {
        super();
        this.state = {
            eventDetails: null
        }
    }
    componentDidMount() {
        this.fetchEventDetails(Number.parseInt(this.props.match.params.id));
    }
    fetchEventDetails(id) {
        fetch("http://localhost:9090/api/events/" + id).then(response => response.json()).then(data => this.setState({
            eventDetails: data
        }));
    }
    render() {
        let pageTitle = "Event Details of - ";
        if (this.state.eventDetails) {
            return (
                <div>
                    <h1>{pageTitle}{this.state.eventDetails.eventName}</h1>
                    <hr />
                    <table className="table table-hover table-striped">
                        <tbody>
                            <tr>
                                <th>Event Id</th>
                                <td>{this.state.eventDetails.eventId}</td>
                            </tr>
                            <tr>
                                <th>Event Code</th>
                                <td>{this.state.eventDetails.eventCode}</td>
                            </tr>
                            < tr >
                                <th>Event Name</th>
                                <td>{this.state.eventDetails.eventName}</td>
                            </tr>
                            <tr>
                                <th>Description</th>
                                <td>{this.state.eventDetails.description}</td>
                            </tr>
                            <tr>
                                <th>Start Date</th>
                                <td>{new Intl.DateTimeFormat("en-IN", {
                                    year: 'numeric',
                                    month: 'long',
                                    day: '2-digit'
                                }).format(Date.parse(this.state.eventDetails.startDate))}</td>
                            </tr>
                            <tr>
                                <th>End Date</th>
                                <td>{new Intl.DateTimeFormat("en-IN", {
                                    year: 'numeric',
                                    month: 'long',
                                    day: '2-digit'
                                }).format(Date.parse(this.state.eventDetails.endDate))}</td>
                            </tr>
                            <tr>
                                <th>Fees</th>
                                <td>{this.state.eventDetails.fees}</td>
                            </tr>
                            <tr>
                                <th>Attendance</th>
                                <td>
                                    <div className="progress">
                                        <div className="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style={{
                                            width: this.state.eventDetails.attendance + '%'
                                        }}>
                                            {this.state.eventDetails.attendance + '%'}
                                            <span className="sr-only">{this.state.eventDetails.attendance + '%'}</span>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>Logo</th>
                                <td>
                                    <img src={"../"+this.state.eventDetails.logo} alt={this.state.eventDetails.eventName} />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>)
        }
        else {
            return (<p></p>)
        }
    }
}