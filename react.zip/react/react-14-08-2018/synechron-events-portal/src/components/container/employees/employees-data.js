const employees = [
    {
        employeeId: 1,
        employeeName: "Pravinkumar R. D.",
        address: "Suncity, A8/404",
        city: "Pune",
        state: "Maharashtra",
        country: "India",
        zipCode: 411051,
        phone: "+91 23723828",
        email: "pravinkumar.r.d@gmail.com",
        avatar: "images/noimage.png"
    },
    {
        employeeId: 2,
        employeeName: "Mahesh S.",
        address: "Greencity, A8/404",
        city: "Pune",
        state: "Maharashtra",
        country: "India",
        zipCode: 411021,
        phone: "+91 37483222",
        email: "mahesh.s@gmail.com",
        avatar: "images/noimage.png"
    },
    {
        employeeId: 3,
        employeeName: "Alisha P.",
        address: "Mooncity, A8/404",
        city: "Mumbai",
        state: "Maharashtra",
        country: "India",
        zipCode: 4334434,
        phone: "+91 3849348",
        email: "alisha.p@gmail.com",
        avatar: "images/noimage.png"
    },
    {
        employeeId: 4,
        employeeName: "Anjala Johns",
        address: "East Park, 23/404",
        city: "London",
        state: "London",
        country: "UK",
        zipCode: 4445555,
        phone: "+203 23723828",
        email: "anjala.j@gmail.com",
        avatar: "images/noimage.png"
    },
    {
        employeeId: 5,
        employeeName: "Manish Sharma",
        address: "Swapnasheel, j/23",
        city: "Pune",
        state: "Maharashtra",
        country: "India",
        zipCode: 411004,
        phone: "+91 90909090",
        email: "manish.sharma@gmail.com",
        avatar: "images/noimage.png"
    }
];

export default employees;