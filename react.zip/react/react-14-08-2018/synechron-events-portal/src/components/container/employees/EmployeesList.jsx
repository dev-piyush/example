import React from "react";

import employees from "./employees-data";

export default class EmployeesList extends React.Component {
    constructor() {
        super();
    }
    render() {
        return (
            <div>
                <h1>Welcome To Synechron Employees List !</h1>
                <hr />
                <h5>Core Development Teams!</h5>
                <br />
                <table className="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>Employee Name</th>
                            <th>City</th>
                            <th>Contact #</th>
                            <th>Email</th>
                            <th>Show Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            employees.map((employee, idx)=> 
                                <tr key={idx}>
                                    <td><span>{employee.employeeName}</span></td>
                                    <td><span>{employee.city}</span></td>
                                    <td><span>{employee.phone}</span></td>
                                    <td><span>{employee.email}</span></td>
                                    <td><button className="btn btn-primary">Show Details</button></td>
                                </tr>
                            )
                        }
                    </tbody>
                </table>
            </div>
        );
    }
}