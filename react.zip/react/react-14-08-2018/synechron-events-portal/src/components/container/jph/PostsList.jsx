import React from "react";

export default class PostsList extends React.Component {
    constructor() {
        super();
        this.state = {
            posts: []
        }
    }

    componentDidMount() {
        this.fetchJphPosts();
    }
    fetchJphPosts() {
        fetch("https://jsonplaceholder.typicode.com/posts").then(
            (response) => response.json(),
            (reason) => console.log(reason)
        ).then(data => this.setState({
            posts: data
        }));
    }
    render() {
        return (
            <div>
                <table className="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>User Id</th>
                            <th>Post Id</th>
                            <th>Title</th>
                            <th>Description</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.state.posts.map((post,idx)=>
                            <tr key={idx}>
                                <td>{post.userId}</td>
                                <td>{post.id}</td>
                                <td>{post.title}</td>
                                <td>{post.body}</td>
                            </tr>
                        )
                        }
                    </tbody>
                </table>
            </div>
        );
    }
}