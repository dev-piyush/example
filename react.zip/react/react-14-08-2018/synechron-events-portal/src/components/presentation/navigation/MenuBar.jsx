import React from "react";
import { NavLink } from "react-router-dom";


const SepNavBar = (props) => {
    return (
        <nav className="navbar navbar-default">
            <div className="container-fluid">
                <div className="navbar-header">
                    <button type="button" className="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
                        <span className="sr-only">Toggle navigation</span>
                        <span className="icon-bar"></span>
                        <span className="icon-bar"></span>
                        <span className="icon-bar"></span>
                    </button>
                    <NavLink className="navbar-brand" to="/">{props.menuItems[0]}</NavLink>
                </div>

                <div className="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                    <ul className="nav navbar-nav">
                        <li className="active"><NavLink to="/home">{props.menuItems[1]} <span className="sr-only">(current)</span></NavLink></li>
                        <li><NavLink to="/employees">{props.menuItems[2]}</NavLink></li>
                        <li><NavLink to="/events">{props.menuItems[3]}</NavLink></li>
                        <li><NavLink to="/jph/posts">{props.menuItems[4]}</NavLink></li>
                        <li><NavLink to="/newevent">{props.menuItems[5]}</NavLink></li>
                    </ul>
                    <ul className="nav navbar-nav navbar-right">
                        <li><a href="#">{props.menuItems[6]}</a></li>
                        <li><a href="#">{props.menuItems[7]}</a></li>
                    </ul>
                </div>
            </div>
        </nav>
    );
}

export default SepNavBar;