import React from "react";

const SepHome = (props) => {
    return(
        <h1>Welcome To Synechron Events Portal!</h1>
    );
}

export default SepHome;