import { createStore, applyMiddleware, combineReducers } from "redux";
import { logger } from "redux-logger";

const initialState = {
    result: 10,
    lastValues: []
}
const oneMoreInitialState = {
    name: "Training",
    address: "Hinjewadi, PH-II",
    city: "Pune"
}
const departmentReducer = (state = oneMoreInitialState, action) => {
    switch (action.type) {
        case "ADD":
            state = {
                ...state,
                address: action.payload
            }
            break;
        case "CHANGE_CITY":
            state = {
                ...state,
                city: action.payload
            }
            break;
    }
    return state;
}
const reducer = (state = initialState, action) => {
    switch (action.type) {
        case "ADD":
            //state.result += action.payload;
            state = {
                ...state,
                result: state.result + action.payload,
                lastValues: [...state.lastValues, action.payload]
            }
            break;
        case "SUBTRACT":
            //state.result -= action.payload;
            state = {
                ...state,
                result: state.result - action.payload,
                lastValues: [...state.lastValues, action.payload]
            }
            break;
        default:
            break;
    }
    return state;
}

const customerLogger = (store) => (next) => (action) => {
    //console.log(`Store Updated ${store.getState().result} and ${store.getState().lastValues}`);
    console.log(`Action is ${action}`);
    next(action);
}

const store = createStore(combineReducers({
    reducer,
    departmentReducer
}), applyMiddleware(customerLogger, logger));

store.subscribe(() => {
    console.log(`Store Updated ${store.getState().result} and ${store.getState().lastValues}`);
});

store.dispatch({
    type: "ADD",
    payload: 100
});
store.dispatch({
    type: "SUBTRACT",
    payload: 50
});
store.dispatch({
    type: "ADD",
    payload: 200
});
store.dispatch({
    type: "ADD",
    payload: "Magarpatta, Phase - II"
});
store.dispatch({
    type: "CHANGE_CITY",
    payload: "Mumbai"
});