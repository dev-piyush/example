/*import { createStore } from "redux";

const reducer = (state, action) => {
    switch (action.type) {
        case "ADD":
            state = state + action.payload;
            break;
        case "SUBTRACT":
            state = state - action.payload;
            break;
    }
    return state;
}

const store = createStore(reducer, 10);

store.subscribe(() => {
    console.log(`Store Updated ${store.getState()}`);
});

store.dispatch({
    type: "ADD",
    payload: 100
});
store.dispatch({
    type: "ADD",
    payload: 33
});
store.dispatch({
    type: "SUBTRACT",
    payload: 50
});*/

/*import { createStore } from "redux";

const initialState = {
    result: 10,
    lastValues: []
}

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case "ADD":
            //state.result += action.payload;
            state.lastValues.push(action.payload);
            state = {
                result: state.result + action.payload,
                lastValues: state.lastValues
            }
            break;
        case "SUBTRACT":
            state.lastValues.push(action.payload);
            state = {
                result: state.result - action.payload,
                lastValues: state.lastValues
            }
            //state.result -= action.payload;
            break;
    }
    return state;
}

const store = createStore(reducer);

store.subscribe(() => {
    console.log(`Store Updated ${store.getState().result} and ${store.getState().lastValues}`);
});

store.dispatch({
    type: "ADD",
    payload: 100
});
store.dispatch({
    type: "ADD",
    payload: 33
});
store.dispatch({
    type: "SUBTRACT",
    payload: 50
});*/

import { createStore, compose, applyMiddleware } from "redux";
import { logger } from "redux-logger";
const initialState = {
    result: 10,
    lastValues: []
}

const reducer = (state = initialState, action) => {
    switch (action.type) {
        case "ADD":
            //state.result += action.payload;
            state = {
                ...state,
                result: state.result + action.payload,
                lastValues: [...state.lastValues, action.payload]
            }
            //state.lastValues.push(state.result);
            break;
        case "SUBTRACT":
            //state.result += action.payload;
            state = {
                ...state,
                result: state.result - action.payload,
                lastValues: [...state.lastValues, action.payload]
            }
            //state.lastValues.push(state.result);
            break;
    }
    return state;
}

const store = createStore(reducer, null, compose(applyMiddleware(logger)));

store.subscribe(() => {
    console.log(`Store Updated ${store.getState()}`);
});

store.dispatch({
    type: "ADD",
    payload: 100
});
store.dispatch({
    type: "ADD",
    payload: 33
});
store.dispatch({
    type: "SUBTRACT",
    payload: 50
});