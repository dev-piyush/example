const mongojs = require("mongojs");
const db = mongojs("react-js-events-db", ["events"]);

class EventDal {
    getAllEvents() {
        return new Promise((resolve, reject) => {
            db.events.find((err, documents) => {
                if (err) {
                    reject(err.message);
                }
                resolve(documents);
            });
        });
    }
    getSingleEvent(evntId) {
        return new Promise((resolve, reject) => {
            db.events.findOne({ eventId: Number.parseInt(evntId) }, (err, document) => {
                if (err) {
                    reject(err.message);
                }
                resolve(document);
            });
        });
    }
    insertNewEvent(event) {
        return new Promise((resolve,reject)=>{
            db.events.insert(event,(err)=>{
                if (err) {
                    reject(err.message);
                }
                resolve(event);
            });
        });
    }
}

module.exports = new EventDal();