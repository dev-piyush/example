const mongojs = require("mongojs");
const db = mongojs("react-js-events-db", ["employees"]);

class EmployeeDal {
    getAllEmployees() {
        return new Promise((resolve, reject) => {
            db.employees.find((err, documents) => {
                if (err) {
                    reject(err.message);
                }
                resolve(documents);
            });
        });
    }
    getSingleEmployee(empId) {
        return new Promise((resolve, reject) => {
            db.employees.findOne({ employeeId: Number.parseInt(empId) }, (err, document) => {
                if (err) {
                    reject(err.message);
                }
                resolve(document);
            });
        });
    }
    insertNewEmployee(employee) {
        return new Promise((resolve,reject)=>{
            db.employees.insert(employee,(err)=>{
                if (err) {
                    reject(err.message);
                }
                resolve(employee);
            });
        });
    }
}

module.exports = new EmployeeDal();