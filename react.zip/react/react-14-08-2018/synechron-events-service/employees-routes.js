const express = require("express");
const employeeRoutes = express.Router();

const employeeDal = require("./dal/employee-dal");

employeeRoutes.get("/", (request, response) => {
    employeeDal.getAllEmployees().then((data) => {
        response.json(data);
    },
        (reason) => {
            response.send(reason);
        });
});
employeeRoutes.get("/:id", (request, response) => {
    let empId = request.params.id;
    employeeDal.getSingleEmployee(empId).then((data) => {
        response.json(data);
    },
        (reason) => {
            response.send(reason);
        });
});

employeeRoutes.post("/", (request, response) => {
    let employee = request.body;
    employeeDal.insertNewEmployee(employee).then((employee) => {
        response.json(employee);
    }, (reason) => {
        response.send(reason);
    });
});

module.exports = employeeRoutes;