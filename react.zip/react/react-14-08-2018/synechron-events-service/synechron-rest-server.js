const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const eventRoutes = require("./events-routes");
const employeeRoutes = require("./employees-routes");


const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use("/api/events", eventRoutes);
app.use("/api/employees", employeeRoutes);
app.listen(9090, () => {
    console.log("REST Service started at PORT : 9090");
});