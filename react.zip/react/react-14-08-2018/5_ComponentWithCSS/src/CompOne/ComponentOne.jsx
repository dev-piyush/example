import React, { Component } from 'react';
import './ComponentOne.css';

class ComponentOne extends Component {
    render() {
        return (
            <h1 className="testOne text-danger">Hello from Component One</h1>
        );
    }
}

export default ComponentOne;