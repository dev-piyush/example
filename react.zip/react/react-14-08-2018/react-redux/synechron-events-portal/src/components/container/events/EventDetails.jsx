import React from "react";
import { connect } from "react-redux";
import propsTypes from "prop-types";


import { fetchSingleEvent } from "../../../actions/events-actions";
class EventDetails extends React.Component {
    componentDidMount() {
        this.props.fetchSingleEvent(Number.parseInt(this.props.match.params.id));
    }
    render() {
        let pageTitle = "Event Details of - ";
        if (this.props.eventDetails) {
            return (
                <div>
                    <h1>{pageTitle}{this.props.eventDetails.eventName}</h1>
                    <hr />
                    <table className="table table-hover table-striped">
                        <tbody>
                            <tr>
                                <th>Event Id</th>
                                <td>{this.props.eventDetails.eventId}</td>
                            </tr>
                            <tr>
                                <th>Event Code</th>
                                <td>{this.props.eventDetails.eventCode}</td>
                            </tr>
                            < tr >
                                <th>Event Name</th>
                                <td>{this.props.eventDetails.eventName}</td>
                            </tr>
                            <tr>
                                <th>Description</th>
                                <td>{this.props.eventDetails.description}</td>
                            </tr>
                            <tr>
                                <th>Start Date</th>
                                <td>
                                {
                                    this.props.eventDetails.startDate
                                }
                                </td>
                                {/* <td>{new Intl.DateTimeFormat("en-IN", {
                                    year: 'numeric',
                                    month: 'long',
                                    day: '2-digit'
                                }).format(Date.parse(this.props.eventDetails.startDate))}</td> */}
                            </tr>
                            <tr>
                                <th>End Date</th>
                                <td>
                                {this.props.eventDetails.endDate}
                                </td>
                                {/* <td>{new Intl.DateTimeFormat("en-IN", {
                                    year: 'numeric',
                                    month: 'long',
                                    day: '2-digit'
                                }).format(Date.parse(this.props.eventDetails.endDate))}</td> */}
                            </tr>
                            <tr>
                                <th>Fees</th>
                                <td>{this.props.eventDetails.fees}</td>
                            </tr>
                            <tr>
                                <th>Attendance</th>
                                <td>
                                    <div className="progress">
                                        <div className="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style={{
                                            width: this.props.eventDetails.attendance + '%'
                                        }}>
                                            {this.props.eventDetails.attendance + '%'}
                                            <span className="sr-only">{this.props.eventDetails.attendance + '%'}</span>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th>Logo</th>
                                <td>
                                    <img src={"../" + this.props.eventDetails.logo} alt={this.props.eventDetails.eventName} />
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>)
        }
        else {
            return (<p></p>)
        }
    }
}

EventDetails.propsTypes = {
    eventDetails: propsTypes.object.isRequired,
    fetchSingleEvent: propsTypes.func.isRequired
}

const mapStateToProps = state => ({
    eventDetails: state.events.item
});

export default connect(mapStateToProps, { fetchSingleEvent })(EventDetails);