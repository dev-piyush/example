import React, { Component } from 'react';
import { BrowserRouter, Route } from "react-router-dom";
import { Provider } from "react-redux";

import store from "./store/store";


import EmployeesList from "./components/container/employees/EmployeesList";
import SepHome from "./components/presentation/home/SepHome";
import EventsList from "./components/container/events/EventsList";
import SepNavBar from "./components/presentation/navigation/MenuBar";
import RegisterNewEvent from "./components/container/events/RegisterNewEvent";
import EventDetails from './components/container/events/EventDetails';
import PostsList from "./components/container/jph/PostsList";

const MainLayout = () => (
    <div className="container-fluid">

        <main>
            <Route path="/" exact component={SepHome} />
            <Route path="/home" component={SepHome} />
            <Route path="/events" component={EventsList} />
            <Route path="/eventdetails/:id" component={EventDetails} />
            <Route path="/newevent" component={RegisterNewEvent} />
            <Route path="/employees" component={EmployeesList} />
            <Route path="/jph/posts" component={PostsList} />
        </main>
    </div>
)

class RootComponent extends Component {
    constructor() {
        super();
        this.state = {
            menuItems: [
                "Sep Portal",
                "Home",
                "Employees",
                "Events",
                "Jph Posts",
                "Register Event",
                "About Us",
                "Contact Us"
            ]
        };
    }
    render() {
        return (
            <Provider store={store}>
                <div>
                    <BrowserRouter>
                        <div>
                            <SepNavBar menuItems={this.state.menuItems} />
                            <MainLayout></MainLayout>
                        </div>
                    </BrowserRouter>

                </div>
            </Provider>
        );
    }
}

export default RootComponent;