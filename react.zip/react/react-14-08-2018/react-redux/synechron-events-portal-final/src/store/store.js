import { createStore, applyMiddleware, compose } from "redux";
import thunk from "redux-thunk";
import rootReducer from "../reducers/reducers";

const initialState = {};
const middleWares = [thunk];

const store = createStore(rootReducer, initialState, applyMiddleware(...middleWares));

export default store;