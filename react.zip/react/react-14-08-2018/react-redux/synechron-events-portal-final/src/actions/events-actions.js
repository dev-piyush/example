import { FETCH_EVENTS, FETCH_EVENT_DETAILS, NEW_EVENTS } from "./sep-types";

export const fetchAllEvents = () => dispatch => {
    console.log("Fetch All Events action is dispatched");
    fetch("http://localhost:9090/api/events").then(
        response => response.json(),
        reason => console.log(reason)
    ).then(
        events => dispatch({
            type: FETCH_EVENTS,
            payload: events
        }));
}
export const fetchSingleEvent = (id) => dispatch => {
    console.log("Fetch Single Event action is dispatched");
    fetch("http://localhost:9090/api/events/" + id).then(
        response => response.json(),
        reason => console.log(reason)
    ).then(
        event => dispatch({
            type: FETCH_EVENT_DETAILS,
            payload: event
        }));
}
export const insertNewEvent = (evnt) => dispatch => {
    console.log("New Event action is dispatched");
    fetch("http://localhost:9090/api/events", {
        method: "POST",
        headers: new Headers({
            "Content-Type": "application/json"
        }),
        body: JSON.stringify(evnt)
    }).then(
        response => response.json(),
        reason => console.log(reason)
    ).then(
        event => dispatch({
            type: NEW_EVENTS,
            payload: event
        }));
}