import { FETCH_EVENTS, FETCH_EVENT_DETAILS, NEW_EVENTS } from "../actions/sep-types";

const initialState = {
    items: [],
    item: {}
};

export default (state = initialState, action) => {
    switch (action.type) {
        case FETCH_EVENTS:
            state = {
                ...state,
                items: action.payload
            }
            break;
        case FETCH_EVENT_DETAILS:
            state = {
                ...state,
                item: action.payload
            }
            break;
        case NEW_EVENTS:
            state = {
                ...state,
                item: action.payload
            }
            break;
    }
    return state;
}