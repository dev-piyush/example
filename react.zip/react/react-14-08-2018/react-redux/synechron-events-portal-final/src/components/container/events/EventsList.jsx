import React from "react";
import { connect } from "react-redux";
import propTypes from 'prop-types';
import { fetchAllEvents } from "../../../actions/events-actions";
class EventsList extends React.Component {
    // constructor(props) {
    //     super(props);
    //     this.state = {
    //         events: [],
    //         eventDetails: null
    //     };
    // }
    componentDidMount() {
        this.props.fetchAllEvents();
        console.log(this.props.fetchAllEvents());
        //        this.fetchAllEvents();
    }
    // fetchAllEvents() {
    //     fetch("http://localhost:9090/api/events").then(
    //         response => response.json(),
    //         reason => console.log(reason)
    //     ).then(
    //         data => this.setState({
    //             events: data
    //         }),
    //         reason => console.log(reason)
    //     );
    // }
    onEventSelection(event) {
        this.setState({
            eventDetails: event
        });
        console.log(event);
    }
    onNavigation(e, id) {
        this.props.history.push("/eventdetails/" + id);
    }
    render() {
        return (
            <div>
                <h1>Welcome To Synechron Events List !</h1>
                <hr />
                <h5>Published By Synechron HR Department!</h5>
                <br />
                <table className="table table-hover table-striped">
                    <thead>
                        <tr>
                            <th>Event Code</th>
                            <th>Event Name</th>
                            <th>Start Date</th>
                            <th>Fees</th>
                            <th>Show Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            this.props.events.map((event, idx) =>
                                <tr key={idx}>
                                    <td><span>{event.eventCode}</span></td>
                                    <td><span>{event.eventName}</span></td>
                                    <td><span>{
                                        new Intl.DateTimeFormat("en-IN", {
                                            year: 'numeric',
                                            month: 'long',
                                            day: '2-digit'
                                        }).format(Date.parse(event.startDate))
                                    }</span></td>
                                    <td><span>{
                                        new Intl.NumberFormat("en-IN", {
                                            style: 'currency',
                                            currency: 'INR', maximumFractionDigits: 2,
                                            minimumFractionDigits: 2
                                        }).format(event.fees)
                                    }</span></td>
                                    <td><button className="btn btn-primary" onClick={
                                        (e, id) => this.onNavigation(e, event.eventId)
                                    }>Show Details</button></td>
                                </tr>
                            )
                        }
                    </tbody>
                </table>
            </div>
        );
    }
}

EventsList.propTypes = {
    fetchAllEvents: propTypes.func.isRequired,
    events: propTypes.array.isRequired
}

const mapStateToProps = state => ({
    events: state.events.items
});

export default connect(mapStateToProps,{fetchAllEvents})(EventsList);