import React from 'react';
import ReactDOM from 'react-dom';
import { createStore, applyMiddleware, combineReducers } from "redux";
import { Provider } from "react-redux";


const pageTitleReducer = (state = {
    title: "Welcome To Synechron Pvt. Ltd."
}, action) => {
    return state;
}

const store = createStore(combineReducers({
    pageTitleReducer
}));
// store.subscribe(() => {
//     console.log(`${store.getState()}`);
// });
import RootComponent from './RootComponent';

ReactDOM.render(<Provider store={store}>
    <RootComponent />
</Provider>, document.getElementById("container"));