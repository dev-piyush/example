import React, { Component } from 'react';
import ComponentOne from "./CompOne/ComponentOne";
import { connect } from "react-redux";

class RootComponent extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div className="container">
                <ComponentOne title={this.props.title} />
            </div>
        );
    }
}
const mapStateToProps = (state) => {
    console.log(state);
    return {
        title: state.pageTitleReducer.title
    }
}
export default connect(mapStateToProps)(RootComponent);