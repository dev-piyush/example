from rasa_core.actions import Action


class ActionSearchRestaurants(Action):
    def name(self):
        return 'action_search_restaurants'

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message("looking for restaurants")
        # restaurant_api = RestaurantAPI()
        # restaurants = restaurant_api.search(tracker.get_slot("cuisine"))
        return [SlotSet("matches", "restaurants")]


class ActionSuggest(Action):
    def name(self):
        return 'action_suggest'

    def run(self, dispatcher, tracker, domain):
        dispatcher.utter_message("looking for restaurants")
        # restaurant_api = RestaurantAPI()
        # restaurants = restaurant_api.search(tracker.get_slot("cuisine"))
        return [SlotSet("matches", "restaurants")]
