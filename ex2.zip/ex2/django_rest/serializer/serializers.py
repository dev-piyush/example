
from rest_framework import serializers
from .models import * 


class PersonSerializer(serializers.ModelSerializer):
    class Meta:
        model = SerializablePerson
        fields = ('name', 'mail', 'city','phonenumber')

