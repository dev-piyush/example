from django.conf.urls import url
from .views import person_list

urlpatterns = [
    url(r'^persons/$', person_list),
]