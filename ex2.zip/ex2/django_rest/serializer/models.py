from django.db import models

class SerializablePerson(models.Model):

   name = models.CharField(max_length = 50)
   city = models.CharField(max_length = 50)
   mail = models.CharField(max_length = 50)
   phonenumber = models.IntegerField(null=True, blank=True)

   class Meta:
      db_table = "SerializablePerson"



