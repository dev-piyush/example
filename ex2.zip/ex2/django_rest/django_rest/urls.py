from django.conf.urls import url, include
from rest_framework import routers
from quickstart import views
from nested_serializer import views as nsview

router = routers.DefaultRouter()
router.register(r'users', views.UserViewSet)
router.register(r'groups', views.GroupViewSet)
router.register(r'albums', nsview.AlbumViewSet)
router.register(r'tracks', nsview.TrackViewSet)
#router.register(r'persons', views.PersonViewSet)


# Wire up our API using automatic URL routing.
# Additionally, we include login URLs for the browsable API.
urlpatterns = [
    url(r'^', include(router.urls)),
    url(r'^api-auth/', include('rest_framework.urls', namespace='rest_framework')),
    url(r'^snippets/', include('snippets.urls')),
    url(r'^person_api/', include('serializer.urls')),

]
