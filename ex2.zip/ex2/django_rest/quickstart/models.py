from django.db import models

class Person(models.Model):

   name = models.CharField(max_length = 50)
   city = models.CharField(max_length = 50)
   mail = models.CharField(max_length = 50)
   phonenumber = models.IntegerField()

   class Meta:
      db_table = "abcd"
