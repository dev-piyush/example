from django.db import models


class BaseManager(models.Manager):

    def get_queryset(self):
        return self.queryset(self.model, using=self._db).exclude(deleted=True)  # Important!

    def all(self):
        return self.exclude(deleted=True)
