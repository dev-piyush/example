

ON_BOARDING_STATUS = (
    ('NOT APPLICABLE', 'Not Applicable'),
    ('Onboarded'.upper(), 'Onboarded'),
    ('Projected'.upper(), 'Projected'),
    ('Released', 'Released'),
    ('Closed', 'Closed')
