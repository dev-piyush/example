from twilio.rest import Client

# the following line needs your Twilio Account SID and Auth Token
client = Client("AC90aa355918b824007f994b77fc330669", "d00f45175345a4d0830a5bc457ca5a54")

# change the "from_" number to your Twilio number and the "to" number
# to the phone number you signed up for Twilio with, or upgrade your
# account to send SMS to any phone number
print client
client.messages.create(to="+919472391391", 
                       from_="+12052365685", 
                       body="Hello from piyush!")
