from elasticsearch_dsl.connections import connections
from elasticsearch_dsl import DocType, Text, Date
from elasticsearch_dsl import DocType, Text, Date, Search


from elasticsearch.helpers import bulk
from elasticsearch import Elasticsearch
from student.models import  BlogPost, Student

connections.create_connection()

class BlogPostIndex(DocType):
    author = Text()
    posted_date = Date()
    title = Text()
    text = Text()

    class Index:
        name = 'blogpost_index'

class StudentIndex(DocType):
    name = Text()
    university = Text()

    class Index:
        name = 'student_index'


def bulk_indexing():
    BlogPostIndex.init()
    es = Elasticsearch()
    bulk(client=es, actions=(b.indexing() for b in BlogPost.objects.all().iterator()))


def student_indexing():
    StudentIndex.init()
    es = Elasticsearch()
    bulk(client=es, actions=(s.indexing() for s in Student.objects.all().iterator()))


def search(author):
    s = Search().filter('term', author=author)
    response = s.execute()
    return response