from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
import django.db.models.options as options
from django.utils import timezone
from django.contrib.auth.models import User


options.DEFAULT_NAMES = options.DEFAULT_NAMES + (
    'es_index_name', 'es_type_name', 'es_mapping'
)


class University(models.Model):
    name = models.CharField(max_length=255, unique=True)


class Course(models.Model):
    name = models.CharField(max_length=255, unique=True)

    # def __str__(self):
    #     return self.name 


class Student(models.Model):
    YEAR_IN_SCHOOL_CHOICES = (
        ('FR', 'Freshman'),
        ('SO', 'Sophomore'),
        ('JR', 'Junior'),
        ('SR', 'Senior'),
    )
    # note: incorrect choice in MyModel.create leads to creation of incorrect record
    year_in_school = models.CharField(
        max_length=2, choices=YEAR_IN_SCHOOL_CHOICES)
    age = models.SmallIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(100)]
    )
    first_name = models.CharField(max_length=50)
    last_name = models.CharField(max_length=50)
    # various relationships models
    university = models.ForeignKey(University, null=True, blank=True)
    courses = models.ManyToManyField(Course, null=True, blank=True)

    def __str__(self):
        return '%s-%s' % (self.first_name, self.last_name)

    def all_cources(self):
        courses=[]
        for a in self.courses.all() :
            courses.append(a.name)
        return {'courses':courses}        

    def indexing(self):
       from pyElastic.search import StudentIndex
       obj = StudentIndex(
          meta={'id': self.id},
          name=self.first_name+self.last_name,
          university=self.university.name,
          courses=self.all_cources()
       )
       obj.save()
       print obj.to_dict()
       return obj.to_dict(include_meta=True)
    
    
    

class BlogPost(models.Model):
   author = models.ForeignKey(User, on_delete=models.CASCADE, related_name='blogpost')
   posted_date = models.DateField(default=timezone.now)
   title = models.CharField(max_length=200)
   text = models.TextField(max_length=1000)

   def indexing(self):
       from pyElastic.search import BlogPostIndex
       obj = BlogPostIndex(
          meta={'id': self.id},
          author=self.author.username,
          posted_date=self.posted_date,
          title=self.title,
          text=self.text
       )
       obj.save()
       return obj.to_dict(include_meta=True)        