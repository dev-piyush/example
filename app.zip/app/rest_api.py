from flask_restplus import Resource, Api

api = Api(
    title='Regression API',
    version='1.0',
    description='CPU Usage prediction API'
)