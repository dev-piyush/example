from flask_restplus import fields
from rest_api import api

###passport

reqparser = api.model('PredRequest', {
    'RWReportcount': fields.Integer(default=44,required = True, description='Count'),
    'DiaryCount': fields.Integer(default=27,required = True, description='Count'),
    'ExportCount': fields.Integer(default=45,required = True, description='Count'),
    'ReportCount': fields.Integer(default=30,required = True, description='Count'),
    'RunCount': fields.Integer(default=31,required = True, description='Count'),
    'FormCount': fields.Integer(default=16,required = True, description='Count'),
    'BatchCount': fields.Integer(default=8,required = True, description='Count'),
    'AutoCount': fields.Integer(default=1,required = True, description='Count'),
    'XplorerCount': fields.Integer(default=0,required = True, description='Count'),
})

###response
response = api.model('PredResponse', {
    'cpu_usage_per': fields.Float(description='CPU usage prediction')
})