from keras.models import Sequential
from keras.layers import Dense
from keras.callbacks import ModelCheckpoint
from sklearn.metrics import mean_squared_error
from keras.activations import relu

def relu_advanced(x):
    return relu(x, max_value=100)

def get_model():
    model = Sequential()
    model.add(Dense(18, input_dim=9, kernel_initializer='normal', activation='linear'))
    model.add(Dense(9, kernel_initializer='normal', activation='linear'))
    model.add(Dense(1, kernel_initializer='normal', activation=relu_advanced))
    model.compile(loss='mean_squared_error', optimizer='adam')
    model.load_weights("namespaces/weights/regression.hdf5")
    return model