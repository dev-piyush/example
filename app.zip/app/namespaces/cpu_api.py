from configuration import reqparser, response
from flask_restplus import Resource
from rest_api import api
from flask import request
from keras.models import load_model
from .model import get_model
import numpy as np

ns = api.namespace('cpu', description='CPU usage prediction')

model = get_model()

@ns.route('')
class Cpu(Resource):
    @ns.marshal_with(response)
    @ns.expect(reqparser, validate=True)
    def post(self):
        '''Performs OCR on Passport'''
        RWReportcount = api.payload.get('RWReportcount')
        DiaryCount = api.payload.get('DiaryCount')
        ExportCount = api.payload.get('ExportCount')
        ReportCount = api.payload.get('ReportCount')
        RunCount = api.payload.get('RunCount')
        FormCount = api.payload.get('FormCount')
        BatchCount = api.payload.get('BatchCount')
        AutoCount = api.payload.get('AutoCount')
        XplorerCount = api.payload.get('XplorerCount')
        feature = np.array([RWReportcount,DiaryCount,ExportCount,ReportCount,RunCount,FormCount,BatchCount,AutoCount,XplorerCount]).reshape((1,9))
        result = model.predict(feature)[0][0]
        return {'cpu_usage_per':result}
