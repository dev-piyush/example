"""
Swagger API
"""
from flask import Flask
from flask_cors import CORS
# from flask_restplus import Resource, Api
from rest_api import api
from namespaces.cpu_api import ns as cpu_namespace
#import cv2

def main():
    '''
    Python Flask App Configuration
    '''
    app = Flask(__name__)
    CORS(app, origins='*')
    api.add_namespace(cpu_namespace)
    api.init_app(app)
    app.run(host='0.0.0.0', port=8080)

if __name__ == '__main__':
    main()
    