from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_admin import Admin

 
app = Flask(__name__)

@app.after_request
def after_request(response):
  response.headers.add('Access-Control-Allow-Origin', '*')
  response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
  response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,')
  return response

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:root@localhost/flaskdb'
db = SQLAlchemy(app)


 
from my_app.user.views import user_blueprint
from my_app.book.views import book_blueprint
from my_app.borrow.views import borrow_blueprint

app.register_blueprint(user_blueprint)
app.register_blueprint(book_blueprint)
app.register_blueprint(borrow_blueprint)

db.create_all()

from my_app.user.models import User
from my_app.book.models import Book
from my_app.borrow.models import Borrow
from flask_admin.contrib.sqla import ModelView
admin = Admin(app, name='Library Management', template_mode='bootstrap3')

admin.add_view(ModelView(User, db.session))
admin.add_view(ModelView(Book, db.session))
admin.add_view(ModelView(Borrow, db.session))