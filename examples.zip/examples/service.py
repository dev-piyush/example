import yagmail
from nameko.rpc import rpc, RpcProxy
import smtplib
import base64
from O365 import Message


class Mail(object):
    name = "mail"

    @rpc
    def send(self, to, subject, contents):
        send_mail(to, subject, contents)


class Compute(object):
    name = "compute"
    mail = RpcProxy('mail')    

    @rpc
    def compute(self, operation, value, other, email):
        operations = {'sum': lambda x, y: int(x) + int(y),
                      'mul': lambda x, y: int(x) * int(y),
                      'div': lambda x, y: int(x) / int(y),
                      'sub': lambda x, y: int(x) - int(y)}
        try:
            result = operations[operation](value, other)
        except Exception as e:
            self.mail.send.async(email, "An error occurred", str(e))
            raise
        else:
            self.mail.send(
                email, 
                "Your operation is complete!", 
                "The result is: %s" % result
            )
            return result

def send_mail(to, subject, content):            
    authenticiation = ('piyush.raj@synechron.com','Mani@007')
    m = Message(auth=authenticiation)
    m.setRecipients(to)
    m.setSubject(subject)
    m.setBody(content)
    r=m.sendMessage()
    print (r)
