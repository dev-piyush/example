## Nameko microservices

Simple microservices example using Nameko.


## Running

`$ docker-compose up`
