# cloudstorage
Repository for handling document storage to cloud with user authentication using openstack swift,nodejs,mysql and reactjs

